import json, numpy as np
c0=299792458.0
J=json.load(open('js_out.json'))
def rel(a,b): 
    a=np.asarray(a,float); b=np.asarray(b,float)
    return float(np.max(np.abs(a-b)/np.maximum(np.abs(b),1e-12)))
print("=== LINEA DE TRANSMISION (Pozar 2.3, Ulaby 2-6/2-7) ===")
for r in J['lt']:
    Z0,RL,XL,d=r['in']; ZL=RL+1j*XL
    G=(ZL-Z0)/(ZL+Z0); S=(1+abs(G))/(1-abs(G)) if abs(G)<1 else np.inf
    bd=2*np.pi*d
    env=abs(1+G*np.exp(-2j*bd))
    with np.errstate(all='ignore'):
        Zin=Z0*(ZL+1j*Z0*np.tan(bd))/(Z0+1j*ZL*np.tan(bd))
        # forma alternativa via Gamma(d) (robusta)
        Gd=G*np.exp(-2j*bd); Zin2=Z0*(1+Gd)/(1-Gd)
    th=np.angle(G); dmin=((th+np.pi)/(4*np.pi))%0.5
    # vInst t=0: Re[e^{jbd}+G e^{-jbd}]
    v0=(np.exp(1j*bd)+G*np.exp(-1j*bd)).real
    print(f"ZL={ZL} Z0={Z0} d={d}: G js={r['G'][0]:+.5f}{r['G'][1]:+.5f}j py={G:.5f} | S js={r['S']} py={S:.4f} | env js={r['env']:.6f} py={env:.6f} rel={rel(r['env'],env):.1e} | Zin js={r['Zin'][0]:.4f}{r['Zin'][1]:+.4f}j py={Zin2:.4f} rel={rel(r['Zin'],[Zin2.real,Zin2.imag]) if abs(Zin2)<1e7 else 'inf'} | dmin js={r['dmin']:.5f} py={dmin:.5f} envmin={r['envmin']:.3e} | v0 js={r['vInst0']:.5f} py={v0:.5f}")
print("\n=== SMITH (Pozar 2.4) ===")
for r in J['sm']:
    Z0,RL,XL,d=r['in']; z=(RL+1j*XL)/Z0
    G=(z-1)/(z+1); Gd=G*np.exp(-4j*np.pi*d); zin=(1+Gd)/(1-Gd)
    ZL=RL+1j*XL; bd=2*np.pi*d
    with np.errstate(all='ignore'): Zin=Z0*(ZL+1j*Z0*np.tan(bd))/(Z0+1j*ZL*np.tan(bd))
    print(f"z={z:.4f} d={d}: Gd js={r['Gd'][0]:+.5f}{r['Gd'][1]:+.5f}j py={Gd:.5f} | Zin js={r['Zin'][0]:.3f}{r['Zin'][1]:+.3f}j py(Zin)={Zin:.3f} py(G)={zin*Z0:.3f} fmt={r['ZinFmt']}")
# círculos de la carta
print("\nCírculos r: ", [(f"r={rr}", f"centro {rr/(1+rr):.3f}", f"radio {1/(1+rr):.3f}") for rr in [0.2,0.5,1,2,5]])
# verificación: puntos de z=r+jx caen sobre círculo
for rr in [0.5,2]:
    for xx in [0.3,-1.7,5]:
        G=((rr+1j*xx)-1)/((rr+1j*xx)+1)
        print(f"  z={rr}+j{xx}: |G-c_r|={abs(G-rr/(1+rr)):.4f} (rad {1/(1+rr):.4f}); |G-c_x|={abs(G-(1+1j/xx)):.4f} (rad {1/abs(xx):.4f})")
print("\n=== GUIA DE ONDA (Pozar 3.3) ===")
EIA={'WR-90':(22.86,10.16,8.2,12.4),'WR-284':(72.14,34.04,2.6,3.95),'WR-42':(10.668,4.318,18.0,26.5),'WR-62':(15.799,7.899,12.4,18.0)}
for k,(a,b,f1,f2) in EIA.items():
    fc=c0/(2*a*1e-3)/1e9; fc2=c0/(a*1e-3)/1e9; fc01=c0/(2*b*1e-3)/1e9
    print(f"{k}: a={a} b={b} fc10={fc:.3f} GHz, TE20={fc2:.3f}, TE01={fc01:.3f}, banda EIA {f1}-{f2} -> {f1/fc:.2f}..{f2/fc:.2f} fc10")
for r in J['go']:
    a,b,f=r['in']
    def fcmn(m,n): return c0/2*np.sqrt((m/a)**2+(n/b)**2)
    ms=sorted([(fcmn(m,n),f'TE{m}{n}') for m in range(4) for n in range(4) if (m,n)!=(0,0)])[:6]
    fc10=fcmn(1,0); u=np.sqrt(1-(fc10/f)**2) if f>fc10 else 0
    lam=c0/f
    print(f"a={a*1e3} b={b*1e3} f={f/1e9} GHz: fc10 js={r['fc10']/1e9:.4f} py={fc10/1e9:.4f} | modos js={[(m[0],round(m[1]/1e9,3)) for m in r['modos']]} py={[(n,round(v/1e9,3)) for v,n in ms]} | lamg js={r['lamg']} py={lam/u if u else None} | vp js={r['vp']} py={1/u if u else None} vg js={r['vg']} py={u} | nprop={r['nprop']} fmt={r['fmt']}")
print("\n=== ANATOMIA ===")
mu0=4e-7*np.pi
for r in J['an']['delta']:
    f,s,m=r['in']; d=1/np.sqrt(np.pi*f*mu0*m*s)
    print(f"f={f} s={s} mur={m}: js={r['d']:.6e} py={d:.6e} rel={rel(r['d'],d):.1e}")
print("logspace ends", J['an']['freqsLog'], "linspace", J['an']['freqsLin'])
print("f(delta=35um):", [(n,f"{v:.4g}") for n,v in J['an']['fref']], " py cobre:", 1/(np.pi*mu0*5.8e7*(35e-6)**2))
