import numpy as np, json, subprocess
def tmm(n1,n2,n3,dl):   # matriz de transferencia / fórmula exacta de 3 medios (Hecht 4.? / Ulaby 8-?): Γ = (r12 + r23 e^{-2jφ})/(1 + r12 r23 e^{-2jφ}), φ=β2 d, conv. e^{jωt}
    h1,h2,h3=377/n1,377/n2,377/n3
    r12=(h2-h1)/(h2+h1); r23=(h3-h2)/(h3+h2); phi=2*np.pi*dl
    G=(r12+r23*np.exp(-2j*phi))/(1+r12*r23*np.exp(-2j*phi))
    t12=1+r12; t23=1+r23
    tau=t12*t23*np.exp(-1j*phi)/(1+r12*r23*np.exp(-2j*phi))   # amplitud en medio 3 referida a z=-d
    return G,tau,r12,r23
cases=[dict(n=[1,1.38,1.52],d=0.25),dict(n=[1,1.38,1.52],d=0.5),dict(n=[1,1.44,1.0],d=0.5),dict(n=[1,1.44,1.0],d=0.25),
       dict(n=[1,np.sqrt(1.52),1.52],d=0.25),dict(n=[1,1.23,1.52],d=0.25),dict(n=[1.52,1.0,1.52],d=0.02),dict(n=[1,2.35,1.77],d=1.5),
       dict(n=[1.5,1.0,1.0],d=0.3),dict(n=[1,1.38,1.52],d=0.75)]
js=json.loads(subprocess.check_output(['node','capa3_js.js',json.dumps(cases)]))
print(f"{'caso':40s} {'|G| js':>8s} {'|G| py':>8s} {'R js %':>8s} {'R py %':>8s} {'R13 %':>7s} {'|tau3| js':>9s} {'|tau3| py':>9s} {'R+T(n3/n1)':>10s}")
for c,j in zip(cases,js):
    n1,n2,n3=c['n']; G,tau,r12,r23=tmm(n1,n2,n3,c['d'])
    # eta(d) independiente
    h1,h2,h3=377/n1,377/n2,377/n3; bd=2*np.pi*c['d']
    Z=h2*(h3+1j*h2*np.tan(bd))/(h2+1j*h3*np.tan(bd)) if abs(np.cos(bd))>1e-9 else h2*h2/h3
    Gz=(Z-h1)/(Z+h1)
    tj=abs(complex(*j['tau3']))
    # en el JS tau3 está referido a z=0 (A·(1+r23)); |tau3| no depende de la referencia de fase
    print(f"{str(c):40s} {j['G']:8.4f} {abs(G):8.4f} {100*j['R']:8.3f} {100*abs(G)**2:8.3f} {100*j['R13']:7.3f} {tj:9.4f} {abs(tau):9.4f} {abs(G)**2+abs(tau)**2*(n3/n1):10.6f}")
    assert abs(j['G']-abs(G))<1e-9 and abs(abs(Gz)-abs(G))<1e-9 and abs(tj-abs(tau))<1e-9
    assert abs(complex(j['etaRe'],j['etaIm'])-Z)<1e-6
print("Vidrio sin capa n=1.52: R =",100*((1.52-1)/(2.52))**2,"% ; n=1.5:",100*(0.5/2.5)**2)
print("n2 ideal para aire|vidrio 1.52:",np.sqrt(1.52),"-> redondeado 1.23: R(λ/4)=",100*abs(tmm(1,1.23,1.52,.25)[0])**2,"%")
print("MgF2 λ/4 sobre BK7: R=",100*abs(tmm(1,1.38,1.52,.25)[0])**2,"%  (Hecht: ~1.3 %)")
# minimo del rango d=0.02: no se puede ver d->0 ; a d=0.02 con 1|1.38|1.52:
print("d=0.02:",100*abs(tmm(1,1.38,1.52,.02)[0])**2)
