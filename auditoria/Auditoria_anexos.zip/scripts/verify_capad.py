import numpy as np, json, subprocess
eta0=376.73; c=2.998e8
def exact(e1,e2,e3,dl):
    h=[eta0/np.sqrt(e) for e in (e1,e2,e3)]
    r12=(h[1]-h[0])/(h[1]+h[0]); r23=(h[2]-h[1])/(h[2]+h[1]); phi=2*np.pi*dl
    return (r12+r23*np.exp(-2j*phi))/(1+r12*r23*np.exp(-2j*phi)), h
cases=[dict(e1=1,e2=4,e3=16,dr=0.25,f=10),dict(e1=1,e2=4,e3=16,dr=0.5,f=10),dict(e1=1,e2=4,e3=1,dr=0.5,f=10),dict(e1=1,e2=4,e3=1,dr=0.25,f=10),
       dict(e1=1,e2=2,e3=4,dr=0.25,f=10),dict(e1=1,e2=2,e3=4,dr=0.0,f=1),dict(e1=10,e2=20,e3=20,dr=1.0,f=40),dict(e1=1,e2=1,e3=16,dr=0.37,f=10),
       dict(e1=1,e2=4,e3=16,dr=0.75,f=2.5),dict(e1=3,e2=9,e3=1,dr=0.125,f=10)]
js=json.loads(subprocess.check_output(['node','capad_js.js',json.dumps(cases)]))
print(f"{'caso':60s} {'|G| js':>8s} {'|G| py':>8s} {'R js %':>8s} {'R py %':>8s} {'d mm js':>8s} {'d mm py':>8s}")
for cc,j in zip(cases,js):
    G,h=exact(cc['e1'],cc['e2'],cc['e3'],cc['dr'])
    lam2=c/(cc['f']*1e9)/np.sqrt(cc['e2']); dmm=cc['dr']*lam2*1e3
    bd=2*np.pi*cc['dr']; Z=h[1]*(h[2]*np.cos(bd)+1j*h[1]*np.sin(bd))/(h[1]*np.cos(bd)+1j*h[2]*np.sin(bd))
    print(f"{str(cc):60s} {j['G']:8.4f} {abs(G):8.4f} {100*j['R']:8.3f} {100*abs(G)**2:8.3f} {j['dmm']:8.3f} {dmm:8.3f}")
    assert abs(j['G']-abs(G))<1e-9 and abs(j['dmm']-dmm)<1e-9 and abs(complex(j['etaRe'],j['etaIm'])-Z)<1e-6
# Ulaby ejemplo: radomo? ; Griffiths 9.3 no cubre 3 medios (problema 9.35?). Casos: 1|2|4 λ/4 -> R=0 ; eta2=sqrt(eta1 eta3) <=> er2=sqrt(er1 er3)
print("er2 ideal 1|?|16 = 4 exacto; 1|?|4 = 2 exacto")
# ideal button rounding: e1=1,e3=10 -> sqrt(10)=3.162->3.2
G,_=exact(1,3.2,10,.25); print("1|3.2|10 λ/4 (botón ideal redondea a 0.1): R=",100*abs(G)**2,"%")
G,_=exact(1,np.sqrt(10),10,.25); print("1|3.162|10: R=",100*abs(G)**2)
