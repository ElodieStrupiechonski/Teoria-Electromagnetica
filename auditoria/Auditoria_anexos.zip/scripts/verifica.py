"""Reimplementación independiente (numpy) de la física de los 5 exploradores U2 y comparación con las salidas del JS."""
import json, sys, numpy as np
js = json.load(open(sys.argv[1]))
c = 299792458.0; mu0 = 4e-7*np.pi; eps0 = 8.8541878128e-12
h = 6.62607015e-34; e = 1.602176634e-19

print("="*70); print("1) MICROONDAS  c = 2 d f")
for r in js['micro']:
    f = float(r['f_GHz'])*1e9; D = r['h2']-r['h1']; n = r['n']
    c_ind = 2*(D/100/n)*f
    print(f"f={f/1e9:.3f} GHz  Wcm={r['Wcm']} n={n} D={D:.2f} cm  JS c={r['c']}  ind c={c_ind:.4e}  err_JS={r['err']}%  λ/2 teór={c/f*50:.2f} cm")
for (uf,uD,un),r in zip([(2450,23,3),(2450,24.5,4),(915,49.2,3),(2450,18.3,3),(2450,6.12,1)], js['micro_u']):
    cind = 2*(uD/100/un)*uf*1e6
    print(f"  usuario f={uf} MHz D={uD} n={un}: JS c={r['c']} err={r['err']}%  ind={cind:.4e} ({(cind-c)/c*100:+.1f}%)")
print("  Incertidumbre (no implementada): con D=23±0.5 cm, n=3, f exacta: δc/c = δD/D =", f"{0.5/23*100:.1f}%")

print("="*70); print("2) EFECTO PIEL")
def gamma_general(f, sig, er, mur=1):
    w = 2*np.pi*f; eps = er*eps0
    g = 1j*w*np.sqrt(mu0*mur*eps)*np.sqrt(1 - 1j*sig/(w*eps))   # Ulaby 7-4: γ = jω√(με_c)
    eta = np.sqrt(mu0*mur/eps)/np.sqrt(1-1j*sig/(w*eps))
    return g.real, g.imag, eta
for r in js['piel']:
    f = r['f']; sig = r['sigma']; er = {'mar':81}.get(r['mat'],1)
    d_gc = 1/np.sqrt(np.pi*f*mu0*sig)
    a, b, eta = gamma_general(f, sig, er)
    d_gen = 1/a
    print(f"{r['mat']:9s} f={f:9.3g} Hz: JS δ={r['delta_txt']:>11s} ({r['delta']:.4e})  ind(buen cond)={d_gc:.4e}  GENERAL δ=1/α={d_gen:.4e}  dif={(r['delta']-d_gen)/d_gen*100:+.1f}%  "
          f"β/α={b/a:.3f}  ∠η={np.degrees(np.angle(eta)):.1f}° (JS {r['ang']}°)  |η|={abs(eta):.3e}  Rs_JS={r['Rs']}  tanδ={r['tanD']:.3g} reg={r['reg']}")
print("  Fase dibujada (línea 171): H=cos(u−t−lag). Pico de E en t=0; pico de H en t=", js['piel_phase'][0]['t_peak_H'], "rad = −lag mod 2π → H ADELANTA a E en el dibujo (debería retrasarse).")

print("="*70); print("3) POLARIZACIÓN")
def AR_exact(A,B,d):
    # semiejes de la elipse: autovalores de la matriz de covarianza del fasor
    E = np.array([A, B*np.exp(1j*d)])
    M = np.array([[A*A, A*B*np.cos(d)],[A*B*np.cos(d), B*B]])
    lam = np.linalg.eigvalsh(M)
    if lam[0] < 1e-12: return np.inf
    return np.sqrt(lam[1]/lam[0])
def plf_exact(A,B,d,th):
    E = np.array([A, B*np.exp(1j*d)]); a = np.array([np.cos(th), np.sin(th)])
    return abs(np.vdot(a, E))**2/np.vdot(E,E).real
def ellipse_params(A,B,d):
    # Ulaby 7-2.3: tan2ψ = tan(2ψ0) cosδ ; sin2χ = sin(2ψ0) sinδ ; tanψ0=B/A
    psi0 = np.arctan2(B, A)
    psi = 0.5*np.arctan2(np.tan(2*psi0)*np.cos(d), 1) if abs(np.cos(2*psi0))>1e-12 else (np.pi/4 if np.cos(d)>0 else -np.pi/4)
    chi = 0.5*np.arcsin(np.sin(2*psi0)*np.sin(d))
    return np.degrees(psi), np.degrees(chi)
for r in js['pol']:
    A,B,d,th = r['A'],r['B'],np.radians(r['delta']),np.radians(r['theta'])
    ar = AR_exact(A,B,d); p = plf_exact(A,B,d,th); psi,chi = ellipse_params(A,B,d)
    # sentido: z hacia el observador, Ex=A cos ωt, Ey=B cos(ωt+δ); dψ/dt ∝ -A B sinδ  (Ex Ey' - Ey Ex')
    w = -A*B*np.sin(d)   # >0 antihorario en pantalla
    sent = 'lineal' if abs(w)<1e-9 else ('antihorario' if w>0 else 'horario')
    ieee = '' if abs(w)<1e-9 else (' = LHCP (IEEE, visto hacia +z: antihorario) / "derecha" en convención óptica' if w<0 else ' = RHCP (IEEE) / "izquierda" óptica')
    print(f"A={A} B={B} δ={r['delta']}° θ={r['theta']}°: JS tipo={r['tipo']} giro={r['giro']} AR={r['AR']} PLF={r['PLF']:.4f} ({r['PLF_dB']} dB) | ind AR={ar:.3f} PLF={p:.4f} giro={sent}{ieee}  ψ={psi:.1f}° χ={chi:.1f}°")
print("  Umbral 'Circular' |sinδ−1|<0.04 → δ∈(%.1f°,%.1f°)" % (np.degrees(np.arcsin(0.96)), 180-np.degrees(np.arcsin(0.96))))
print("  A=B, δ=74°: AR exacta =", f"{AR_exact(1,1,np.radians(74)):.3f}", " PLF(45°)=", f"{plf_exact(1,1,np.radians(74),np.radians(45)):.3f}", " PLF(135°)=", f"{plf_exact(1,1,np.radians(74),np.radians(135)):.3f}")

print("="*70); print("4) DOPPLER")
for r in js['dop1']:
    b = r['beta']
    rel_up = np.sqrt((1+b)/(1-b)) if b<1 else np.inf; rel_dn = np.sqrt((1-b)/(1+b))
    print(f"β={b}: JS adelante={r['fup']} atrás={r['fdn']} | acústica fuente móvil {1/(1-b):.3f}/{1/(1+b):.3f} | RELATIVISTA (EM) {rel_up:.3f}/{rel_dn:.3f}  dif={(1/(1-b)-rel_up)/rel_up*100:+.1f}%/{(1/(1+b)-rel_dn)/rel_dn*100:+.1f}%")
for r in js['dop3']:
    z = r['zb']; b_rel = ((1+z)**2-1)/((1+z)**2+1)
    print(f"z={z}: JS Hα={r['Ha']} nm v={r['vkm']} km/s | ind λ={656.28*(1+z):.1f} nm  v_clásica={z*c/1e3:.0f} km/s  v_relativista={b_rel*c/1e3:.0f} km/s ({(z-b_rel)/max(b_rel,1e-12)*100:+.1f}%)")
print("  Hα sale de la barra (780 nm) para z >", f"{780/656.3-1:.3f}")
for (f,v,dir,k),r in zip([(10,30,1,2),(10,30,-1,1),(24,40,1,2),(1.575,7000,1,1),(2.45,0.1,1,2)], js['dop4']):
    df = k*f*1e9*v/c*dir
    print(f"f={f} GHz v={v} m/s dir={dir} k={k}: JS Δf={r['df']:.4f} Hz ({r['df_txt']}) ind={df:.4f} Hz  rel exacto 1 vía: {f*1e9*(np.sqrt((1+v/c)/(1-v/c))-1)*dir:.4f} Hz")

print("="*70); print("5) ESPECTRO")
for r in js['esp']:
    f = r['f_raw']; lam = c/f; EeV = h*f/e; wn = 1/(lam*100)
    print(f"logf={r['logf']:.4f} band={r['band']:15s} JS f={r['f']:>12s} λ={r['lam']:>10s} E={r['E_eV']:>11s} ν̄={r['wn']:>9s} cm⁻¹ color={r['color']} | CODATA λ={lam:.4e} m ({(r['lam_raw']-lam)/lam*100:+.3f}%) E={EeV:.4e} eV ({(r['EeV_raw']-EeV)/EeV*100:+.3f}%) ν̄={wn:.4e}")
print("  hc =", f"{h*c/e*1e9:.2f} eV·nm; 1 eV =", f"{e/(h*c*100):.2f} cm⁻¹ =", f"{e/h:.4e} Hz; h =", f"{h/e:.4e} eV·s")
print("  límites de banda: log10(f) de 750 nm =", f"{np.log10(c/750e-9):.3f}", "; 380 nm =", f"{np.log10(c/380e-9):.3f}", "; 700 nm =", f"{np.log10(c/700e-9):.3f}", "; 300 MHz = 8.477; 300 GHz = 11.477; 10 nm = ", f"{np.log10(c/10e-9):.3f}", "; 100 keV =", f"{np.log10(1e5*e/h):.3f}")
print("  octavas 1 kHz–1 YHz:", f"{np.log2(1e21):.1f}", "; visible 380–750:", f"{np.log2(750/380):.2f}")
