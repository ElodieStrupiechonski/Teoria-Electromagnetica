import numpy as np, json, subprocess, sys
mu0=4e-7*np.pi; eps0=8.8541878128e-12; eta0=np.sqrt(mu0/eps0)
print("eta0 exacto =",eta0)
cases=[dict(er=4,cond=False,d=0.25),dict(er=4,cond=False,d=0.5),dict(er=1,cond=False,d=0.3),
       dict(er=16,cond=False,d=0.0),dict(er=16,cond=False,d=2.0),dict(er=2.5,cond=False,d=0.125),
       dict(er=4,cond=True,d=0.25),dict(er=4,cond=True,d=0.1),dict(er=4,cond=True,d=0.5),dict(er=9,cond=False,d=0.75)]
js=json.loads(subprocess.check_output(['node','refl_js.js',json.dumps(cases)]))
print(f"{'caso':38s} {'G js':>8s} {'G py':>8s} {'eta(d) js':>22s} {'eta(d) py':>22s} {'A js':>7s} {'A py':>7s} {'1-|G|^2-(η1/η2)|τ|^2':>12s}")
for c,j in zip(cases,js):
    eta1=377.0  # el JS usa 377 (no 376.73); uso el mismo valor para aislar la fórmula
    if c['cond']:
        eta2=0.0; G=-1.0; tau=0.0
    else:
        eta2=eta1/np.sqrt(c['er']); G=(eta2-eta1)/(eta2+eta1); tau=1+G
    bd=2*np.pi*c['d']
    # Ulaby 8-? : Z_in(-d) = eta1 (eta2 + j eta1 tan bd)/(eta1 + j eta2 tan bd) ; usar cos/sen
    num=eta2*np.cos(bd)+1j*eta1*np.sin(bd); den=eta1*np.cos(bd)+1j*eta2*np.sin(bd)
    z=eta1*num/den if abs(den)>1e-12 else complex(np.inf,np.inf)
    # onda estacionaria |E1(z)| = |E0| |1 + G e^{2j b1 z}|, z=-d
    A=abs(1+G*np.exp(-2j*bd))
    P = 1-abs(G)**2-(eta1/eta2 if eta2>0 else 0)*abs(tau)**2
    zj=complex(j['etaRe'],j['etaIm']) if j['etaRe'] is not None else complex(np.inf,np.inf)
    print(f"{str(c):38s} {j['G']:8.4f} {G:8.4f} {str(np.round(zj,2)):>22s} {str(np.round(z,2)):>22s} {j['A']:7.4f} {A:7.4f} {P:12.2e}")
    assert abs(j['G']-G)<1e-12 and abs(j['A']-A)<1e-9
    if np.isfinite(z.real): assert abs(zj-z)<1e-6*max(1,abs(z)), (zj,z)
# check A at d=0.5 and 0.25 limits vs SWR
for er in [4,16]:
    eta2=377/np.sqrt(er);G=(eta2-377)/(eta2+377)
    print(f"er={er}: |E|max={1+abs(G):.4f}, |E|min={1-abs(G):.4f}, S={(1+abs(G))/(1-abs(G)):.4f}, posiciones max: G<0 -> theta_r=pi -> z_max=-(pi+2n pi)/(2b1) = -(lam/4 + n lam/2)")
# mostrar efecto de 377 vs 376.73 en G
for er in [4,16]:
    print("sensibilidad a eta0: G identica para cualquier eta0 (solo cociente); eta2 difiere:",377/np.sqrt(er),eta0/np.sqrt(er))
