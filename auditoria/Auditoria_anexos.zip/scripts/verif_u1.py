"""Verificación independiente (numpy/scipy) de los exploradores U1 contra las salidas del JS (js_out.json)."""
import json, sys, numpy as np
from scipy import integrate
EPS0 = 8.8541878128e-12   # CODATA 2018
MU0  = 1.25663706212e-6   # CODATA 2018 (4π·1e-7 = 1.2566370614e-6)
js = json.load(open(sys.argv[1]))
def rel(a,b): return abs(a-b)/abs(b) if b else abs(a-b)
def rep(name, js_v, ref, tag=''):
    print(f"  {name:38s} JS={js_v:.6g}  ref={ref:.6g}  rel={rel(js_v,ref):.2e} {tag}")

print("=== GAUSS ===")
def E_ref(esc,Q,R,sig,r):
    if esc=='placa': return abs(sig)/(2*EPS0)
    if esc=='punto' or r>=R: return abs(Q)/(4*np.pi*EPS0*r**2)
    return abs(Q)*r/(4*np.pi*EPS0*R**3)
cases = {'punto def':('punto',5e-9,.3,10e-9,.55),'punto r=4cm':('punto',5e-9,.3,10e-9,.04),
 'punto Q=-5nC r=1m':('punto',-5e-9,.3,10e-9,1.0),'esfera r<R (r=0.15,R=0.30)':('esfera',5e-9,.3,10e-9,.15),
 'esfera r=R':('esfera',5e-9,.3,10e-9,.3),'esfera r>R (0.55)':('esfera',5e-9,.3,10e-9,.55),
 'placa def':('placa',5e-9,.3,10e-9,.55),'placa sig=-100nC/m2':('placa',5e-9,.3,-100e-9,.04)}
for name,o in js['gauss']:
    esc,Q,R,sig,r = cases[name]
    rep(name+' E', o['E'], E_ref(esc,Q,R,sig,r))
    if o['Flux'] is not None:
        # flujo real = E·4πr² (con signo de Q)
        flux = np.sign(Q)*E_ref(esc,Q,R,sig,r)*4*np.pi*r**2
        rep(name+' Flux(E*4pi r^2)', o['Flux'], flux)
# Flujo por unidad de area para placa: 2E = sigma/eps0
print("  placa: 2E*A/A =", 2*E_ref('placa',0,0,10e-9,0), " sigma/eps0 =", 10e-9/EPS0)

print("=== CAPACITOR ===")
def cap_ref(A,s,er,p,V=None,Q=None):
    C = EPS0*A/s*(1+p*(er-1))
    if V is None: V=Q/C
    Q=C*V
    return dict(C=C,V=V,Q=Q,E=V/s,U=0.5*C*V*V)
cc = {'def V fijo p=0':(100e-4,2e-3,4,0,100,None),'V fijo p=0.5':(100e-4,2e-3,4,.5,100,None),
 'V fijo p=1':(100e-4,2e-3,4,1,100,None),'Q fija p=1 (Q=C0*100V)':(100e-4,2e-3,4,1,None,8.854e-12*100e-4/2e-3*100),
 'Q fija p=0.5':(100e-4,2e-3,4,.5,None,8.854e-12*100e-4/2e-3*100),
 'extremo A=1cm2 s=0.1mm er=80 V=1000':(1e-4,1e-4,80,1,1000,None),'er=1 p=1':(100e-4,2e-3,1,1,100,None)}
for name,o in js['cap']:
    r = cap_ref(*cc[name])
    for k in ('C','V','Q','E','U'): rep(f'{name} {k}', o[k], r[k])
# energía con dieléctrico a V fijo vs Q fija (Griffiths 4.4.3)
print("  Q fija p=1: U(p=1)/U(p=0) =", cap_ref(100e-4,2e-3,4,1,None,4.427e-10)['U']/cap_ref(100e-4,2e-3,4,0,None,4.427e-10)['U'], "(esperado 1/er=0.25)")

print("=== SOLENOIDE ===")
def Bz_biot(I,N,L,d,z):
    """Integral directa de Biot–Savart de anillos (sin usar la fórmula cerrada)."""
    a=d/2; n=N/L
    f=lambda x: MU0*n*I*a**2/(2*(a**2+(z-x)**2)**1.5)
    return integrate.quad(f,-L/2,L/2)[0]
sc = {'P3 def z=0':(2,50,.04,.067,0),'P3 z=L/2 (borde)':(2,50,.04,.067,.02),'P3 z=5cm fuera':(2,50,.04,.067,.05),
 'largo L=30 d=1 I=3 N=300':(3,300,.30,.01,0),'largo borde z=0.15':(3,300,.30,.01,.15),
 'corto L=2 d=12 I=0.5 N=10':(.5,10,.02,.12,0),'L/d=3 (L=30,d=10)':(1,100,.30,.10,0)}
for name,o in js['sol']:
    I,N,L,d,z = sc[name]
    B = Bz_biot(I,N,L,d,z)*1e3
    rep(name+' B(z) mT', o['Bz_mT'], B)
    rep(name+' Bideal mT', o['Bid_mT'], MU0*N/L*I*1e3)
    if z==0: rep(name+' Bcentro(cosA) mT', o['Bre_mT'], B)
print("  P3: cosA =", js['sol'][0][1]['cosA'], " B(z=L/2)/B(0) =", js['sol'][1][1]['Bz_mT']/js['sol'][0][1]['Bz_mT'])
print("  largo L=30 d=1: cosA =", js['sol'][3][1]['cosA'], "; extremo/centro =", js['sol'][4][1]['Bz_mT']/js['sol'][3][1]['Bz_mT'])

print("=== INDUCCION ===")
def phi_ref(modo,N,R,B0,f,t,xm):
    A=np.pi*R**2
    if modo=='iman': return N*50e-3*A/(1+xm**2)**1.5
    return N*B0*A*np.sin(2*np.pi*f*t)
ic = {'iman def xm=1.6':('iman',50,.03,20e-3,1,0,1.6),'iman xm=0.3':('iman',50,.03,20e-3,1,0,.3),
 'iman xm=5.3':('iman',50,.03,20e-3,1,0,5.3),'B def t=0':('B',50,.03,20e-3,1,0,0),
 'B t=0.25 (pico Phi)':('B',50,.03,20e-3,1,.25,0),'B f=2 t=0':('B',50,.03,20e-3,2,0,0),
 'B N=1 R=0.1 B0=1T f=60 t=0':('B',1,.1,1,60,0,0)}
for name,o in js['ind']:
    args=ic[name]
    rep(name+' Phi', o['phi'], phi_ref(*args))
    if o['fem'] is not None:
        # derivada numérica central de -dPhi/dt (Phi ya incluye N)
        m,N,R,B0,f,t,xm=args; h=1e-7
        femref = -(phi_ref(m,N,R,B0,f,t+h,xm)-phi_ref(m,N,R,B0,f,t-h,xm))/(2*h)
        rep(name+' FEM', o['fem'], femref)
# Verificar que el modelo "dipolar" Phi ∝ (1+x²/R²)^-3/2 corresponde a un dipolo en el eje
# Para un dipolo m en el eje, flujo a través de un disco de radio R a distancia x: Phi = μ0 m R² / (2 (R²+x²)^{3/2})  → ∝ (1+(x/R)²)^{-3/2}. OK.
print("  dipolo: Phi(x)/Phi(0) = (1+(x/R)^2)^-1.5 : es la forma exacta del flujo de un dipolo puntual a través de un disco coaxial (Griffiths Prob. 7.? / cálculo directo).")

print("=== RC ===")
def rc_ref(R,C,f,Vp):
    w=2*np.pi*f; Zc=R+1/(1j*w*C); I=Vp/Zc
    return dict(Xc=1/(w*C),Z=abs(Zc),phi_deg=np.degrees(np.angle(I)),Ip=abs(I),VRp=abs(I*R),VCp=abs(I/(1j*w*C)),dt=np.angle(I)/w)
rcc={'def':(1000,100e-9,1000,3),'f=100 R=100 C=1000nF':(100,1000e-9,100,1),'f=10k R=10k C=10nF':(10000,10e-9,10000,5),
 'f=fc (1591.55)':(1000,100e-9,1/(2*np.pi*1000*100e-9),3),'R=100 C=10nF f=100 (phi~90)':(100,10e-9,100,3),
 'R=10k C=1000nF f=10k (phi~0)':(10000,1000e-9,10000,3)}
for name,o in js['rc']:
    r=rc_ref(*rcc[name])
    for k in ('Xc','Z','phi_deg','Ip','VRp','VCp','dt'): rep(f'{name} {k}', o[k], r[k])
    print(f"     KVL err={o['kvl_err']:.2e}  marcador Δt: fracción ancho={o['bracket_frac_of_width']:.4f} vs Δt/(2.5T)={o['dt_frac_of_width']:.4f}")
