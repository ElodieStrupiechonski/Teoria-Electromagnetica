#!/usr/bin/env python3
"""Auditoría UX automatizada de los exploradores EM con Playwright.
Uso: python3 audit.py [pagina.html ...]   (sin args: todas)
Salida: ux/out/<pagina>.json, capturas en ux/shots/"""
import json, os, re, sys, time
from playwright.sync_api import sync_playwright

SITE = "/tmp/tem"
OUT = os.path.dirname(os.path.abspath(__file__))
SHOTS = os.path.join(OUT, "shots"); os.makedirs(SHOTS, exist_ok=True)
JOUT = os.path.join(OUT, "out"); os.makedirs(JOUT, exist_ok=True)

PAGES = ["index.html"] + sorted(f for f in os.listdir(SITE) if f.endswith(".html") and f != "index.html")
if len(sys.argv) > 1: PAGES = sys.argv[1:]

VIEWPORTS = {"desktop": (1280, 800, False), "mobile": (390, 844, True), "narrow390": (390, 844, False)}
BAD_RE = re.compile(r"\bNaN\b|Infinity|undefined|\[object", re.I)

JS_CONTROLS = r"""
() => {
  const lab = (el) => {
    if (el.getAttribute('aria-label')) return 'aria:' + el.getAttribute('aria-label');
    if (el.id) { const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`); if (l) return 'for:' + l.innerText.trim(); }
    const a = el.closest('label'); if (a) return 'wrap:' + a.innerText.trim();
    // label previo en el mismo contenedor
    let p = el.previousElementSibling; let n = 0;
    while (p && n < 3) { if (p.tagName === 'LABEL') return 'prev:' + p.innerText.trim(); p = p.previousElementSibling; n++; }
    const pp = el.parentElement && el.parentElement.querySelector('label');
    if (pp) return 'near:' + pp.innerText.trim();
    return '';
  };
  const vis = (el) => { const r = el.getBoundingClientRect(); const cs = getComputedStyle(el); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; };
  const out = [];
  let i = 0;
  document.querySelectorAll('input, select, button, textarea').forEach(el => {
    if (el.closest('.nvbar')) return;
    if (!el.dataset.uxid) el.dataset.uxid = 'c' + (i++);
    const o = { ux: el.dataset.uxid, tag: el.tagName.toLowerCase(), type: el.type || '', id: el.id || '', name: el.name || '',
      label: lab(el), min: el.min, max: el.max, step: el.step, value: el.value, checked: el.checked, visible: vis(el),
      text: (el.tagName === 'BUTTON' ? el.innerText.trim() : ''), disabled: el.disabled, tabindex: el.tabIndex };
    if (el.tagName === 'SELECT') o.options = [...el.options].map(x => x.value + '|' + x.text.trim());
    out.push(o);
  });
  return out;
}
"""

JS_OUTPUTS = r"""
() => {
  // nodos "hoja" con texto, fuera de la barra de nav e inputs: se usan para detectar cambios y valores raros
  const res = {};
  const all = document.body.querySelectorAll('*');
  let k = 0;
  for (const el of all) {
    if (el.closest('.nvbar, script, style, .visitas')) continue;
    if (['SCRIPT','STYLE','INPUT','SELECT','OPTION','TEXTAREA','CANVAS','SVG','BUTTON','LABEL','SUMMARY'].includes(el.tagName)) continue;
    if (el.children.length === 0 || [...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim())) {
      const t = (el.innerText || el.textContent || '').trim();
      if (!t || t.length > 400) continue;
      let key; if (el.id) key = '#' + el.id; else { const parts = []; let e = el; while (e && e !== document.body && !e.id) { const par = e.parentElement; const idx = par ? [...par.children].indexOf(e) : 0; parts.unshift(e.tagName.toLowerCase() + ':' + idx); e = par; } key = (e && e.id ? '#' + e.id + '>' : '') + parts.join('>'); }
      res[key] = t;
    }
  }
  return res;
}
"""

JS_LAYOUT = r"""
() => {
  const W = window.innerWidth, H = window.innerHeight;
  const r = { scrollWidth: document.documentElement.scrollWidth, innerWidth: W, overflowX: document.documentElement.scrollWidth > W + 1, overflowEls: [], clipped: [], minFont: null, minFontEl: '', smallFonts: [], canvases: [] };
  const desc = (el) => el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') + (el.className && typeof el.className === 'string' && el.className ? '.' + el.className.trim().split(/\s+/).join('.') : '');
  const all = document.body.querySelectorAll('*');
  for (const el of all) {
    if (el.closest('.nvbar, .visitas, .nv-menu')) continue;
    const cs = getComputedStyle(el); if (cs.display === 'none' || cs.visibility === 'hidden') continue;
    const b = el.getBoundingClientRect(); if (b.width === 0 && b.height === 0) continue;
    if (b.right > W + 2 && b.width > 0) r.overflowEls.push({ el: desc(el), right: Math.round(b.right), w: Math.round(b.width) });
    // texto recortado: overflow no visible y scrollWidth mayor al cliente
    if (cs.overflowX !== 'visible' && el.scrollWidth > el.clientWidth + 2 && !['HTML','BODY'].includes(el.tagName) && el.tagName !== 'CANVAS') {
      const txt = (el.innerText || '').trim().slice(0, 80);
      r.clipped.push({ el: desc(el), sw: el.scrollWidth, cw: el.clientWidth, overflow: cs.overflowX, teo: cs.textOverflow, txt });
    }
    const hasText = [...el.childNodes].some(n => n.nodeType === 3 && n.textContent.trim());
    if (hasText) {
      const fs = parseFloat(cs.fontSize);
      if (r.minFont === null || fs < r.minFont) { r.minFont = fs; r.minFontEl = desc(el) + ' «' + (el.textContent.trim().slice(0, 40)) + '»'; }
      if (fs < 11) r.smallFonts.push({ el: desc(el), fs, txt: el.textContent.trim().slice(0, 50) });
    }
    if (el.tagName === 'CANVAS') r.canvases.push({ el: desc(el), w: Math.round(b.width), h: Math.round(b.height), attrW: el.width, attrH: el.height, aria: el.getAttribute('aria-label') || '', role: el.getAttribute('role') || '', fallback: el.textContent.trim().slice(0, 80), x: Math.round(b.x), y: Math.round(b.y) });
  }
  r.smallFonts = r.smallFonts.slice(0, 15); r.overflowEls = r.overflowEls.slice(0, 20); r.clipped = r.clipped.slice(0, 20);
  // solapes entre "tiles"/.inbox/.tile/.ctrl hijos directos del mismo contenedor
  r.overlaps = [];
  const cands = [...document.body.querySelectorAll('.tile, .inbox, .btn, button, input, label, .kv, .status, canvas, h1, h2, h3, p, .eq')].filter(e => !e.closest('.nvbar, .nv-menu'));
  const boxes = cands.map(e => ({ e, b: e.getBoundingClientRect() })).filter(x => x.b.width > 0 && x.b.height > 0);
  for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
    const A = boxes[i], B = boxes[j];
    if (A.e.contains(B.e) || B.e.contains(A.e)) continue;
    const ox = Math.min(A.b.right, B.b.right) - Math.max(A.b.left, B.b.left);
    const oy = Math.min(A.b.bottom, B.b.bottom) - Math.max(A.b.top, B.b.top);
    if (ox > 4 && oy > 4) { r.overlaps.push({ a: desc(A.e), b: desc(B.e), ox: Math.round(ox), oy: Math.round(oy) }); if (r.overlaps.length > 15) break; }
  }
  return r;
}
"""

JS_A11Y = r"""
() => {
  const r = { inputsNoLabel: [], canvases: [], headings: [], lang: document.documentElement.lang || '', title: document.title, viewportMeta: !!document.querySelector('meta[name=viewport]'), doctype: !!document.doctype, imgsNoAlt: 0 };
  document.querySelectorAll('input, select, textarea').forEach(el => {
    if (el.closest('.nvbar')) return;
    const ok = el.getAttribute('aria-label') || el.getAttribute('aria-labelledby') || el.closest('label') || (el.id && document.querySelector(`label[for="${CSS.escape(el.id)}"]`));
    if (!ok) r.inputsNoLabel.push((el.tagName.toLowerCase()) + (el.type ? '[' + el.type + ']' : '') + (el.id ? '#' + el.id : ''));
  });
  document.querySelectorAll('canvas').forEach(c => r.canvases.push({ id: c.id, aria: c.getAttribute('aria-label') || '', role: c.getAttribute('role') || '', fallbackText: c.textContent.trim().slice(0, 60) }));
  document.querySelectorAll('h1,h2,h3').forEach(h => r.headings.push(h.tagName + ': ' + h.innerText.trim().slice(0, 80)));
  document.querySelectorAll('img').forEach(i => { if (!i.alt) r.imgsNoAlt++; });
  r.fontFamilyBody = getComputedStyle(document.body).fontFamily;
  r.fontFamilyH1 = document.querySelector('h1') ? getComputedStyle(document.querySelector('h1')).fontFamily : '';
  r.fontsLoaded = [...document.fonts].filter(f => f.status === 'loaded').map(f => f.family);
  r.navLinks = [...document.querySelectorAll('.nv-menu a')].map(a => a.getAttribute('href'));
  const ant = document.getElementById('nv-ant'), sig = document.getElementById('nv-sig');
  r.navAnt = ant ? { href: ant.getAttribute('href'), dis: ant.getAttribute('aria-disabled') } : null;
  r.navSig = sig ? { href: sig.getAttribute('href'), dis: sig.getAttribute('aria-disabled') } : null;
  r.navAqui = (document.getElementById('nv-aqui-bar') || {}).innerText || '';
  r.pageLinks = [...document.querySelectorAll('a[href]')].map(a => a.getAttribute('href')).filter(h => h && !h.startsWith('http') && !h.startsWith('#') && !h.startsWith('mailto'));
  return r;
}
"""

def set_value(page, ux, val, kind):
    return page.evaluate("""([ux, val, kind]) => {
      const el = document.querySelector(`[data-uxid="${ux}"]`); if (!el) return 'noel';
      if (kind === 'checkbox') { el.checked = val; el.dispatchEvent(new Event('input', {bubbles:true})); el.dispatchEvent(new Event('change', {bubbles:true})); return el.checked; }
      el.value = String(val);
      el.dispatchEvent(new Event('input', {bubbles:true})); el.dispatchEvent(new Event('change', {bubbles:true}));
      if (el.tagName === 'INPUT' && el.type !== 'range') { el.dispatchEvent(new KeyboardEvent('keyup', {bubbles:true, key:'0'})); el.dispatchEvent(new Event('blur', {bubbles:true})); }
      return el.value;
    }""", [ux, val, kind])

def mid(a, b):
    try: return (float(a) + float(b)) / 2
    except: return None

def candidates(c):
    t = c["type"]
    if c["tag"] == "select": return [("opt:" + o.split("|")[0], o.split("|")[0]) for o in c.get("options", [])]
    if t == "checkbox": return [("toggle", not c["checked"]), ("restore", c["checked"])]
    if t == "range":
        mn, mx = c["min"] or "0", c["max"] or "100"
        return [("min", mn), ("max", mx), ("mid", mid(mn, mx)), ("0", 0)]
    if t in ("number", "text", ""):
        mn, mx = c["min"], c["max"]
        vals = []
        if mn != "": vals.append(("min", mn))
        if mx != "": vals.append(("max", mx))
        if mn != "" and mx != "": vals.append(("mid", mid(mn, mx)))
        vals += [("0", 0), ("neg", -5), ("vacío", ""), ("1e9", 1e9), ("1e-9", 1e-9)]
        return vals
    return []

def run_page(pw, fname):
    rep = {"page": fname, "viewports": {}}
    url = "file://" + os.path.join(SITE, fname)
    for vname, (w, h, ismob) in VIEWPORTS.items():
        browser = pw.chromium.launch()
        ctx = browser.new_context(viewport={"width": w, "height": h}, device_scale_factor=1,
                                  is_mobile=ismob, has_touch=(w < 500), locale="es-MX")
        page = ctx.new_page()
        log = []; state = {"step": "carga"}
        page.on("console", lambda m: log.append({"step": state["step"], "kind": "console." + m.type, "text": m.text}) if m.type in ("error", "warning") else None)
        page.on("pageerror", lambda e: log.append({"step": state["step"], "kind": "pageerror", "text": str(e)}))
        page.on("requestfailed", lambda r: log.append({"step": state["step"], "kind": "requestfailed", "text": r.url + " :: " + (r.failure or "")}))
        page.on("dialog", lambda d: (log.append({"step": state["step"], "kind": "dialog", "text": d.message}), d.dismiss()))
        try:
            page.goto(url, wait_until="load", timeout=30000)
        except Exception as e:
            log.append({"step": "carga", "kind": "goto-fail", "text": str(e)})
        page.wait_for_timeout(900)
        v = {"log": log}
        v["a11y"] = page.evaluate(JS_A11Y)
        v["vp"] = page.evaluate("() => ({innerWidth: innerWidth, innerHeight: innerHeight, scale: (visualViewport||{}).scale, docW: document.documentElement.clientWidth})")
        v["controls"] = page.evaluate(JS_CONTROLS)
        v["layout"] = page.evaluate(JS_LAYOUT)
        base_out = page.evaluate(JS_OUTPUTS)
        v["outputs_default"] = base_out
        v["bad_default"] = {k: t for k, t in base_out.items() if BAD_RE.search(t) or t in ("–", "—", "-", "?")}
        if vname == "desktop":
            v["bodyText"] = page.evaluate("() => document.body.innerText")
        page.screenshot(path=os.path.join(SHOTS, f"{fname[:-5]}_{vname}.png"), full_page=True)
        # ---------- fuzz de controles ----------
        fuzz = []
        for c in v["controls"]:
            if c["tag"] == "button" or not c["visible"] and c["type"] not in ("checkbox",): continue
            if c["tag"] == "button": continue
            kind = "checkbox" if c["type"] == "checkbox" else c["type"]
            for lbl, val in candidates(c):
                if val is None: continue
                state["step"] = f"{c['ux']}({c['id'] or c['label']})={lbl}:{val}"
                n0 = len(log)
                try:
                    got = set_value(page, c["ux"], val, kind)
                except Exception as e:
                    got = "EXC " + str(e)
                page.wait_for_timeout(120)
                out = page.evaluate(JS_OUTPUTS)
                changed = [k for k in out if out.get(k) != base_out.get(k)]
                bad = {k: t for k, t in out.items() if BAD_RE.search(t)}
                fuzz.append({"ctrl": c["ux"], "id": c["id"], "label": c["label"], "try": lbl, "val": val, "got": got,
                             "changed": changed[:12], "nchanged": len(changed), "bad": bad, "newlog": log[n0:]})
            # restaurar valor
            try:
                if c["type"] == "checkbox": set_value(page, c["ux"], c["checked"], "checkbox")
                else: set_value(page, c["ux"], c["value"], c["type"])
            except Exception: pass
            page.wait_for_timeout(60)
        v["fuzz"] = fuzz
        # ---------- botones ----------
        btns = []
        for c in v["controls"]:
            if c["tag"] != "button" or not c["visible"]: continue
            state["step"] = f"click {c['ux']} «{c['text']}»"
            n0 = len(log)
            before = page.evaluate(JS_OUTPUTS)
            try:
                page.click(f'[data-uxid="{c["ux"]}"]', timeout=3000)
            except Exception as e:
                btns.append({"ctrl": c["ux"], "text": c["text"], "err": str(e)[:200]}); continue
            page.wait_for_timeout(250)
            after = page.evaluate(JS_OUTPUTS)
            ctrls_after = page.evaluate(JS_CONTROLS)
            cchg = [(a["id"] or a["ux"], a["value"]) for a, b in zip(ctrls_after, v["controls"]) if a["value"] != b["value"] or a["checked"] != b["checked"]]
            changed = [k for k in after if after.get(k) != before.get(k)]
            bad = {k: t for k, t in after.items() if BAD_RE.search(t)}
            btns.append({"ctrl": c["ux"], "text": c["text"], "id": c["id"], "nchanged": len(changed), "changed": changed[:10], "ctrlChanged": cchg[:10], "bad": bad, "newlog": log[n0:], "url": page.url.split("/")[-1]})
            if page.url.split("/")[-1] != fname:  # navegó
                page.goto(url, wait_until="load"); page.wait_for_timeout(500); page.evaluate(JS_CONTROLS)
        v["buttons"] = btns
        # ---------- arrastre en canvas ----------
        page.goto(url, wait_until="load"); page.wait_for_timeout(500); page.evaluate(JS_CONTROLS)
        drags = []
        for cv in page.evaluate(JS_LAYOUT)["canvases"]:
            if cv["w"] < 40 or cv["h"] < 40: continue
            state["step"] = f"drag {cv['el']}"
            n0 = len(log)
            before = page.evaluate(JS_OUTPUTS)
            sel = cv["el"].split(".")[0]
            try:
                el = page.locator(sel).first
                el.scroll_into_view_if_needed(timeout=3000)
                b = el.bounding_box()
                for frac in (0.5, 0.3, 0.7):
                    x0, y0 = b["x"] + b["width"] * frac, b["y"] + b["height"] * frac
                    page.mouse.move(x0, y0); page.mouse.down()
                    for k in range(1, 9): page.mouse.move(x0 + 8 * k, y0 + 3 * k); page.wait_for_timeout(15)
                    page.mouse.up()
                    if vname == "mobile":
                        page.touchscreen.tap(x0, y0)
                page.wait_for_timeout(200)
                after = page.evaluate(JS_OUTPUTS)
                changed = [k for k in after if after.get(k) != before.get(k)]
                bad = {k: t for k, t in after.items() if BAD_RE.search(t)}
                drags.append({"canvas": cv["el"], "nchanged": len(changed), "changed": changed[:10], "bad": bad, "newlog": log[n0:]})
            except Exception as e:
                drags.append({"canvas": cv["el"], "err": str(e)[:200]})
        v["drags"] = drags
        # ---------- teclado y navegación ----------
        page.goto(url, wait_until="load"); page.wait_for_timeout(400)
        nav = {}
        state["step"] = "nav"
        try:
            page.click("#nvdet summary", timeout=3000); page.wait_for_timeout(200)
            nav["menuOpen"] = page.evaluate("() => document.getElementById('nvdet').open")
            nav["menuBox"] = page.evaluate("() => { const m=document.querySelector('.nv-menu'); const b=m.getBoundingClientRect(); return {x:b.x,y:b.y,w:b.width,h:b.height,right:b.right,bottom:b.bottom, W:innerWidth, H:innerHeight}; }")
            page.screenshot(path=os.path.join(SHOTS, f"{fname[:-5]}_{vname}_menu.png"), full_page=False)
            page.keyboard.press("Escape"); page.wait_for_timeout(150)
            nav["escCloses"] = not page.evaluate("() => document.getElementById('nvdet').open")
        except Exception as e:
            nav["menuErr"] = str(e)[:200]
        page.keyboard.press("ArrowRight"); page.wait_for_timeout(600)
        nav["afterRight"] = page.url.split("/")[-1]
        page.goto(url, wait_until="load"); page.wait_for_timeout(300)
        page.keyboard.press("ArrowLeft"); page.wait_for_timeout(600)
        nav["afterLeft"] = page.url.split("/")[-1]
        # ArrowRight con foco en un range: ¿navega o mueve el slider?
        page.goto(url, wait_until="load"); page.wait_for_timeout(300)
        rng = page.locator("input[type=range]").first
        if rng.count() > 0:
            try:
                rng.focus(); v0 = rng.input_value(); page.keyboard.press("ArrowRight"); page.wait_for_timeout(400)
                nav["rightOnRange"] = {"url": page.url.split("/")[-1], "before": v0, "after": rng.input_value() if page.url.split("/")[-1] == fname else "navegó"}
            except Exception as e: nav["rightOnRange"] = str(e)[:100]
        # Tab: recorrido
        page.goto(url, wait_until="load"); page.wait_for_timeout(300)
        seq = []
        for i in range(60):
            page.keyboard.press("Tab")
            d = page.evaluate("() => { const e=document.activeElement; if(!e||e===document.body) return 'body'; return e.tagName.toLowerCase()+(e.id?'#'+e.id:'')+(e.type?'['+e.type+']':'')+(e.className&&typeof e.className==='string'?'.'+e.className.trim().split(/\\s+/)[0]:''); }")
            seq.append(d)
            if i > 5 and d == 'body': break
        nav["tabSeq"] = seq
        nctrl = len([c for c in v["controls"] if c["visible"] and not c["disabled"]])
        nav["tabReached"] = len([s for s in seq if s.startswith(("input", "select", "button")) and ".nv" not in s])
        nav["nControlsVisible"] = nctrl
        v["nav"] = nav
        rep["viewports"][vname] = v
        browser.close()
    return rep

def main():
    with sync_playwright() as pw:
        for f in PAGES:
            t0 = time.time()
            try:
                rep = run_page(pw, f)
            except Exception as e:
                rep = {"page": f, "fatal": str(e)}
            with open(os.path.join(JOUT, f[:-5] + ".json"), "w", encoding="utf-8") as fh:
                json.dump(rep, fh, ensure_ascii=False, indent=1)
            print(f"{f}: {time.time()-t0:.1f}s", flush=True)

if __name__ == "__main__":
    main()
