import numpy as np, json, subprocess
# ---- Snell ----
cases=[dict(n1=1,n2=1.5,t1=40),dict(n1=1.5,n2=1,t1=40),dict(n1=1.5,n2=1,t1=41.8),dict(n1=1.33,n2=1,t1=0),dict(n1=1.5,n2=1.48,t1=89),
       dict(n1=1,n2=1.5,t1=89),dict(n1=1,n2=1,t1=30),dict(n1=1.5,n2=1,t1=41.81)]
js=json.loads(subprocess.check_output(['node','snell_js.js',json.dumps(cases)]))
print("SNELL")
for c,j in zip(cases,js):
    s=c['n1']/c['n2']*np.sin(np.radians(c['t1'])); t2=np.degrees(np.arcsin(s)) if s<=1 else np.nan
    tc=np.degrees(np.arcsin(c['n2']/c['n1'])) if c['n1']>c['n2'] else None; tb=np.degrees(np.arctan(c['n2']/c['n1']))
    print(f"{str(c):36s} t2 js={j['t2']} py={t2:.4f}  tir={j['tir']}  tc js={j['tc']} py={tc}  tb js={j['tb']:.4f} py={tb:.4f}")
    if not np.isnan(t2): assert abs(j['t2']-t2)<1e-9
    assert abs(j['tb']-tb)<1e-9
print("Brewster aire->vidrio 1.5:",np.degrees(np.arctan(1.5)),"; vidrio->aire:",np.degrees(np.arctan(1/1.5)),"; tc 1.5->1:",np.degrees(np.arcsin(1/1.5)),"; fibra 1.50/1.48:",np.degrees(np.arcsin(1.48/1.5)))
# ---- Fresnel ----
def fres(n1,n2,th):
    ti=np.radians(th); st=n1/n2*np.sin(ti)
    ct=np.sqrt(1-st*st+0j)  # para st>1: ct = +j*sqrt(st^2-1) (rama); Ulaby: cos θt = -j sqrt(...) con e^{-jkz}... |r|=1 en cualquier caso
    e1,e2=1/n1,1/n2
    rs=(e2*np.cos(ti)-e1*ct)/(e2*np.cos(ti)+e1*ct)   # Ulaby 8.66a: Γ⊥=(η2 cosθi − η1 cosθt)/(η2 cosθi + η1 cosθt)
    rp=(e2*ct-e1*np.cos(ti))/(e2*ct+e1*np.cos(ti))   # Ulaby 8.67a: Γ∥=(η2 cosθt − η1 cosθi)/(η2 cosθt + η1 cosθi)
    # Griffiths 9.3 (no magn.): r_s = (cosθi - β cosθt... ) using alpha,beta: r_p(Griffiths E par.) = (α−β)/(α+β), α=cosθt/cosθi, β=n2/n1
    a=ct/np.cos(ti); b=n2/n1
    rp_G=(a-b)/(a+b)            # Griffiths 9.109 (E en el plano)
    rs_G=(np.cos(ti)-b*ct)/(np.cos(ti)+b*ct)  # Griffiths prob. 9.17; = Ulaby Γ⊥ para μ=μ0
    # Hecht 4.42/4.43
    rs_H=(n1*np.cos(ti)-n2*ct)/(n1*np.cos(ti)+n2*ct); rp_H=(n2*np.cos(ti)-n1*ct)/(n2*np.cos(ti)+n1*ct)
    # transmitancias
    ts=1+rs; tp=(1+rp)*np.cos(ti)/ct if abs(ct)>0 else np.nan  # Ulaby τ∥=(1+Γ∥) cosθi/cosθt
    Ts=(n2*ct/(n1*np.cos(ti)))*abs(ts)**2 if st<=1 else 0
    Tp=(n2*ct/(n1*np.cos(ti)))*abs(tp)**2 if st<=1 else 0
    return rs,rp,rp_G,rs_G,rs_H,rp_H,Ts,Tp,st
cases=[dict(n1=1,n2=1.52,th=30),dict(n1=1,n2=1.52,th=0),dict(n1=1,n2=1.52,th=56.66),dict(n1=1,n2=1.52,th=89.9),dict(n1=1.52,n2=1,th=30),
       dict(n1=1.52,n2=1,th=41.14),dict(n1=1.52,n2=1,th=60),dict(n1=1,n2=1.52,th=70),dict(n1=2.42,n2=1,th=24),dict(n1=1.33,n2=1,th=45)]
js=json.loads(subprocess.check_output(['node','fresnel_js.js',json.dumps(cases)]))
print("\nFRESNEL")
for c,j in zip(cases,js):
    rs,rp,rpG,rsG,rsH,rpH,Ts,Tp,st=fres(c['n1'],c['n2'],c['th']); r=j['r']
    print(f"{str(c):36s} gs js={r['gs']} py(Ulaby)={np.real(rs):+.4f} Hecht={np.real(rsH):+.4f} | gp js={r['gp']} py(Ulaby)={np.real(rp):+.4f} Griffiths={np.real(rpG):+.4f} Hecht={np.real(rpH):+.4f} | Rs js={r['Rs']:.4f} Rp js={r['Rp']:.4f} | Rs+Ts={abs(rs)**2+Ts:.6f} Rp+Tp={abs(rp)**2+Tp:.6f} tir={r['tir']}")
    if st<=1:
        assert abs(r['gs']-np.real(rs))<1e-9 and abs(r['gp']-np.real(rp))<1e-9
print("Brewster 1->1.52:",np.degrees(np.arctan(1.52)),"; 1.52->1:",np.degrees(np.arctan(1/1.52)),"; tc 1.52->1:",np.degrees(np.arcsin(1/1.52)))
# signo de gp en Brewster: evaluar justo antes y despues
for th in [56,57]:
    rs,rp,*_=fres(1,1.52,th); print(f"th={th}: Γ∥(Ulaby)={np.real(rp):+.4f}")
# fase en TIR
for th in [50,70,89]:
    ti=np.radians(th); st=1.52*np.sin(ti); ct=-1j*np.sqrt(st*st-1)   # Ulaby conv.
    e1,e2=1/1.52,1
    rs=(e2*np.cos(ti)-e1*ct)/(e2*np.cos(ti)+e1*ct); rp=(e2*ct-e1*np.cos(ti))/(e2*ct+e1*np.cos(ti))
    print(f"TIR 1.52->1 th={th}: |Γ⊥|={abs(rs):.6f} fase={np.degrees(np.angle(rs)):.1f}°, |Γ∥|={abs(rp):.6f} fase={np.degrees(np.angle(rp)):.1f}°")
