# Informe de auditoría física — Unidad 3 (Reflexión y refracción de ondas planas)

Archivos auditados (en `/tmp/tem/`, sin modificar): `Reflexion_interactivo.html`, `CapaTresMedios_interactivo.html`, `CapaDielectrica_explorador.html`, `Snell_explorador.html`, `Fresnel_explorador.html`.

Método: el JS de física de cada archivo se extrajo **textualmente** (por rango de líneas, sin reescribirlo) a arneses de `node` (`refl_js.js`, `capa3_js.js`, `capad_js.js`, `snell_js.js`, `fresnel_js.js`) y se comparó con reimplementaciones independientes en Python/numpy (`verify_refl.py`, `verify_capa3.py`, `verify_capad.py`, `verify_snell_fresnel.py`) que usan la fórmula exacta de tres medios por matriz de transferencia (Γ = (r₁₂ + r₂₃e^{−2jφ})/(1 + r₁₂r₂₃e^{−2jφ})) y las fórmulas de Fresnel en las convenciones de Ulaby, Griffiths y Hecht. Todos los scripts están en `/tmp/claude-0/-home-claude/59869150-07f9-5bfd-a971-dafcad5e4df4/scratchpad/u3/`. Convención general del sitio: fasores e^{jωt}, onda incidente e^{−jβz} viajando hacia +z, Γ = (η₂−η₁)/(η₂+η₁) (Ulaby cap. 8; equivalente a Griffiths 9.3 para μ = μ₀).

**Resultado global: no se encontró ningún error de física confirmado en los cinco archivos.** Todos los casos de prueba (48 en total) coinciden con la reimplementación independiente dentro del redondeo de máquina (< 10⁻⁹). Los hallazgos son de tipo ⚠/ℹ (valores de tabla dudosos, aproximaciones no declaradas, inconsistencias cosméticas) y de cobertura pedagógica.

---

## 1. `Reflexion_interactivo.html` — tema 3.2, incidencia normal (P8)

### 1.1 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 129 | η₁ = 377 Ω (constante `ETA1`) | η₀ = √(μ₀/ε₀) = 376.730 Ω (Ulaby 7-?; Griffiths 9.2) | ℹ Aproximación ≈377 declarada en el formulario (l. 116). Γ, τ, S no dependen de η₀ (solo de cocientes); η₂ y η(d) mostradas difieren 0.07 % del valor con 376.73. |
| 133 | r = 1/√εᵣ; Γ = (r−1)/(r+1) ⇔ Γ = (η₂−η₁)/(η₂+η₁) con η₂ = η₁/√εᵣ | Ulaby 8-1 ec. (8.8); Griffiths 9.3.2 (β = n₂/n₁ → Γ = (1−β)/(1+β)) | ✔ |
| 133 | τ = 1 + Γ | Ulaby ec. (8.9) | ✔ |
| 133 | Conductor perfecto: Γ = −1, τ = 0 | Ulaby 8-1.? (η₂ = 0) | ✔ |
| 136 | η₂ = η₁/√εᵣ (0 si conductor) | η = η₀/√εᵣ, medio no magnético y sin pérdidas | ℹ μᵣ = 1 y εᵣ real: aproximación no declarada en pantalla (sí en 3.3). |
| 139–142 | η(d) = η₁ (η₂ cos βd + jη₁ sen βd)/(η₁ cos βd + jη₂ sen βd), con βd = 2π d/λ₁ | Ulaby ec. (8.? ) Z_in(−d) = η₁(η₂ + jη₁ tan β₁d)/(η₁ + jη₂ tan β₁d) (forma idéntica a la línea de transmisión, Ulaby 2-7 / Pozar 2.3) | ✔ (forma cos/sen evita la singularidad de tan en λ/4; devuelve ±j∞ correctamente cuando el denominador → 0) |
| 153 | S = (1+|Γ|)/(1−|Γ|); ∞ si |Γ| ≥ 1 | Ulaby ec. (8.? ) SWR | ✔ |
| 157 | R = |Γ|² (mostrado en %) | Ulaby ec. (8.? ) | ✔ |
| 163, 185, 207 | A(z) = √(1 + Γ² + 2Γ cos 2β₁z) = |1 + Γ e^{2jβ₁z}| | Ulaby ec. (8.13) |Ẽ₁(z)| = |E₀ⁱ| [1 + |Γ|² + 2|Γ| cos(2β₁z + θᵣ)]^{1/2} (con Γ real, θᵣ = 0 o π absorbido en el signo) | ✔ |
| 189 | E₁(z,t) = cos(ωt − β₁z) + Γ cos(ωt + β₁z), z ≤ 0 | Re[(e^{−jβ₁z} + Γe^{jβ₁z}) e^{jωt}] | ✔ |
| 182, 193 | β₂ = β₁√εᵣ; E₂ = τ cos(ωt − β₂z) | λ₂ = λ₁/√εᵣ | ✔ |
| 113 (texto) | T = 1 − |Γ|² | Potencia: 1 = |Γ|² + (η₁/η₂)|τ|² (Ulaby 8-1.3) | ⚠ Correcto como fracción de potencia transmitida, pero **no se muestra la relación con τ**; el estudiante puede inferir T = |τ|², que es falso (véase cobertura). |
| 114 (texto) | d = λ₁/2 → η(d) = η₂; d = λ₁/4 → η(d) = η₁²/η₂; conductor → jη₁ tan β₁d | Ulaby 2-8 (transformador λ/4, línea λ/2, línea en corto) | ✔ (verificado numéricamente) |

### 1.2 Casos de prueba (JS extraído vs. Python independiente, ambos con η₁ = 377 Ω para aislar la fórmula)

| εᵣ | cond. | d/λ₁ | Γ (JS) | Γ (Py) | η(d) JS (Ω) | η(d) Py (Ω) | A(−d) JS | A(−d) Py | 1−|Γ|²−(η₁/η₂)|τ|² |
|---|---|---|---|---|---|---|---|---|---|
| 4 (defecto) | no | 0.25 | −0.3333 | −0.3333 | 754.0 | 754.0 | 1.3333 | 1.3333 | −2e−16 |
| 4 | no | 0.5 | −0.3333 | −0.3333 | 188.5 | 188.5 | 0.6667 | 0.6667 | −2e−16 |
| 1 (adaptado) | no | 0.3 | 0 | 0 | 377 | 377 | 1.0000 | 1.0000 | 0 |
| 16 (máx. slider) | no | 0 | −0.6 | −0.6 | 94.25 | 94.25 | 0.4000 | 0.4000 | −1e−16 |
| 16 | no | 2.0 (máx.) | −0.6 | −0.6 | 94.25 | 94.25 | 0.4000 | 0.4000 | −1e−16 |
| 2.5 | no | 0.125 | −0.2251 | −0.2251 | 340.6 + j161.6 | 340.6 + j161.6 | 1.0250 | 1.0250 | 0 |
| — | sí | 0.25 | −1 | −1 | ±j∞ | ∞ | 2.0000 | 2.0000 | 0 |
| — | sí | 0.1 | −1 | −1 | j273.9 | j273.9 (= j377 tan 36°) | 1.1756 | 1.1756 | 0 |
| — | sí | 0.5 | −1 | −1 | 0 | 0 | 0 | 0 | 0 |
| 9 | no | 0.75 | −0.5 | −0.5 | 1131 | 1131 (= η₁²/η₂) | 1.5 | 1.5 | 0 |

Diferencia relativa JS–Py: < 10⁻¹² en todos los casos. Coherencia interna comprobada: en d = λ₁/4 (Γ<0) A = 1+|Γ| (máximo) y η(d) = η₁²/η₂ = 754 Ω; en d = λ₁/2 A = 1−|Γ| (mínimo) y η(d) = η₂; S = 2 y 4 para εᵣ = 4 y 16 (= A_max/A_min). Posición de máximos: con Γ<0, θᵣ = π ⇒ z_max = −(π+2nπ)/(2β₁) = −λ₁/4 − nλ₁/2, que es lo que dibuja la envolvente.

### 1.3 Cobertura del tema 3.2 y hallazgos pedagógicos

- ✔ Cubre Γ, τ, SWR, R, onda estacionaria (envolvente + animación), η(d) en plano móvil, conductor perfecto (P8), casos λ/4 y λ/2.
- ⚠ **Γ > 0 es inalcanzable**: medio 1 fijo en aire y εᵣ₂ ≥ 1 ⇒ Γ ∈ (−1, 0] siempre. El estudiante nunca ve el caso "máximo de |E| en la frontera" (θᵣ = 0, z_max = 0, −λ/2, …), que es exactamente la distinción de Ulaby entre θᵣ = 0 y θᵣ = π. Propuesta: permitir εᵣ₁ ≠ 1 o permitir εᵣ₂ < 1 (equivalente a onda saliendo de un dieléctrico), o un botón "intercambiar medios".
- ⚠ **Conservación de potencia incompleta**: se muestra T = 1−|Γ|² pero no 1 = |Γ|² + (η₁/η₂)|τ|². Con εᵣ = 4: |τ|² = 0.444 y (η₁/η₂)|τ|² = 0.889 = 1 − 0.111 ✔; mostrar este cálculo evitaría el error frecuente T = |τ|².
- ℹ No se muestra la fórmula explícita de posición de máximos/mínimos (l_max = (θᵣ + 2nπ)λ₁/(4π), l_min = l_max + λ₁/4) que sí pide el programa; la envolvente lo muestra solo gráficamente. Tampoco la onda estacionaria de H (mínimos de E = máximos de H), útil para P8.
- ℹ No cubre medio 2 con pérdidas ni buen conductor con σ finita (η₂ compleja, Γ complejo, θᵣ ≠ 0, π). El índice dice "dieléctrico/conductor": solo está el límite ideal. Juicio: aceptable para un explorador, pero conviene indicarlo en el texto.
- ℹ Cosmético: la etiqueta del lienzo dice "η₁ = 377 Ω" (l. 180) mientras el formulario dice 376.73 ≈ 377; coherente. En anchuras pequeñas (W = 320 px, xb = 147 px) el plano con d > 1.67 λ₁ sale del lienzo pero las cifras siguen actualizándose (no es error).

---

## 2. `CapaTresMedios_interactivo.html` — tema 3.3, capa entre dos medios (interfaz móvil en z = −d)

### 2.1 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 130–131 | η₀ = 377; tabla de **n** (no εᵣ); ηᵢ = η₀/nᵢ (l. 140) | η = η₀/n para μᵣ = 1 (Griffiths 9.3; Ulaby 8-?) | ✔ Usa n de forma consistente en impedancias, longitudes de onda y fases. |
| 143–144 | η(d) = η₂ (η₃ cos β₂d + jη₂ sen β₂d)/(η₂ cos β₂d + jη₃ sen β₂d), β₂d = 2π d/λ₂ | Transformación de impedancia (Ulaby 2-7 / 8-?; Pozar 2.3) | ✔ |
| 145 | Γ_in = (η(d) − η₁)/(η(d) + η₁) | Ulaby | ✔ (coincide con la fórmula exacta de tres medios, véase 2.2) |
| 146 | r₂₃ = (η₃ − η₂)/(η₃ + η₂) | Ulaby | ✔ |
| 149–152 | A = (1+Γ_in)/(e^{jβ₂d} + r₂₃e^{−jβ₂d}); τ₃ = A(1 + r₂₃) | Continuidad de E en z = −d con E₂ = A[e^{−jβ₂z} + r₂₃e^{jβ₂z}] y E₃ = A(1+r₂₃)e^{−jβ₃z}; continuidad de H garantizada por la construcción con impedancias | ✔ (verificado: |τ₃| coincide con la matriz de transferencia y |Γ|² + (n₃/n₁)|τ₃|² = 1 en todos los casos) |
| 148 | `den=[cos+r23 cos,0]` | — | ℹ Código muerto (placeholder sobrescrito en l. 150); inocuo. |
| 205, 213 | λ₂ = λ₀/n₂ en píxeles; β₁,₂,₃ = 2πnᵢ/λ₀ | λᵢ = λ₀/nᵢ | ✔ Espesor d/λ₂ coherente entre slider, etiqueta, dibujo y física. |
| 234–235 | E₁ = e^{−jβ₁(z+d)} + Γ_in e^{jβ₁(z+d)} | Referencia de fase en z = −d | ✔ |
| 195–196 | S = (1+|Γ|)/(1−|Γ|); T = 1 − |Γ|² ("Potencia transmitida") | Sin pérdidas: fracción transmitida a medio 3 = 1 − R | ✔ |
| 197 | |Γ₁₃|² = ((η₃−η₁)/(η₃+η₁))² referencia sin capa | ✔ | ✔ |
| 116 (texto) | d = λ₂/2 → η(d) = η₃; d = λ₂/4 → η(d) = η₂²/η₃ | Ulaby 2-8 | ✔ |
| 131 | Tabla: Aire 1.00, Agua 1.33, MgF₂ 1.38, **Teflón 1.44**, Sílice 1.46, BK7 1.52, Poliestireno 1.59, Zafiro 1.77, ZnS 2.35 | Valores ópticos (visible) salvo teflón | ⚠ Ver 2.3. |

### 2.2 Casos de prueba (JS vs. matriz de transferencia independiente)

| n₁ \| n₂ \| n₃ | d/λ₂ | |Γ| JS | |Γ| Py | R JS (%) | R Py (%) | R₁₃ (%) | |τ₃| JS | |τ₃| Py | R + (n₃/n₁)|τ₃|² |
|---|---|---|---|---|---|---|---|---|---|
| 1 \| 1.38 \| 1.52 (defecto, AR) | 0.25 | 0.1123 | 0.1123 | 1.260 | 1.260 | 4.258 | 0.8060 | 0.8060 | 1.000000 |
| 1 \| 1.38 \| 1.52 | 0.5 | 0.2063 | 0.2063 | 4.258 | 4.258 | 4.258 | 0.7937 | 0.7937 | 1.000000 |
| 1 \| 1.44 \| 1 (radomo) | 0.5 | 0 | 0 | 0.000 | 0.000 | 0 | 1.0000 | 1.0000 | 1.000000 |
| 1 \| 1.44 \| 1 | 0.25 | 0.3493 | 0.3493 | 12.20 | 12.20 | 0 | 0.9370 | 0.9370 | 1.000000 |
| 1 \| √1.52 \| 1.52 | 0.25 | 0 | 0 | 0.000 | 0.000 | 4.258 | 0.8111 | 0.8111 | 1.000000 |
| 1 \| 1.23 (botón ideal) \| 1.52 | 0.25 | 0.0023 | 0.0023 | 0.0005 | 0.0005 | 4.258 | 0.8111 | 0.8111 | 1.000000 |
| 1.52 \| 1 \| 1.52 | 0.02 (mín.) | 0.0539 | 0.0539 | 0.291 | 0.291 | 0 | 0.9985 | 0.9985 | 1.000000 |
| 1 \| 2.35 \| 1.77 | 1.5 (máx.) | 0.2780 | 0.2780 | 7.727 | 7.727 | 7.727 | 0.7220 | 0.7220 | 1.000000 |
| 1.5 \| 1 \| 1 | 0.3 | 0.2 | 0.2 | 4.000 | 4.000 | 4.000 | 1.2000 | 1.2000 | 1.000000 |
| 1 \| 1.38 \| 1.52 | 0.75 | 0.1123 | 0.1123 | 1.260 | 1.260 | 4.258 | 0.8060 | 0.8060 | 1.000000 |

Diferencia relativa < 10⁻⁹. Comprobaciones de las afirmaciones del texto: "radomo aire|teflón|aire con λ₂/2 → la capa desaparece" ✔ (R = 0 exacto); "MgF₂ λ/4 sobre vidrio: compara con el 4 %" → 1.26 % vs 4.26 % ✔ (valor clásico ≈1.3 %, Hecht, Optics, sec. 9.7 películas delgadas); "con n₂ ideal el mínimo baja a cero exacto" → el botón redondea a 2 decimales (1.23 en vez de 1.2329), R = 0.0005 % que se muestra como "0.00 %" en verde ✔ (no exacto pero indistinguible en pantalla).

### 2.3 Hallazgos

- ⚠ **Teflón n = 1.44 es el valor de microondas** (εᵣ ≈ 2.1 ⇒ n = 1.449), mientras que el resto de la tabla (agua 1.33, MgF₂ 1.38, BK7 1.52, zafiro 1.77, ZnS 2.35) son valores **ópticos** (visible). El PTFE en el visible tiene n ≈ 1.35–1.38 (valores tabulados habituales); el agua en microondas tiene n ≈ 9. La mezcla de regímenes en una sola tabla sin indicar la frecuencia es dudosa; para el ejemplo del radomo (aplicación de microondas) 1.44 es el valor correcto, pero entonces "agua 1.33" no lo es. Corrección propuesta: añadir en el nombre el régimen ("Teflón (microondas, εᵣ 2.1)") o separar la tabla por régimen; o usar n ≈ 1.35 con la etiqueta "óptico". Esta misma tabla aparece en `Fresnel_explorador.html` l. 111.
- ℹ El HTML inicial (l. 89) pone n₃ = 1.50 / η₃ = 251 Ω pero el JS (l. 177) lo sobrescribe a 1.52 (BK7) al cargar. Sin efecto en el usuario, pero el texto "el 4 % del vidrio" corresponde a n = 1.5 (4.00 %) y no a 1.52 (4.26 %, lo que muestra la tesela). Sugerencia: "≈4 %".
- ℹ Rango mínimo d/λ₂ = 0.02: no se puede llegar a d = 0 (capa inexistente); la tesela |Γ₁₃|² suple esa referencia. Correcto por diseño.
- ℹ Aproximaciones no declaradas en pantalla: sin pérdidas, μᵣ = 1, incidencia normal, materiales no dispersivos (n fijo mientras se varía d/λ₂; en realidad al cambiar d a f fija se cambia d/λ₂, pero al cambiar f, n cambia también).
- Cobertura 3.3: ✔ impedancia transformada, Γ total, λ/2 y λ/4, condición η₂ = √(η₁η₃), campo dentro de la capa (ondas múltiples resueltas de forma exacta). No cubre: respuesta en frecuencia (ancho de banda del λ/4 — lo da el otro explorador vía d/λ₂), capas con pérdidas, ni la interpretación por suma de reflexiones múltiples (Hecht 9.7) que es la forma alternativa de obtener el mismo Γ.

---

## 3. `CapaDielectrica_explorador.html` — tema 3.3, |Γ|² contra d/λ₂

### 3.1 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 121 | η₀ = 376.73 Ω; c = 2.998×10⁸ m/s | CODATA: 376.730 Ω; 2.99792×10⁸ m/s | ✔ |
| 133 | ηᵢ = η₀/√εᵣᵢ | μᵣ = 1 (declarado en l. 109) | ✔ |
| 134–139 | η(d) = η₂ (η₃c + jη₂s)/(η₂c + jη₃s), c, s = cos, sen(2π d/λ₂) | Ulaby 2-7 / 8-? | ✔ (la división por `den` = η₂²c² + η₃²s² nunca es 0 para η₂, η₃ > 0) |
| 141–146 | |Γ| = |(η(d) − η₁)/(η(d) + η₁)| | Ulaby | ✔ |
| 207–212 | Curva R(d/λ₂) = |Γ|², 0 ≤ d/λ₂ ≤ 1, 401 puntos | — | ✔ Marcas λ₂/4, λ₂/2, 3λ₂/4 en las posiciones correctas |
| 230–231 | λ₂ = c/(f√εᵣ₂); d_fís = (d/λ₂)·λ₂ en mm | λ = c/(f n) | ✔ (f en GHz → ×10⁹, mm → ×10³ correctos) |
| 263 | εᵣ₂ ideal = round(√(εᵣ₁εᵣ₃), 1 decimal) | η₂ = √(η₁η₃) ⇔ εᵣ₂ = √(εᵣ₁εᵣ₃) | ✔ (el texto l. 109 lo enuncia correctamente). Con 1\|?\|10 redondea a 3.2 (exacto 3.162): R(λ/4) = 0.0035 %, se muestra "0.00 %". ℹ |
| 264–265 | Presets radomo 1\|4\|1 λ/2; antirreflejante 1\|2\|4 λ/4 | ✔ R = 0 en ambos | ✔ |
| 108 (texto) | λ₂/2 → η = η₃; λ₂/4 → η = η₂²/η₃ | ✔ | ✔ |

### 3.2 Casos de prueba (JS vs. fórmula exacta de tres medios)

| εᵣ₁ \| εᵣ₂ \| εᵣ₃ | d/λ₂ | f (GHz) | |Γ| JS | |Γ| Py | R JS (%) | R Py (%) | d mm JS | d mm Py |
|---|---|---|---|---|---|---|---|---|
| 1 \| 4 \| 16 (defecto) | 0.25 | 10 | 0 | 0 | 0.000 | 0.000 | 3.748 | 3.748 |
| 1 \| 4 \| 16 | 0.5 | 10 | 0.6 | 0.6 | 36.00 | 36.00 (= Γ₁₃²) | 7.495 | 7.495 |
| 1 \| 4 \| 1 (radomo) | 0.5 | 10 | 0 | 0 | 0.000 | 0.000 | 7.495 | 7.495 |
| 1 \| 4 \| 1 | 0.25 | 10 | 0.6 | 0.6 | 36.00 | 36.00 (η(d) = η₂²/η₃ = 94 Ω) | 3.748 | 3.748 |
| 1 \| 2 \| 4 (AR) | 0.25 | 10 | 0 | 0 | 0.000 | 0.000 | 5.300 | 5.300 |
| 1 \| 2 \| 4 | 0 (mín.) | 1 | 0.3333 | 0.3333 | 11.11 | 11.11 (= Γ₁₃) | 0 | 0 |
| 10 \| 20 \| 20 (máx.) | 1.0 (máx.) | 40 (máx.) | 0.1716 | 0.1716 | 2.944 | 2.944 | 1.676 | 1.676 |
| 1 \| 1 \| 16 | 0.37 | 10 | 0.6 | 0.6 | 36.00 | 36.00 (capa = medio 1) | 11.09 | 11.09 |
| 1 \| 4 \| 16 | 0.75 | 2.5 | 0 | 0 | 0.000 | 0.000 | 44.97 | 44.97 |
| 3 \| 9 \| 1 | 0.125 | 10 | 0.5622 | 0.5622 | 31.61 | 31.61 | 1.249 | 1.249 |

Diferencia relativa < 10⁻⁹. Ceros en λ/4 (+ nλ/2) cuando εᵣ₂ = √(εᵣ₁εᵣ₃) y en λ/2 (+ nλ/2) cuando εᵣ₁ = εᵣ₃: ✔ (coincide con el transformador λ/4 de Ulaby 2-8 y con el tratamiento de películas delgadas de Hecht 9.7; Griffiths 9.3 no trata el caso de tres medios en el texto, solo en problemas al final del capítulo).

### 3.3 Hallazgos

- ✔ Declara explícitamente "medios sin pérdidas, μᵣ = 1" (l. 109) — buena práctica que falta en los otros dos exploradores de 3.2/3.3.
- ℹ El control de frecuencia solo afecta a "d físico"; la curva está en d/λ₂, así que f no cambia nada visible salvo la tesela. Es correcto pero puede confundir: sugerir un comentario "la curva es universal en d/λ₂; f solo fija el espesor físico". Alternativa pedagógica: segunda curva R(f) a d fijo (ancho de banda del adaptador λ/4).
- ℹ εᵣ ideal redondeado a 0.1 decimal: el texto dice "la reflexión se anula" y la tesela muestra 0.00 % (verde) aunque sea 0.0035 %. Indistinguible en pantalla.
- ℹ Eje y etiquetado "potencia reflejada R = |Γ|²" en %, eje x "d/λ₂": correctos. Tesela "η(d) = R + jX": correcta. "S.W.R. en el medio 1": correcta.
- Cobertura 3.3: ✔ completa para la condición antirreflejante y radomo. No cubre incidencia oblicua sobre la capa (espesor efectivo d cos θ₂) ni pérdidas.

---

## 4. `Snell_explorador.html` — temas 3.5–3.8, ley de Snell, θ_c, θ_B (P10, P11)

### 4.1 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 142–143 | sen θ₂ = (n₁/n₂) sen θ₁; TIR si sen θ₂ > 1 | Snell, Griffiths 9.3.3 ec. (9.100); Ulaby 8-? | ✔ |
| 137–140 | Rayo incidente desde arriba-izquierda a θ₁ de la normal; reflejado a +θ₁ | Ley de reflexión θᵣ = θᵢ | ✔ |
| 143 | Rayo refractado a θ₂ del lado opuesto de la normal, hacia abajo | ✔ | ✔ |
| 153 | θ_c = arcsen(n₂/n₁) solo si n₁ > n₂; "no aplica" si no | Ulaby ec. (8.? ) | ✔ (n₁ = n₂ da "no aplica"; estrictamente θ_c = 90°, irrelevante) |
| 154 | θ_B = arctan(n₂/n₁) | Griffiths 9.3.3 ec. (9.112); Ulaby ec. (8.? ) para medios no magnéticos | ✔ (ℹ válida solo para μ₁ = μ₂; no se declara pero el formulario l. 108 dice "medio no magnético") |
| 108 | n = c/v = √εᵣ (no magnético) | ✔ | ✔ |
| 109 | c = 2.998×10⁸ m/s (solo texto) | ✔ | ✔ |
| 157–159 | Ventana de estado: TIR / Brewster (|θ₁ − θ_B| < 1.2°) / refracción normal | — | ✔ |
| 79, 172 | θ₁ ∈ [0, 89°], paso 1° (slider); decimales por teclado | — | ℹ Con paso 1° el slider rara vez cae exactamente en θ_c o θ_B; el teclado lo permite. |

### 4.2 Casos de prueba

| n₁ → n₂ | θ₁ | θ₂ JS | θ₂ Py | θ_c JS | θ_c Py | θ_B JS | θ_B Py |
|---|---|---|---|---|---|---|---|
| 1 → 1.5 (defecto) | 40° | 25.374° | 25.374° | no aplica | — | 56.310° | 56.310° |
| 1.5 → 1 | 40° | 74.619° | 74.619° | 41.810° | 41.810° | 33.690° | 33.690° |
| 1.5 → 1 | 41.8° | 88.850° | 88.850° | 41.810° | 41.810° | 33.690° | 33.690° |
| 1.5 → 1 | 41.81° | 89.799° | 89.799° | 41.810° | — | — | — |
| 1.33 → 1 | 0° | 0° | 0° | 48.753° | 48.753° | 36.939° | 36.939° |
| 1.50 → 1.48 (fibra) | 89° | TIR | TIR (sen θ₂ = 1.013) | 80.633° | 80.633° | 44.616° | 44.616° |
| 1 → 1.5 | 89° (máx.) | 41.803° | 41.803° | no aplica | — | 56.310° | 56.310° |
| 1 → 1 | 30° | 30° | 30° | no aplica | — | 45° | 45° |

Diferencia relativa < 10⁻¹². Comportamiento con n₁ < n₂ (sin ángulo crítico): correcto, θ₂ < θ₁ siempre y θ₂ → arcsen(n₁/n₂) en incidencia rasante.

### 4.3 Hallazgos y cobertura (3.5–3.8)

- ✔ Snell, ángulo crítico, Brewster (valor), reflexión total, trazado de rayos, presets de P10/P11.
- ⚠ Cobertura parcial de 3.6–3.8: el explorador muestra θ_B pero **no explica por qué** (R∥ = 0) ni que solo ocurre para la polarización ∥ en medios no magnéticos; eso queda para `Fresnel_explorador.html`, lo cual es razonable si ambos se usan juntos. El eyebrow dice "temas 3.5 a 3.8" y debería decir 3.5 (y referir 3.6–3.8 al explorador de Fresnel).
- ℹ No se muestra la onda evanescente ni la profundidad de penetración en TIR, ni el cambio de longitud de onda entre medios (solo rayos). No hay corrimiento de fase en TIR ni Goos–Hänchen (fuera de alcance de licenciatura, juicio).
- ℹ El preset "fibra óptica" (1.50/1.48) muestra θ_c = 80.6° pero no el concepto de ángulo de aceptación/apertura numérica, que es lo que P11 probablemente mide. Sugerencia: tesela NA = √(n₁² − n₂²) = 0.244.
- ℹ El tono azul del medio 2 (l. 130) se oscurece solo si n₂ > n₁; cuando n₁ > n₂ ambos medios tienen tinte similar: cosmético.

---

## 5. `Fresnel_explorador.html` — temas 3.6–3.8, coeficientes de Fresnel

### 5.1 Convención identificada

El JS (l. 126–127) implementa
Γ⊥ = (η₂ cos θᵢ − η₁ cos θₜ)/(η₂ cos θᵢ + η₁ cos θₜ), Γ∥ = (η₂ cos θₜ − η₁ cos θᵢ)/(η₂ cos θₜ + η₁ cos θᵢ),
que son **exactamente Ulaby ecs. (8.66a) y (8.67a)** (6e, sec. 8-? "Oblique incidence"), con η = 377/n (medios no magnéticos). Para μ = μ₀ coinciden con Griffiths 9.3.3 ec. (9.109): r∥ = (α − β)/(α + β), α = cos θₜ/cos θᵢ, β = n₂/n₁, y con la r⊥ del problema 9.17 de Griffiths. Verificado numéricamente: Γ∥(JS) = Γ∥(Griffiths) en todos los casos. **Hecht (Optics, 4.6.2, ecs. 4.42–4.43) usa el signo opuesto para r∥**; el explorador NO usa la convención de Hecht. En consecuencia: Γ∥(0°) = Γ⊥(0°) = (η₂−η₁)/(η₂+η₁), como afirma el texto (l. 97) ✔, y Γ∥ pasa de negativo a positivo al cruzar θ_B cuando n₁ < n₂ (verificado: −0.0070 en 56°, +0.0037 en 57°, θ_B = 56.66°) ✔. En incidencia rasante Γ⊥ → −1 y Γ∥ → +1 (en esta convención) ✔.

### 5.2 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia | Veredicto |
|---|---|---|---|
| 123 | sen θₜ = (n₁/n₂) sen θᵢ; η = 377/n | Snell; η₀/n | ✔ (ℹ 377 vs 376.73 irrelevante: solo cocientes) |
| 125–128 | cos θₜ = √(1 − sen²θₜ); Γ⊥, Γ∥ según Ulaby; R = Γ² | Ulaby (8.66)–(8.67); Griffiths (9.109) | ✔ |
| 130–131 | sen θₜ > 1 → R⊥ = R∥ = 1, Γ = NaN, θₜ = NaN | Ulaby 8-?: cos θₜ = −j√(…) ⇒ |Γ| = 1 | ✔ para R; ℹ no se calcula el Γ complejo (fase) en TIR |
| 133 | θ_B = arctan(n₂/n₁) | ✔ (solo μ₁ = μ₂) | ✔ |
| 134 | θ_c = arcsen(n₂/n₁) si n₁ > n₂ | ✔ | ✔ |
| 161–165 | Curvas R⊥(θ), R∥(θ), 0–90°, 361 puntos | ✔ | ✔ Eje x "ángulo de incidencia θᵢ" (°), eje y "potencia reflejada R" (%) ✔ |
| 91–93 (texto) | Γ⊥ y Γ∥ escritas en pantalla | Idénticas a las del código | ✔ Coherencia pantalla–código |
| 94–96 (texto) | tan θ_B = n₂/n₁ (R∥ = 0); sen θ_c = n₂/n₁ | ✔ | ✔ |
| 97 (texto) | "En θᵢ = 0 ambas coinciden con R = |(η₂−η₁)/(η₂+η₁)|²; θᵢ → 90°: R → 1; sin pérdidas, μᵣ = 1" | ✔ | ✔ Verificado: 1→1.52, 0°: R = 4.26 % (= explorador de 3.2); 89.9°: R⊥ = 99.4 %, R∥ = 98.6 % |
| 111 | Tabla n: Aire 1.00, Agua 1.33, MgF₂ 1.38, **Teflón 1.44**, Sílice 1.46, BK7 1.52, Zafiro 1.77, Diamante 2.42 | Ópticos salvo teflón | ⚠ Mismo problema que en 2.3 |

### 5.3 Casos de prueba (JS vs. Python; Ulaby = Griffiths para μᵣ = 1; Hecht difiere en el signo de Γ∥)

| n₁ → n₂ | θᵢ | Γ⊥ JS | Γ⊥ Py | Γ∥ JS | Γ∥ Py (Ulaby/Griffiths) | Γ∥ Hecht | R⊥ JS | R∥ JS | R⊥+T⊥ | R∥+T∥ |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 → 1.52 (defecto) | 30° | −0.2474 | −0.2474 | −0.1646 | −0.1646 | +0.1646 | 0.0612 | 0.0271 | 1.000000 | 1.000000 |
| 1 → 1.52 | 0° | −0.2063 | −0.2063 | −0.2063 | −0.2063 | +0.2063 | 0.0426 | 0.0426 | 1.000000 | 1.000000 |
| 1 → 1.52 | 56.66° (θ_B) | −0.3958 | −0.3958 | 7.6e−6 | 0 | 0 | 0.1567 | 0.0000 | 1.000000 | 1.000000 |
| 1 → 1.52 | 89.9° (máx.) | −0.9970 | −0.9970 | +0.9930 | +0.9930 | −0.9930 | 0.9939 | 0.9860 | 1.000000 | 1.000000 |
| 1.52 → 1 | 30° | +0.3389 | +0.3389 | +0.0657 | +0.0657 | −0.0657 | 0.1149 | 0.0043 | 1.000000 | 1.000000 |
| 1.52 → 1 | 41.14° (θ_c) | TIR | +1.0000 | TIR | −0.9998 | — | 1 | 1 | 1 | 1 |
| 1.52 → 1 | 60° | TIR | |Γ| = 1, fase 126.0° (⊥), −24.9° (∥) | TIR | — | — | 1 | 1 | 1 | 1 |
| 1 → 1.52 | 70° | −0.5549 | −0.5549 | +0.2038 | +0.2038 | −0.2038 | 0.3079 | 0.0415 | 1.000000 | 1.000000 |
| 2.42 → 1 (diamante) | 24° | +0.8521 | +0.8521 | −0.3628 | −0.3628 | +0.3628 | 0.7261 | 0.1317 | 1.000000 | 1.000000 |
| 1.33 → 1 (agua) | 45° | +0.4690 | +0.4690 | −0.2200 | −0.2200 | +0.2200 | 0.2200 | 0.0484 | 1.000000 | 1.000000 |

T calculada independientemente con T = (n₂cos θₜ)/(n₁cos θᵢ)|τ|², τ⊥ = 1 + Γ⊥, τ∥ = (1 + Γ∥) cos θᵢ/cos θₜ (Ulaby 8-?): R + T = 1 en todos los casos, lo que confirma la consistencia de los Γ del JS. Diferencia relativa JS–Py < 10⁻⁹. θ_B(1→1.52) = 56.659°, θ_c(1.52→1) = 41.140°: coinciden con las marcas del lienzo.

### 5.4 Hallazgos y cobertura (3.6–3.8)

- ✔ r⊥, r∥, R⊥, R∥, Brewster (R∥ = 0 y cambio de signo), crítico, TIR con R = 1, R = 1 en incidencia rasante, igualdad con incidencia normal, medios no magnéticos declarado.
- ⚠ **No se calculan ni muestran τ⊥, τ∥ ni T⊥, T∥** con el factor (n₂cos θₜ)/(n₁cos θᵢ). El programa 3.6–3.8 incluye normalmente los coeficientes de transmisión y la conservación R + T = 1; aquí el estudiante solo ve R. Corrección propuesta (l. 128): añadir `ts:1+gs, tp:(1+gp)*ci/ct, Ts:(n2*ct)/(n1*ci)*(1+gs)**2, Tp:(n2*ct)/(n1*ci)*((1+gp)*ci/ct)**2` y dos teselas, o al menos la ecuación en el formulario.
- ⚠ **TIR sin fase**: más allá de θ_c el explorador pone Γ = NaN y muestra "|Γ| = 1". Lo correcto (Ulaby 8-?; Griffiths prob. 9.37) es Γ complejo de módulo 1 con cos θₜ = −j√(sen²θₜ − 1): p. ej. 1.52→1, 60°: ∠Γ⊥ = 126.0°, ∠Γ∥ = −24.9°. Para 3.8 (reflexión total) convendría mostrar la fase (es la base de los retardadores de Fresnel y de la fibra). Corrección: implementar `coefs` con aritmética compleja (como ya hace `CapaTresMedios`).
- ℹ No se menciona que no existe Brewster para ⊥ en medios no magnéticos (Γ⊥ nunca se anula si n₁ ≠ n₂), ni el Brewster magnético. Juicio: un renglón en el formulario bastaría.
- ℹ No se indica en pantalla la convención de signo de Γ∥ ("Ulaby/Griffiths, no Hecht"). Dado que el signo cambia de libro a libro y que las teselas muestran Γ con signo, un aviso evitaría confusiones si el estudiante compara con Hecht.
- ℹ La tesela "θₜ (Snell)" muestra "— (reflexión total)" en TIR: correcto. En θᵢ = θ_c exacto el JS cae en la rama `st<=1` con cos θₜ = 0 y da Γ⊥ = +1, Γ∥ = −1: correcto y continuo con la rama TIR.
- ℹ Medios con pérdidas/conductores en incidencia oblicua: no cubiertos (coherente con el declarado "sin pérdidas").

---

## 6. Lista consolidada

### 6.1 Errores confirmados (numéricamente)

**Ninguno.** Las 48 comparaciones JS–Python coinciden a < 10⁻⁹ relativo; todas las afirmaciones cuantitativas de los textos en pantalla (λ/2 transparente, λ/4 antirreflejante con η₂ = √(η₁η₃), R(0°) igual en ambas polarizaciones, R → 1 en rasante, R = 1 en TIR, η(λ/4) = η₁²/η₂, 4 % del vidrio, 1.3 % del MgF₂) se cumplen con los números de los propios exploradores.

### 6.2 Puntos a verificar / corregir (⚠ y ℹ relevantes)

| # | Archivo | Línea | Descripción | Corrección propuesta |
|---|---|---|---|---|
| 1 | CapaTresMedios_interactivo.html; Fresnel_explorador.html | 131; 111 | ⚠ Tabla de n mezcla valores ópticos (agua 1.33, MgF₂ 1.38, BK7 1.52…) con teflón 1.44 (valor de microondas, εᵣ ≈ 2.1; óptico ≈ 1.35–1.38). Sin indicación de frecuencia. | Etiquetar el régimen: `["Teflón (PTFE, óptico)",1.35]` o `["Teflón (microondas, εᵣ≈2.1)",1.45]`, y una nota "valores en el visible salvo indicación". Verificar contra la ficha del fabricante / tablas (valor a confirmar por la autora). |
| 2 | Reflexion_interactivo.html | 80, 83, 133 | ⚠ Γ > 0 inalcanzable (medio 1 = aire fijo, εᵣ₂ ≥ 1); nunca se ve θᵣ = 0 ni máximo en la frontera. | Añadir control εᵣ₁ (o botón "intercambiar medios"): `G=(Math.sqrt(er1/er2)-1)/(Math.sqrt(er1/er2)+1)` con η₁ = η₀/√εᵣ₁; actualizar etiqueta l. 180. |
| 3 | Reflexion_interactivo.html | 113 | ⚠ Muestra T = 1−|Γ|² sin relacionarlo con τ; riesgo de inferir T = |τ|². | Añadir ecuación `1 = |Γ|² + (η₁/η₂)|τ|²` y tesela "(η₁/η₂)|τ|²". |
| 4 | Reflexion_interactivo.html | 114 | ℹ Falta la fórmula explícita de posición de máximos/mínimos del tema 3.2. | Añadir `l_max = (θᵣ + 2nπ)/(2β₁)`, `l_min = l_max + λ₁/4`, con θᵣ = π si Γ<0, 0 si Γ>0. |
| 5 | Fresnel_explorador.html | 128 | ⚠ No hay τ⊥, τ∥, T⊥, T∥ (tema 3.6–3.7). | `ts=1+gs; tp=(1+gp)*ci/ct; Ts=(n2*ct)/(n1*ci)*ts*ts; Tp=(n2*ct)/(n1*ci)*tp*tp;` y mostrar R+T = 1. |
| 6 | Fresnel_explorador.html | 130–131 | ⚠ En TIR se descarta la fase de Γ (tema 3.8). | Calcular con complejos: `ct = -j*sqrt(st²−1)`; Γ⊥ = (η₂cᵢ − η₁ct)/(η₂cᵢ + η₁ct), Γ∥ = (η₂ct − η₁cᵢ)/(η₂ct + η₁cᵢ); mostrar ∠Γ. Ejemplo de control: 1.52→1, 60°: ∠Γ⊥ = +126.0°, ∠Γ∥ = −24.9°. |
| 7 | Fresnel_explorador.html | 91–93 | ℹ No declara la convención de signo de Γ∥ (Ulaby/Griffiths; Hecht usa el signo opuesto). | Nota: "Convención de Ulaby (= Griffiths para μᵣ = 1); en Hecht r∥ tiene signo opuesto, por eso allí r∥(0) = −r⊥(0)". |
| 8 | Snell_explorador.html | 66 | ℹ Eyebrow "temas 3.5 a 3.8" pero el contenido es 3.5 (+ valor de θ_B sin justificar). | "Tema 3.5 (3.6–3.8: ver explorador de Fresnel)". |
| 9 | Snell_explorador.html | 84, 157 | ℹ Preset fibra sin apertura numérica (P11). | Tesela `NA = √(n₁²−n₂²)` = 0.244 para 1.50/1.48; θ_acept = arcsen(NA) = 14.1°. |
| 10 | CapaTresMedios_interactivo.html | 89, 117, 177 | ℹ HTML inicial n₃ = 1.50 pero JS fija 1.52; el texto "4 % del vidrio" corresponde a 1.50 (la tesela muestra 4.26 %). | Poner `value="1.52"` en l. 89 y "≈4 %" en l. 117. |
| 11 | CapaTresMedios_interactivo.html | 148 | ℹ Línea de código muerta (`den` placeholder). | Eliminar. |
| 12 | Reflexion_interactivo.html; CapaTresMedios_interactivo.html | 116; 118 | ℹ Aproximaciones no declaradas en pantalla: sin pérdidas, μᵣ = 1 (CapaDielectrica sí lo declara, l. 109). | Añadir "Medios sin pérdidas, μᵣ = 1" como en CapaDielectrica. |
| 13 | CapaDielectrica_explorador.html | 77–78 | ℹ El control f solo afecta a "d físico"; puede parecer que no hace nada. | Nota "la curva es universal en d/λ₂; f fija el espesor físico" o segunda gráfica R(f) a d fijo. |

### 6.3 Juicios (no verificables numéricamente)

- Las referencias a secciones de Ulaby se dan como "cap. 8" / "2-7, 2-8" porque la numeración exacta de ecuaciones cambia entre ediciones; las de Griffiths (9.3.2, 9.3.3, ecs. 9.100, 9.109, 9.112) corresponden a la 4e. Hecht (Optics) 4.6.2 para Fresnel y 9.7 para películas delgadas. No se citan DOIs.
- La convención de signos de Γ∥ del sitio es consistente entre los cinco exploradores y con los libros base del curso (Ulaby, Griffiths); solo diverge de Hecht/Born–Wolf, lo que es una elección legítima pero debe decirse.
