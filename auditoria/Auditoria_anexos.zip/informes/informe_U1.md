# Informe de auditoría física — Unidad 1 (exploradores interactivos TEM, ENES Juriquilla)

Archivos auditados (en `/tmp/tem`, sin modificar): `CampoGauss_explorador.html`, `Capacitor_explorador.html`, `Solenoide_explorador.html`, `Induccion_explorador.html`, `RC_interactivo.html`.

Método: lectura íntegra del JS de física y de los textos/ecuaciones mostrados; extracción verbatim de las funciones numéricas a `js_u1.js` (ejecutado con `node`, salida en `js_out.json`); reimplementación independiente en Python/numpy/scipy (`verif_u1.py`, constantes CODATA 2018, Biot–Savart por integración numérica `quad`, FEM por derivada numérica central, RC por impedancia compleja) y comparación caso por caso. Scripts y salidas en `/tmp/claude-0/-home-claude/59869150-07f9-5bfd-a971-dafcad5e4df4/scratchpad/u1/`.

Leyenda de veredictos: ✔ correcto · ✘ error confirmado · ⚠ requiere verificación/juicio · ℹ aproximación no declarada.

**Resumen ejecutivo.** Las fórmulas implementadas en los cinco archivos son correctas y reproducen los valores de referencia con error relativo ≤ 2.1×10⁻⁵ (atribuible solo al redondeo de ε₀ a 4 cifras). Se confirman **tres errores de coherencia** (no de fórmula): (1) en `RC_interactivo.html` el corchete "Δt" del osciloscopio mide T−Δt en lugar de Δt; (2) en `Induccion_explorador.html` la magnitud rotulada "Flujo Φ" es en realidad el enlace de flujo NΦ, en contradicción con el formulario "Φ = B·A, FEM = −N dΦ/dt"; (3) en el mismo archivo el texto afirma que la FEM va "90° adelantada" respecto de Φ, cuando −cos(ωt) está 90° **retrasada** respecto de sen(ωt). Además, el sentido horario/antihorario de la corriente de Lenz en modo imán parece invertido respecto de la geometría dibujada (polo N hacia la espira); lo clasifico como ✘ por análisis geométrico, pero recomiendo que la autora lo confirme con el dibujo. El archivo de Solenoide **no contiene datos experimentales numéricos**: el "contenido embebido" de 145 kB (línea 128) es una fotografía JPEG en base64 de la bobina; solo están los parámetros de la bobina de la P3 (d = 6.7 cm, N = 50, L = 4 cm).

---

## 1. `CampoGauss_explorador.html` — tema 1.1 Campo eléctrico, densidad de flujo, ley de Gauss (P1)

### 1.1 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 120 | ε₀ = 8.854×10⁻¹² F/m | CODATA: 8.8541878×10⁻¹² F/m (desv. 2.1×10⁻⁵) | ✔ |
| 128 | Lámina: E = \|σ\|/(2ε₀), independiente de r | Griffiths 4e §2.2.3 Ej. 2.5 (lámina infinita de carga superficial) | ✔ (ℹ: es lámina de carga no conductora; para un conductor E = σ/ε₀, Griffiths §2.5.3, no se aclara) |
| 129 | Carga puntual o r ≥ R: E = \|Q\|/(4πε₀r²) | Griffiths §2.2.3 Ej. 2.2 | ✔ |
| 130 | Esfera uniforme, r < R: E = \|Q\| r/(4πε₀R³) | Griffiths Prob. 2.8 / Ulaby 6e Ej. 4-6 | ✔ |
| 132-136 | Q_enc = Q (punto); Q(r/R)³ si r<R (esfera); nulo (placa) | Ley de Gauss, Griffiths §2.2.1 | ✔ |
| 155-157 | Φ = Q_enc/ε₀, unidades "V·m" | ∮E·dA = Q_enc/ε₀; N·m²/C ≡ V·m | ✔ (con signo de Q; E se muestra en módulo) |
| 150-151 | Placa: "Q_enc = σ·A", "Φ = 2·E·A = σA/ε₀" | Pillbox: 2EA = σA/ε₀ → E=σ/2ε₀ | ✔ (verificado: 2E = 1129.4 V·m/m² = σ/ε₀) |
| 104-108 | Formulario en pantalla | coincide con las líneas 128-130 | ✔ |
| 99, 160 | "E cae como 1/r², el área crece como r²" | correcto | ✔ |
| 263, 265, 272 | Límites: R ≤ 0.9 m, r ≤ 1 m, r ≥ 0.04 m (arrastre) / ≥ 0.01 m (teclado) | sin división por cero (r>0 garantizado); Q=0 y σ=0 se rechazan (l. 262, 264) | ✔ |

Convenciones: ninguna convención de signo temporal; orientación radial implícita. Sin aproximaciones ocultas más allá de la idealidad (lámina infinita, distribución uniforme).

### 1.2 Casos de prueba (JS vs. referencia Python, ε₀ CODATA)

| Caso | Entrada | Salida JS | Referencia | Dif. rel. |
|---|---|---|---|---|
| Punto, defecto | Q=5 nC, r=55 cm | E=148.558 V/m; Φ=564.72 V·m | 148.555; 564.705 | 2.1e-5 |
| Punto, r mínimo | Q=5 nC, r=4 cm | E=28 086.7 V/m | 28 086.1 | 2.1e-5 |
| Punto, Q<0, r máx | Q=−5 nC, r=1 m | E=44.94 V/m; Φ=−564.72 V·m | 44.94; −564.70 | 2.1e-5 |
| Esfera interior | Q=5 nC, R=30, r=15 cm | Q_enc=0.625 nC; E=249.66 V/m; Φ=70.59 | 0.625 nC; 249.65; 70.59 | 2.1e-5 |
| Esfera r=R | r=30 cm | E=499.32 V/m | 499.31 | 2.1e-5 (continuidad en r=R ✔) |
| Esfera exterior | r=55 cm | E=148.558 (igual a punto) | 148.555 | 2.1e-5 |
| Lámina, defecto | σ=10 nC/m² | E=564.72 V/m (uniforme) | 564.70 | 2.1e-5 |
| Lámina, σ<0 extremo | σ=−100 nC/m², r=4 cm | E=5647.2 V/m | 5647.1 | 2.1e-5 |

Coherencia interna: en todos los casos Φ(tile) = E·4πr² (verificado numéricamente); la curva E(r) (l. 246) usa la misma `Efield`; el punto marcador coincide con el valor del tile. Eje de la gráfica rotulado "r (cm)" con ticks 0–100 ✔; el eje E no tiene escala numérica (solo forma) — aceptable, pero conviene indicarlo.

### 1.3 Cobertura del tema 1.1
- Cubre: campo de carga puntual, esfera uniforme (interior/exterior), lámina infinita; ley de Gauss en forma integral; invariancia del flujo con el tamaño de la superficie.
- **No toca**: la **densidad de flujo eléctrico D = ε₀E** (el título del tema la nombra explícitamente; en todo el explorador solo aparece E y Φ_E = Q/ε₀, nunca Φ_D = Q_enc ni la forma ∇·D = ρ); la simetría cilíndrica (línea de carga, E ∝ 1/r); la distinción lámina de carga (σ/2ε₀) vs. superficie de conductor (σ/ε₀); la forma diferencial de la ley de Gauss. La superficie gaussiana "arrastrable" solo cambia de tamaño, no de forma, por lo que la afirmación "sin importar la forma" (l. 62) no se puede comprobar en el explorador.

---

## 2. `Capacitor_explorador.html` — tema 1.2 Potencial, capacitancia

### 2.1 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 116 | ε₀ = 8.854×10⁻¹² | CODATA | ✔ |
| 119 | C = ε₀A/s · [1 + p(εᵣ−1)] | Dos capacitores en paralelo (área pA con εᵣ, área (1−p)A en vacío): C = ε₀[pεᵣA + (1−p)A]/s. Griffiths 4e §2.5.4 y Ej. 4.4 (Ulaby 6e §4-10) | ✔ |
| 122 | Modo V: Q=CV; modo Q: V=Q/C | definición de C | ✔ |
| 123 | E = V/s; U = ½CV² | Griffiths §2.5.4 (energía ½CV² = Q²/2C) | ✔ (ℹ: E=V/s supone campo uniforme sin efecto de borde; con inserción parcial E es el mismo en ambas regiones, correcto en el modelo ideal) |
| 205 | Al cambiar de modo se congela V o Q en el valor actual | continuidad física correcta | ✔ |
| 231 | Qset inicial = C(p=0)·100 V | coherencia inicial | ✔ |
| 101-104 | Formulario en pantalla | idéntico al código | ✔ |
| 96, 147-148 | Textos: V fijo → Q y U suben, E no cambia; Q fija → V, E y U bajan; dieléctrico succionado en ambos casos | Griffiths §4.4.4 (fuerza sobre dieléctrico, F = ½V² dC/dx; a Q fija U = Q²/2C disminuye) | ✔ |
| 164-169 | Dibujo: cargas +/− distribuidas uniformemente sobre toda la placa | A Q fija con inserción parcial la densidad de carga libre es mayor sobre la región con dieléctrico (σ₁/σ₂ = εᵣ) | ℹ (esquema, no afecta números) |
| 216 | εᵣ ≥ 1 forzado; A, s, V > 0 forzados | sin división entre cero | ✔ |

### 2.2 Casos de prueba

| Caso | Entrada | Salida JS | Referencia | Dif. rel. |
|---|---|---|---|---|
| Defecto (V fijo, p=0) | A=100 cm², s=2 mm, εᵣ=4, V=100 V | C=44.27 pF; Q=4.427 nC; E=50 kV/m; U=221.35 nJ | 44.271 pF; 4.4271 nC; 50 kV/m; 221.355 nJ | 2.1e-5 |
| V fijo, p=0.5 | ídem | C=110.68 pF; Q=11.07 nC; U=553.4 nJ | 110.68; 11.068; 553.39 | 2.1e-5 |
| V fijo, p=1 | ídem | C=177.08 pF; U=885.4 nJ | 177.08; 885.42 | 2.1e-5 |
| Q fija, p=1 | Q=4.427 nC | V=25.0 V; E=12.5 kV/m; U=55.34 nJ | 25.0; 12.50 k; 55.34 n | 2.1e-5 |
| Q fija, p=0.5 | Q=4.427 nC | V=40.0 V; E=20 kV/m; U=88.54 nJ | 40.0; 20 k; 88.54 n | 2.1e-5 |
| Extremo | A=1 cm², s=0.1 mm, εᵣ=80, V=1000 V | C=708.3 pF; Q=708.3 nC; E=10 MV/m; U=354.2 µJ | 708.34 pF; … ; 354.17 µJ | 2.1e-5 |
| εᵣ=1, p=1 | — | idéntico a p=0 | ✔ límite degenerado | 0 |

Comprobación de la afirmación del texto: a Q fija, U(p=1)/U(p=0) = 0.250 = 1/εᵣ ✔; a V fijo, U(p=1)/U(p=0) = 4 = εᵣ ✔. Coherencia tiles–dibujo–formulario ✔ (la densidad de flechas de E en el dibujo escala con E del estado, l. 186-187).

### 2.3 Cobertura del tema 1.2
- Cubre: capacitancia de placas paralelas, dieléctrico (εᵣ), inserción parcial como paralelo, energía, contraste V fijo / Q fija.
- **No toca**: el **potencial** como tal (V = −∫E·dl, equipotenciales, relación E = −∇V) que es la primera mitad del título del tema; D y P (densidad de flujo y polarización), carga ligada σ_b = P·n̂ — la frase "el dieléctrico se polariza y cancela parte del campo" (l. 96, 148) no se cuantifica (E_dielec = E₀/εᵣ); capacitores en serie; dieléctrico insertado como **capa** (en serie, C = ε₀A/[s−t+t/εᵣ]) que es la otra configuración clásica; rigidez dieléctrica (con los valores extremos permitidos, E = 10 MV/m supera la rigidez del aire ≈ 3 MV/m sin aviso).

---

## 3. `Solenoide_explorador.html` — tema 1.4 Ley de Ampère (P3)

### 3.1 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 192 | μ₀ = 4π×10⁻⁷ | CODATA 2018: 1.25663706212×10⁻⁶ (desv. 5.4×10⁻¹⁰) | ✔ |
| 195 | n = N/L; a = d/2; h = L/2 | — | ✔ |
| 196 | cos α = h/√(h²+a²) | Factor de borde en el centro | ✔ |
| 197 | B(z)/(μ₀nI) = ½[(z+h)/√((z+h)²+a²) − (z−h)/√((z−h)²+a²)] | Campo axial de un solenoide finito, Griffiths 4e Ej. 5.6 (anillo) + integración (Prob. 5.11); Ulaby 6e §5-? (Ej. 5-6 "solenoide") | ✔ — coincide con integración numérica de Biot–Savart a 5×10⁻¹⁰ (ver 3.2) |
| 205-206 | B_ideal = μ₀nI; B_real = B_ideal·cos α | Griffiths Ej. 5.9 (Ampère, solenoide infinito); Ulaby eq. del solenoide | ✔ |
| 102-110 | Formulario: B(z)=½μ₀nI(cos α₁ + cos α₂); B_centro = μ₀nI cos α | equivalente a l. 197 con cos α₁,₂ = (h±z)/√((h±z)²+a²) | ✔ |
| 142-150 | Derivación: dB = μ₀a²nI dx/[2(a²+x²)^{3/2}]; con x = a cot α → dB = ½μ₀nI sen α dα | Griffiths Ej. 5.6 eq. (5.41); el cambio de variable da −½μ₀nI sen α dα, signo absorbido por los límites | ✔ |
| 122, 129 | "factor ≈ 0.51" para d=6.7, L=4 cm | cos α = 0.5126 | ✔ |
| 241-243 | Gráfica B–I: pendientes μ₀n (ideal) y μ₀n cos α (real) | lineal, correcto en aire | ✔ (ℹ: sin saturación; coherente con "en aire") |
| 167-172 | Consejos: R = ρℓ/A con ℓ ≈ Nπd; P = I²R; núcleo multiplica por μᵣ | correctos cualitativamente | ✔ (⚠ "multiplica por μᵣ" solo vale para núcleo que cierra el circuito magnético; para un núcleo abierto el factor es mucho menor por desmagnetización — juicio) |
| 200 | Tile "Tipo": corto si L/d<1, intermedio <3, largo ≈ ideal ≥3 | umbral de juicio: con L/d=3, cos α = 0.949 (5 % bajo el ideal) | ⚠ (decisión pedagógica; "≈ ideal" con 5 % de error puede matizarse) |
| 215 | Modo absoluto: tope del eje = ideal con N=300 | elección gráfica, no física | ℹ |

### 3.2 Casos de prueba (referencia: integración numérica `scipy.integrate.quad` de anillos de Biot–Savart, sin usar la fórmula cerrada)

| Caso | Entrada | Salida JS | Referencia | Dif. rel. |
|---|---|---|---|---|
| P3 defecto, centro | I=2 A, N=50, L=4 cm, d=6.7 cm, z=0 | B_ideal=3.1416 mT; cos α=0.5126; B=1.6104 mT | 3.1416; 1.6104 | 5e-10 |
| P3, extremo z=L/2 | ídem, z=2 cm | B=1.2043 mT (=0.748 B₀) | 1.2043 | 5e-10 |
| P3, fuera z=5 cm | ídem | B=0.3690 mT | 0.3690 | 5e-10 |
| Largo extremo | I=3, N=300, L=30 cm, d=1 cm, z=0 | B_ideal=3.7699 mT; B=3.7678 (cos α=0.99944) | 3.7678 | 5e-10 |
| Largo, en el extremo | ídem, z=15 cm | B=1.8847 mT = 0.5002 B(0) | 1.8847 | 5e-10 (confirma "la mitad en los extremos") |
| Corto extremo | I=0.5, N=10, L=2 cm, d=12 cm | B_ideal=0.3142 mT; B=0.0516 mT (cos α=0.164) | 0.0516 | 5e-10 |
| L/d = 3 | I=1, N=100, L=30, d=10 cm | B=0.3974 mT vs ideal 0.4189 (cos α=0.949) | 0.3974 | 5e-10 |

Coherencia: la curva del perfil (l. 234, `Bnorm(z)*sc`), la insignia "x mT en el centro" (l. 238) y el tile "B real" (l. 206) usan la misma función y coinciden; eje z rotulado en cm con ticks en ±L/2 ✔; eje Y "B (mT)" o "B/μ₀nI" según el modo ✔; la gráfica B–I usa pendiente μ₀n cos α consistente con el tile ✔.

**Sobre los "datos experimentales embebidos"**: no existen. La línea 128 (145 569 caracteres) es `<img src="data:image/jpeg;base64,...">`, la fotografía de la bobina. El archivo no contiene mediciones de B ni de la pendiente B–I; solo los parámetros nominales d=6.7 cm, N=50, L=4 cm y la afirmación cualitativa (l. 122) de que una pendiente medida "cercana a la mitad de μ₀n" es efecto de borde. Predicción del modelo para contrastar con la P3: pendiente real dB/dI = μ₀n cos α = **0.805 mT/A** (ideal 1.571 mT/A); a 2 A, B_centro = 1.61 mT. Si la práctica mide con sonda Hall de teléfono o sensor de efecto Hall, el campo terrestre (~0.04 mT) es ≈2.5 % de la señal y debería restarse. Conviene que el informe de la práctica adjunte los datos para cerrar la comparación.

### 3.3 Cobertura del tema 1.4 (ley de Ampère)
- Cubre: solenoide ideal μ₀nI, solenoide finito por Biot–Savart, efecto de borde, diseño de bobinas.
- **No toca**: la **ley de Ampère en sí** — el explorador deriva todo por Biot–Savart y nunca muestra ∮B·dl = μ₀I_enc ni el circuito amperiano rectangular que da μ₀nI (Griffiths Ej. 5.9); la frase del título "por qué no basta con B = μ₀nI" se justifica sin decir que Ampère sigue siendo exacta pero la simetría asumida (B uniforme dentro, cero fuera) falla en el solenoide corto. Tampoco: alambre recto (B = μ₀I/2πr), toroide, forma diferencial ∇×B = μ₀J, campo fuera del eje. El dibujo de líneas (l. 258-298) es topológico (Bézier), no calculado; está anunciado como esquemático ✔.

---

## 4. `Induccion_explorador.html` — temas 1.6–1.7 Ley de Faraday (P3)

### 4.1 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 121 | A = πR² | — | ✔ |
| 125-126 | Modo imán: `phiNow` = N·B_cara·A/(1+x²_m)^{3/2}, B_cara = 50 mT, x_m = x/R | Flujo de un dipolo puntual m sobre el eje a través de un disco coaxial de radio R: Φ = μ₀mR²/[2(R²+x²)^{3/2}] ∝ (1+(x/R)²)^{−3/2} — forma funcional exacta (se obtiene de Griffiths eq. 5.89 integrando B_z sobre el disco, o del potencial vector del dipolo). La normalización "B_cara·A" en x=0 es una aproximación (un dipolo puntual en el centro del disco no tiene "campo en la cara") | ✔ forma / ℹ normalización no declarada en pantalla (solo en comentario del código) |
| 126, 128 | **La cantidad devuelta como "Φ" incluye el factor N** (N·B·A) | El formulario (l. 99-100) define Φ = B·A y FEM = −N dΦ/dt; el tile "Flujo Φ ahora" (l. 90, 157) muestra por tanto **NΦ** (enlace de flujo), 50× el flujo de la espira | ✘ incoherencia rótulo–fórmula (confirmado numéricamente: B₀=20 mT, R=3 cm → Φ=56.5 µWb, tile muestra 2.83 mWb) |
| 128 | Modo B: Φ(t) = N B₀ A sen(2πft) | — | ✔ (misma observación sobre N) |
| 131 | FEM = −N B₀ A 2πf cos(2πft) | FEM = −d(NΦ)/dt, Griffiths §7.2.1 eq. 7.14 | ✔ (consistente con l. 128 porque ahí Φ ya lleva N; NO hay doble N) |
| 152-153 | Modo imán: FEM = −ΔΦ/Δt (diferencia hacia atrás, Δt=1/60 s) con filtro IIR femSuave = 0.75·prev + 0.25·nuevo | derivada numérica; el filtro introduce retardo de ~3 cuadros (~50 ms) y atenúa picos de movimientos bruscos | ℹ no declarado (el texto dice "la FEM solo depende de la rapidez", cierto, pero el valor mostrado es una versión suavizada) |
| 101 | Formulario: B(t)=B₀sen(2πft) → FEM = −NAB₀·2πf·cos(2πft) | ✔ coincide con l. 131 | ✔ |
| 94 | Texto: "la FEM va 90° **adelantada** respecto de Φ (un coseno frente a un seno)" | Φ ∝ sen(ωt); FEM ∝ −cos(ωt) = sen(ωt − 90°): la FEM está 90° **retrasada** (la derivada adelanta 90° y el signo de Lenz añade 180°). El propio osciloscopio del explorador lo muestra: el pico de FEM llega un cuarto de periodo **después** del cero ascendente de Φ… y coincide con el pico de Φ con signo negativo | ✘ (texto) |
| 94 | "duplicar f duplica el pico de la FEM" | FEM_pico = NAB₀ω ∝ f | ✔ (verificado: 17.77 mV → 35.53 mV) |
| 161-163 | Lenz: FEM>0 (Φ decrece) → "antihoraria vista desde el imán"; FEM<0 (Φ crece) → "horaria vista desde el imán" | En el dibujo (l. 179-182) el polo **N** es la mitad del imán más cercana a la espira, luego B del imán atraviesa la espira alejándose del imán. Visto desde el imán, B apunta **alejándose del observador**. Si Φ crece, la corriente inducida debe producir B hacia el observador → **antihoraria** vista desde el imán; si Φ decrece → **horaria**. El texto dice lo contrario | ✘ por análisis geométrico (⚠ pedir a la autora que confirme la orientación del imán que quiere mostrar; en modo B(t) con ⊙ = positivo el enunciado sí es correcto "visto desde el frente", pero el rótulo sigue diciendo "vista desde el imán" aunque no hay imán) |
| 160-161 | Umbral "sin corriente": \|FEM\| < 2 % del pico (modo B) o < 40 µV (modo imán) | heurística de presentación | ℹ |
| 116, 235 | DT = 1/60 s fijo; "10 s en pantalla" | Si la pantalla refresca a 120 Hz la simulación corre al doble; el eje sigue siendo tiempo simulado (coherente), pero el "10 s" no es tiempo real | ℹ |
| 103 | "no interviene ninguna constante de la naturaleza" | cierto para el código (μ₀ está absorbido en B_cara=50 mT) | ✔ |

### 4.2 Casos de prueba

| Caso | Entrada | Salida JS | Referencia | Dif. rel. |
|---|---|---|---|---|
| Imán, defecto | N=50, R=3 cm, x=1.6R | NΦ=1.0523 mWb (tile "Φ") | 1.0523 mWb; Φ por espira = 21.05 µWb | 0 (fórmula) / factor 50 (rótulo) |
| Imán, mínimo x | x=0.3R | NΦ=6.211 mWb | 6.211 mWb | 0 |
| Imán, máximo x | x=5.3R | NΦ=45.05 µWb | 45.05 µWb | 0 |
| B(t), t=0 | B₀=20 mT, f=1 Hz | Φ=0; FEM=−17.77 mV | 0; −17.77 mV (deriv. numérica) | 7e-14 |
| B(t), t=T/4 | ídem | NΦ=2.827 mWb (pico); FEM≈0 | 2.827 mWb; 0 | 0 |
| B(t), f=2 Hz, t=0 | — | FEM=−35.53 mV | −35.53 mV | 3e-13 |
| B(t), extremo | N=1, R=10 cm, B₀=1 T, f=60 Hz | FEM=−11.84 V | −11.84 V | 2e-10 |

Coherencia: ambas trazas del osciloscopio usan autoescala independiente (l. 220), de modo que la relación de amplitudes Φ/FEM no se puede leer de la pantalla (solo la fase) — no está indicado. El tile de FEM y la traza usan el mismo valor ✔.

### 4.3 Cobertura de los temas 1.6–1.7
- Cubre: ley de Faraday en forma integral (flujo variable por movimiento de imán y por B(t)), signo de Lenz cualitativo, dependencia con f, N, A.
- **No toca**: FEM de movimiento (v×B, barra deslizante, Griffiths §7.1.3) — la práctica P3 habitual sí la usa; el campo eléctrico inducido ∮E·dl = −dΦ/dt / ∇×E = −∂B/∂t (forma diferencial, parte central del tema "ecuaciones de Maxwell"); autoinductancia e inductancia mutua (1.7 suele incluirlas); fuerza de frenado sobre el imán (solo se menciona en texto); diferencia Φ vs. NΦ (ver error). El modo imán no permite variar B_cara ni la geometría del imán.

---

## 5. `RC_interactivo.html` — temas 1.9–1.10 Fasores (P4)

### 5.1 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 207 | ω=2πf; X_C=1/(ωC); \|Z\|=√(R²+X_C²); φ=atan2(X_C,R) | Z = R + 1/(jωC) = R − jX_C (convención e^{jωt}); I = V/Z → ∠I = +arctan(X_C/R): la corriente **adelanta**. Ulaby 6e §1-7 (fasores) y Ej. 1-?; Sadiku §9 | ✔ |
| 208 | I_p=V_p/\|Z\|; V_R=I_pR; V_C=I_pX_C; T=1/f | — | ✔ (amplitudes pico, coherente con "V_in amplitud") |
| 222 | Δt = (φ/2π)·T | = (φ/360°)T | ✔ |
| 247-249 | Trazas: V_in = V_p sen θ; V_R = V_Rp sen(θ+φ); V_C = V_Cp sen(θ+φ−90°) | V_R en fase con I (adelanta φ); V_C retrasa 90° respecto de I | ✔ (KVL instantánea V_in − V_R − V_C verificada < 2×10⁻¹⁵ V en todo el periodo) |
| 252-255 | Marcadores "Δt": xA en θ=0 (cero ascendente de V_in), xB en θ = 2π−φ (cero ascendente de V_R, tomado módulo 2π); el corchete "Δt" une xB con xA | El corchete abarca desde θ=2π−φ hasta θ=0, es decir **2π−φ = T−Δt**, no Δt. El cero de V_R en 2π−φ debe compararse con el cero de V_in en θ=2π, no en θ=0 | ✘ confirmado numéricamente: defecto φ=57.9°, Δt = 0.161 ms = 6.4 % del ancho de pantalla; el corchete dibujado mide 33.6 % del ancho (= 2.5 ciclos: (2π−φ)/5π). Para φ→0 el corchete tiende a un ciclo completo en vez de a cero |
| 277-282 | Fasores: V_in en +x; V_R a +φ; V_C a φ−90° punta-cola; I a +φ | diagrama estándar RC serie con V_in de referencia | ✔ |
| 291-295 | Triángulo Z: R horizontal, X_C vertical **hacia arriba**, Z hipotenusa, ángulo φ | Con Z = R − jX_C el triángulo de impedancias convencional dibuja X_C hacia **abajo** (−j) (Ulaby, Sadiku §9.5); dibujarlo hacia arriba es un espejo, numéricamente equivalente | ⚠ convención gráfica (no error numérico); si se mantiene, decirlo |
| 180-186 | Formulario: Z = R + 1/(jωC) = R − j/(ωC); f_c = 1/(2πRC) | ✔; f_c se muestra pero no se calcula ni se marca en ningún panel | ✔ / ℹ |
| 225 | "Sube f y φ baja (X_C disminuye); el capacitor manda a baja frecuencia" | ✔ | ✔ |
| 203-206, 310 | Rango: R 100–10 kΩ, C 10–1000 nF, f 100–10 kHz; teclado acepta cualquier v>0 | sin división entre cero | ✔ |
| 188 | "no interviene ninguna constante de la naturaleza" | ✔ | ✔ |

### 5.2 Casos de prueba (referencia: impedancia compleja en numpy)

| Caso | Entrada | Salida JS | Referencia | Dif. rel. |
|---|---|---|---|---|
| Defecto | R=1 kΩ, C=100 nF, f=1 kHz, V=3 V | X_C=1591.5 Ω; Z=1879.6 Ω; φ=57.86°; Δt=160.7 µs; I=1.596 mA; V_R/V_C=1.60/2.54 V | idénticos | <1e-15 |
| Baja f, φ→90° | R=100 Ω, C=1 µF, f=100 Hz, V=1 V | φ=86.40°; Δt=2.400 ms; V_C=0.998 V | idénticos | <1e-15 |
| Alta f, φ→0 | R=10 kΩ, C=10 nF, f=10 kHz, V=5 V | φ=9.04°; V_R=4.94 V | idénticos | <1e-15 |
| f = f_c | R=1 kΩ, C=100 nF, f=1591.55 Hz | φ=45.00°; V_R=V_C=2.121 V = V/√2 | idénticos | 0 |
| Extremo φ≈90° | R=100 Ω, C=10 nF, f=100 Hz | X_C=159 kΩ; φ=89.96°; V_C=3.00 V | idénticos | <1e-15 |
| Extremo φ≈0 | R=10 kΩ, C=1 µF, f=10 kHz | φ=0.091°; V_R=3.00 V | idénticos | <1e-15 |
| Corchete Δt (visual) | defecto | ancho dibujado = 0.3357 del ancho útil | debería ser Δt/(2.5T) = 0.0643 | **✘ factor 5.2** |

### 5.3 Cobertura de los temas 1.9–1.10
- Cubre: impedancia compleja, módulo y fase, corriente que adelanta en RC, Δt↔φ, fasores de tensión, triángulo de impedancias, comparación "congelar".
- **No toca**: la transformación explícita dominio del tiempo ↔ fasor (v(t) = Re{Ṽ e^{jωt}}, la razón por la que d/dt → jω) que es el núcleo del tema "fasores"; el caso RL (adelanto vs. retraso, que fija la regla "ELI the ICE man"); el circuito RLC/resonancia; potencia media y factor de potencia; la convención e^{jωt} vs e^{−jωt} (relevante porque el curso usa ambos signos en óptica y en Griffiths); el filtro pasa-bajas (f_c aparece en el formulario pero no se usa — un panel \|V_C/V_in\| vs f sería inmediato con los mismos datos).

---

## 6. Lista consolidada

### 6.1 Errores confirmados

| # | Archivo | Línea | Descripción | Corrección propuesta |
|---|---|---|---|---|
| E1 | `RC_interactivo.html` | 252-255 | El corchete "Δt" del osciloscopio une el cero de V_R en θ=2π−φ con el cero de V_in en θ=0: mide T−Δt (33.6 % del ancho en el caso por defecto, en vez de 6.4 %). | Comparar con el cero de V_in en θ=2π: `var xA=mk(2*Math.PI,css('--vin')), xB=mk(-phi,css('--vr'));` (y eliminar el `if(th<0)th+=2*Math.PI` o dejarlo, ya que −φ+2π es el valor deseado). Alternativa equivalente: `xA=mk(0)`, `xB=pad+((-phi+2*Math.PI)… )` no sirve; lo esencial es que ambos ceros pertenezcan al mismo ciclo. |
| E2 | `Induccion_explorador.html` | 90, 126, 128, 157 (vs 99-100) | El tile "Flujo Φ ahora" muestra NΦ (enlace de flujo) mientras el formulario define Φ = B·A y FEM = −N dΦ/dt. Con los valores por defecto muestra 2.83 mWb donde Φ = 56.5 µWb. | Opción a) quitar N de `phiNow` (l. 126 y 128) y poner `fem = -N*(phi-phiPrev)/DT` (l. 152) y `-N*…` ya está en l. 131 → cambiar a `-N*B0*area()*…` sin N en phi. Opción b) renombrar el tile "Enlace de flujo NΦ" y la leyenda "NΦ(t)". |
| E3 | `Induccion_explorador.html` | 94 | "la FEM va 90° adelantada respecto de Φ". Con Φ = sen(ωt), FEM = −cos(ωt) = sen(ωt − 90°): retrasada 90°. | "la FEM va 90° **retrasada** respecto de Φ (−cos frente a sen: la derivada adelanta 90° y el signo de Lenz le da media vuelta)". |
| E4 | `Induccion_explorador.html` | 162-163 (con 179-182) | Sentido de Lenz invertido respecto del dibujo: con el polo N frente a la espira, Φ creciente ⇒ corriente **antihoraria** vista desde el imán; Φ decreciente ⇒ **horaria**. El código muestra lo contrario. (Confirmado por regla de la mano derecha sobre la geometría dibujada; no por cálculo numérico.) | Intercambiar los dos textos de l. 162-163, o invertir el imán (S hacia la espira) si se prefiere conservar los textos. En modo B(t) sustituir "vista desde el imán" por "vista de frente (⊙ hacia ti)". |

### 6.2 Puntos a verificar / aproximaciones no declaradas

| # | Archivo | Línea | Punto |
|---|---|---|---|
| V1 | `Solenoide_explorador.html` | 128 | No hay datos experimentales embebidos (es una foto JPEG). La comparación con la P3 no puede cerrarse desde el archivo; el modelo predice pendiente 0.805 mT/A y 1.61 mT a 2 A para la bobina de ejemplo. |
| V2 | `Solenoide_explorador.html` | 200 | "largo ≈ ideal" para L/d ≥ 3 cuando cos α = 0.949 (−5 %). Sugerencia: "largo (≈5 % bajo el ideal)" o subir el umbral a L/d ≥ 5 (cos α = 0.981). |
| V3 | `Solenoide_explorador.html` | 170 | "Un núcleo ferromagnético multiplica B por μᵣ": solo con circuito magnético cerrado; en una bobina abierta el factor efectivo es mucho menor (desmagnetización). Matizar. |
| V4 | `RC_interactivo.html` | 291-295 | Triángulo de impedancias con X_C hacia arriba (convención espejo de Z = R − jX_C). Indicar o dibujar hacia abajo. |
| V5 | `RC_interactivo.html` | 186 | f_c aparece en el formulario pero no se calcula ni se marca; sería útil mostrarla en los tiles (φ = 45°, V_R = V_C). |
| V6 | `Induccion_explorador.html` | 125, 153, 220 | (a) Normalización B_cara = 50 mT y modelo de dipolo puntual no declarados en pantalla; (b) filtro IIR en la FEM (retardo ≈50 ms, atenúa picos) no declarado; (c) autoescala independiente de cada traza: no se puede comparar amplitudes Φ/FEM, indicarlo. |
| V7 | `CampoGauss_explorador.html` | 107, 128 | "lámina plana infinita E = σ/2ε₀": indicar que es lámina de carga (no superficie de conductor, σ/ε₀). |
| V8 | `CampoGauss_explorador.html` | 62 | "sin importar la forma": la superficie solo cambia de tamaño; o se añade una forma alternativa (cubo) o se reformula. |
| V9 | `Capacitor_explorador.html` | 123, 164-169 | E = V/s ignora bordes (declarar); en modo Q fija con inserción parcial las cargas libres dibujadas son uniformes aunque σ_dielec/σ_vacío = εᵣ. Sin aviso de rigidez dieléctrica cuando E supera ~3 MV/m (alcanzable con los controles). |
| V10 | `Induccion_explorador.html` | 116 | DT fijo = 1/60 s: en pantallas de 120 Hz la simulación corre al doble de velocidad real ("10 s en pantalla" es tiempo simulado). Usar el timestamp de `requestAnimationFrame`. |

### 6.3 Cobertura pedagógica (síntesis)
- 1.1: falta D = ε₀E (densidad de flujo, parte del título del tema), simetría cilíndrica, forma diferencial.
- 1.2: falta el potencial (V = −∫E·dl, E = −∇V), D y P, carga ligada, dieléctrico en serie.
- 1.4: falta la ley de Ampère como tal (∮B·dl = μ₀I_enc, circuito amperiano del solenoide ideal); todo se deriva por Biot–Savart.
- 1.6–1.7: falta FEM de movimiento (v×B), E inducido / ∇×E = −∂B/∂t, inductancia.
- 1.9–1.10: falta la transformación tiempo↔fasor explícita (d/dt → jω), el caso RL, potencia; convención e^{jωt} no enunciada.

Lo numérico (fórmulas, constantes, casos de prueba, KVL, continuidad en r=R, límites de solenoide largo/corto) está **confirmado** por reimplementación independiente. Los puntos E4, V2, V3, V4 y toda la sección 6.3 son **juicio** del auditor sobre convenciones y alcance pedagógico, no errores de cálculo.
