# Informe de auditoría — Unidad 4 (líneas de transmisión, carta de Smith, guías de onda) + transversal (Anatomía de una gráfica)

Archivos auditados (en `/tmp/tem/`, sin modificar): `LineaTransmision_interactivo.html`, `Smith_explorador.html`, `GuiaOnda_explorador.html`, `AnatomiaGrafica_explorador.html`.
Método: extracción de las funciones físicas del JS a módulos Node (`lt.js`, `sm.js`, `go.js`, `an.js` en el directorio de trabajo), ejecución con `node` (`run_js.js` → `js_out.json`) y reimplementación independiente en NumPy (`verif.py`). Los scripts matplotlib generados por el explorador de Anatomía se reconstruyeron con `gen_script.js` y se ejecutaron con `python3 -I` (matplotlib 3.11.2, numpy 2.5.3). Referencias: Pozar, *Microwave Engineering* (4e) cap. 2 y 3; Ulaby–Michielssen–Ravaioli (6e) cap. 2; Jackson 3e §5.18/§8.1 para efecto piel.

Resumen ejecutivo: la física de los tres exploradores de U4 es correcta en todas las fórmulas y en todos los casos numéricos probados (diferencia relativa ≤ 1e-15, es decir, redondeo de máquina). Se confirman **dos errores reales**: (1) en `GuiaOnda` el conteo de modos propagantes está truncado a 6 modos TE (m,n ≤ 3) y por eso el "Estado" miente a frecuencias altas o con guías de relación a/b atípica; (2) en `AnatomiaGrafica` el script generado contiene `1e2.5` (SyntaxError en Python) cuando el exponente del barrido no es entero y el muestreo es `np.linspace`. El resto son precisiones de presentación y lagunas de cobertura.

---

## 1. `LineaTransmision_interactivo.html` (temas 4.3–4.4)

### 1.1 Tabla de fórmulas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 131 | `Gam()` → Γ = (R_L + jX_L − Z₀)/(R_L + jX_L + Z₀) | Pozar (2.35); Ulaby 2-7 | ✔ |
| 132–136 | `envAt(d)` → \|1 + Γ e^{−j4πd/λ}\| con d en unidades de λ (ph = −4πd ≡ −2βd) | Pozar (2.39): \|V(z)\| = \|V₀⁺\|\|1 + Γ e^{2jβz}\| con z = −d | ✔ |
| 137–144 | `vInst(d,t)` → Re[(e^{jβd} + Γ e^{−jβd}) e^{jωt}] | V(z) = V₀⁺(e^{−jβz} + Γ e^{jβz}), z = −d, convención e^{jωt} | ✔ (misma convención que las ecuaciones mostradas) |
| 145–152 | `Zin(d)` → Z₀ (Z_L cos βd + jZ₀ sin βd)/(Z₀ cos βd + jZ_L sin βd) con Z_L compleja | Pozar (2.44); Ulaby (2.79) | ✔ (forma cos/sin evita tan → ∞ en d = λ/4) |
| 160–163 | `dmin()` → d_mín/λ = (θ_r + π)/(4π) mod 0.5 | Ulaby (2.72): d_mín = (θ_r + π)λ/(4π) (+ nλ/2) | ✔ |
| 168 | VSWR = (1+\|Γ\|)/(1−\|Γ\|); ∞ si \|Γ\| ≥ 0.9999 | Pozar (2.41) | ✔ |
| 171 | Potencia reflejada = \|Γ\|² (%) | Pozar (2.37) | ✔ |
| 174 | \|V\|máx/\|V\|mín mostrado = S (mismo número que VSWR) | Es la definición, no una medida independiente de la envolvente | ℹ tautológico: sería más convincente calcularlo de `envAt` (máx/mín numéricos) y que el estudiante vea que coincide |
| 109–112 | Ecuaciones en pantalla: Γ, VSWR, \|V(d)\|, Z_in(d), casos λ/2, λ/4 (Z₀²/Z_L), corto (jZ₀ tan βd) | Pozar 2.3 | ✔ |
| 113 | "Línea sin pérdidas" declarado | — | ✔ aproximación declarada |
| 153–159 | `fmtC` muestra Γ con **1 decimal** y umbral 0.05 para anular parte real/imag. | — | ⚠ presentación: Γ = 0.3333 → "0.3"; Z_L = 52 + j1 Ω → Γ se muestra "0.0" mientras VSWR muestra 1.04. Para Γ conviene 3 decimales y umbral ~0.0005 (como en `Smith_explorador`, que usa `toFixed(3)` y fase) |
| 169 | `.replace('±j∞','1∠180°')` sobre Γ | — | ℹ código muerto: \|Γ\| ≤ 1 nunca dispara '±j∞'; el corto muestra "−1.0" (correcto) |

Convenciones verificadas: Γ = (Z_L − Z₀)/(Z_L + Z₀) (no la inversa); e^{jωt}; z = 0 en la carga, d > 0 hacia el generador; rotación e^{−j2βd}. Todo consistente entre código, ecuaciones y dibujo (carga a la derecha, "← hacia el generador" a la izquierda).

### 1.2 Casos de prueba numéricos (salida JS vs NumPy independiente)

| Z₀ | Z_L (Ω) | d/λ | Γ (JS) | VSWR (JS) | \|1+Γe^{−j2βd}\| JS / Py | Z_in JS / Py (Ω) | d_mín/λ JS / Py | Δrel |
|---|---|---|---|---|---|---|---|---|
| 50 | 100 (defecto) | 0.125 | 0.3333 | 2.000 | 1.054093 / 1.054093 | 40 − j30 / 40 − j30 | 0.250 / 0.250 | <1e-15 |
| 50 | 50 | 0.3 | 0 | 1 | 1 / 1 | 50 / 50 | "sin mínimos" | 0 |
| 50 | 0 (corto) | 0.125 | −1 | ∞ | 1.41421 / 1.41421 | j50.0 / j50.0 | 0 / 0 | ~1e-16 |
| 50 | 0 (corto) | 0.25 | −1 | ∞ | 2 / 2 | "±j∞" (JS: j8.2e17) / ∞ | 0 / 0 | — (degenerado bien manejado) |
| 50 | 1e9 (abierto) | 0.125 | 1.0 | ∞ (S=2e7) | 1.41421 / 1.41421 | −j50.0 / −j50.0 | 0.250 / 0.250 | 1e-9 |
| 50 | 73 + j42.5 | 0.125 | 0.2737 + j0.2510 | 2.181 | 1.280549 / 1.280549 | 67.78 − j43.04 / idem | 0.3091 / 0.3091 | 3e-16 |
| 50 | 25 − j50 | 0.2 | 0.0769 − j0.6154 | 4.266 | 0.732614 / 0.732614 | 13.78 + j20.28 / idem | 0.1349 / 0.1349 | 4e-16 |
| 50 | 25 − j50 | 1.5 (máx. control) | idem | idem | 1.240347 / 1.240347 | 25 − j50 (= Z_L, 3 medias λ) | idem | 3e-16 |
| 75 | 100 | 0.25 | 0.1429 | 1.333 | 0.857143 / 0.857143 | 56.25 / 56.25 (= Z₀²/Z_L ✔) | 0.250 | 1e-16 |
| 50 | 100 | 0.5 | 0.3333 | 2 | 1.3333 | 100 (= Z_L ✔) | 0.250 | 3e-16 |

Comprobación adicional: `envAt(dmin())` = 1 − \|Γ\| en todos los casos (0.6667, 0.6287, 0.3798, 0 para corto), es decir, el mínimo marcado en rojo coincide con el mínimo real de la envolvente. `vInst(d,0)` coincide con Re[e^{jβd} + Γe^{−jβd}] (p. ej. 0.94281 para el caso por defecto).

### 1.3 Coherencia interna
- Envolvente dibujada (`envAt`), tiles (`Zin`, `dmin`, S) y ecuaciones del formulario corresponden a la misma magnitud y convención. ✔
- Etiqueta del plano: "z = −d (d = … λ) · Z_in = …" coincide con el tile. ✔
- La afirmación "el cociente \|V\|máx/\|V\|mín es exactamente el VSWR" es cierta, pero el tile no lo demuestra (ver ℹ arriba).
- Rango d/λ 0–1.5 y escala 180 px/λ: con 940 px de ancho se ven ≈4.9 λ; el plano se puede arrastrar sólo hasta 1.5 λ. Coherente.
- Caso degenerado corto en d = λ/4: `cdiv` divide por ~0 y da j8×10¹⁷ → `fmtC` imprime "±j∞". Correcto. Si además R_L = 0 y el denominador es exactamente 0 se obtiene NaN → también "±j∞". ✔

### 1.4 Cobertura pedagógica (4.3–4.4)
Cubierto: Γ complejo, VSWR, patrón de onda estacionaria, posiciones de mínimos, Z_in(d), casos corto/abierto/adaptado, λ/4 y λ/2, analogía con η(d) de U3.
No cubierto o incompleto:
- Caso abierto en el formulario: falta Z_in = −jZ₀ cot(βd) (sólo aparece el corto).
- Posición de los máximos (d_máx = d_mín ± λ/4) no se muestra ni se dibuja; sólo mínimos.
- Línea con pérdidas (α, Z₀ compleja), parámetros L, C, Z₀ = √(L/C), velocidad de fase: fuera del explorador (si 4.3 incluye "parámetros de la línea", es una laguna).
- Transformador λ/4 como herramienta de diseño (Z₁ = √(Z₀Z_L)): aparece la fórmula Z₀²/Z_L pero no un modo "diseño" para adaptar.
- Reconstrucción de Z_L a partir de (VSWR, d_mín) — el texto lo afirma (línea 104) pero el explorador no la ejecuta en sentido inverso.
- Potencia entregada a la carga (1 − \|Γ\|²) sólo implícita.

---

## 2. `Smith_explorador.html` (temas 4.7–4.8)

### 2.1 Tabla de fórmulas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 120 | `GamL()` → Γ = (z_L − 1)/(z_L + 1), z_L = Z_L/Z₀ | Pozar (2.52) | ✔ |
| 121–122 | `rot(G,d)` → Γ(d) = Γ_L e^{−j4πd/λ} (= e^{−j2βd}) | Pozar (2.55)/(2.56); sentido horario hacia el generador | ✔ |
| 123 | `zOf(G)` → z = (1+Γ)/(1−Γ) | Pozar (2.53) | ✔ |
| 142–144 | Círculos r = cte: centro (r/(1+r), 0), radio 1/(1+r) | Pozar (2.59a) | ✔ (verificado numéricamente: puntos z = r + jx caen a distancia exactamente 1/(1+r) del centro) |
| 146–149 | Arcos x = cte: centro (1, ±1/x), radio 1/\|x\| (sg=+1 arriba = inductivo) | Pozar (2.59b) | ✔ (verificado: \|Γ − (1 + j/x)\| = 1/\|x\|) |
| 139 | Recorte al círculo unidad (elimina la parte r < 0 de los arcos x) | — | ✔ |
| 157–158 | Etiquetas de r en el eje real en Γ = (r−1)/(r+1) | Cruce del círculo r con el eje real | ✔ (contiene `*0 + 0`, código muerto inocuo) |
| 164–166 | Círculo de VSWR: radio \|Γ\| | Pozar 2.4 | ✔ |
| 170–173 | Arco verde de Γ_L a Γ(d): canvas `arc(…, −θ_L, −θ_L + 4πd, false)` | Horario en pantalla (eje y invertido) | ✔ (dirección y longitud 4πd correctas; `a0` en l.170 es código muerto) |
| 195 | VSWR = (1+\|Γ\|)/(1−\|Γ\|) | Pozar (2.41) | ✔ |
| 200–201 | d_mín/λ = (θ_r + π)/(4π) mod 0.5 | Ulaby (2.72) | ✔ |
| 203 | Z_in = Z₀·z(Γ(d)) | — | ✔ |
| 97, 104 | "El círculo \|Γ\| corta el eje real en r = VSWR (máx, derecha) y r = 1/VSWR (mín, izquierda); media vuelta = λ/4; vuelta = λ/2" | Pozar 2.4 | ✔ |
| 219 | Arrastre limitado a \|Γ\| ≤ 0.985 | — | ℹ no se puede arrastrar hasta corto/abierto (S ≤ 132); los botones sí los dan. Razonable, pero conviene decirlo |

### 2.2 Casos de prueba

| Z₀ | Z_L | d/λ | Γ(d) JS | Γ(d) Py | Z_in JS (Ω) | Z_in Py vía tan βd (Ω) | Texto mostrado |
|---|---|---|---|---|---|---|---|
| 50 | 100 (defecto) | 0 | 0.3333 | 0.3333 | 100 | 100 | "100.0" |
| 50 | 100 | 0.25 | −0.3333 | −0.3333 | 25 | 25 (= Z₀²/Z_L) | "25.0" |
| 50 | 25 + j25 | 0.1 | 0.31862 + j0.31382 | idem | 71.08 + j55.76 | 71.08 + j55.76 | "71.1 + j55.8" |
| 50 | 73 + j42.5 | 0.5 | 0.2737 + j0.2510 | idem | 73 + j42.5 (vuelta completa) | idem | "73.0 + j42.5" |
| 50 | 0 (corto) | 0.125 | +j1 | +j1 | j50 | j50 | "j50.0" |
| 50 | 1e9 (abierto) | 0.125 | −j1 | −j1 | −j50 | −j50 | "−j50.0" |
| 50 | 25 − j50 | 0.2 | −0.4240 + j0.4526 | idem | 13.78 + j20.28 | idem (coincide con LineaTransmision) | "13.8 + j20.3" |
| 75 | 100 | 0.25 | −0.1429 | −0.1429 | 56.25 | 56.25 | "56.3" |

Diferencias relativas ≤ 1e-15. Los dos exploradores (Línea y Smith) dan exactamente el mismo Z_in para la misma entrada: coherencia cruzada ✔.

### 2.3 Coherencia interna
- La rejilla dibujada, los puntos z_L/z_in, el círculo VSWR y los tiles usan el mismo Γ. ✔
- "+jx (inductivo)" arriba y "−jx (capacitivo)" abajo coincide con `sg` de los arcos. ✔
- La carta no etiqueta los valores de x en los arcos (sólo r en el eje real) ni muestra la escala angular "longitudes de onda hacia el generador" del borde. El estudiante no puede *leer* x de la carta sin el tile. ⚠ pedagógico, no error.

### 2.4 Cobertura pedagógica (4.7–4.8)
Cubierto: mapeo z→Γ, círculos r y x, rotación hacia el generador, círculo VSWR y su lectura en el eje real, d_mín, Z_in(d).
No cubierto:
- **Admitancia** (punto diametralmente opuesto, y = 1/z, carta de admitancias): ausente. Es lo primero que se usa para stubs en paralelo.
- **Stubs** (simple, en serie/paralelo) y **transformador λ/4** sobre la carta: ausentes.
- Rotación "hacia la carga" (antihorario): no hay control (d sólo ≥ 0).
- Escala exterior en λ (0 a 0.5) y escala de fase de Γ: no dibujadas.
- Rejilla con sólo 5 valores de r y x (0.2, 0.5, 1, 2, 5): suficiente para la idea, insuficiente para lecturas cuantitativas.

---

## 3. `GuiaOnda_explorador.html` (temas 4.10–4.12)

### 3.1 Tabla de fórmulas y datos

| Línea | Fórmula / dato implementado | Referencia correcta | Veredicto |
|---|---|---|---|
| 118 | c₀ = 299 792 458 m/s | exacto | ✔ |
| 121 | f_c(m,n) = (c/2)√[(m/a)² + (n/b)²] | Pozar (3.84) | ✔ (sólo aire; el texto l.106 declara c → c/√εᵣ para relleno) |
| 122–130 | `modos()`: enumera (m,n) con 0 ≤ m,n ≤ 3, ordena por f_c y **se queda con 6** | Modos TE_mn (m o n ≠ 0) y TM_mn (m,n ≥ 1) | ✘ ver 3.3 (conteo truncado) y ⚠ etiqueta "TE" para todos (TM11 degenerado con TE11 no se menciona) |
| 136–137 | f_c(TE₁₀) = c/2a; u = √(1 − (f_c/f)²); banda monomodo = [f_c(1er modo), f_c(2º modo)] | Pozar 3.3 | ✔ (para a > 2b el 2º es TE20, para b > a/2 es TE01: manejado) |
| 142 | λ_g = λ/u | Pozar (3.90) | ✔ |
| 143–144 | v_p/c = 1/u, v_g/c = u | Pozar (3.91)–(3.92) | ✔ (v_p v_g = c² se cumple por construcción) |
| 103 | β = (2πf/c)√(1 − (f_c/f)²) (en pantalla) | Pozar (3.86) | ✔ |
| 105, 195–216 | E_y(x) ∝ sin(πx/a), uniforme en y, nula en x = 0, a | Pozar (3.89) TE₁₀ | ✔ |
| 194, 199 | Evanescente: amplitud ×0.35 y ×e^{−1} | Decaimiento e^{−αz}, no una amplitud fija | ℹ ilustrativo, no cuantitativo (no se afirma lo contrario) |
| 75 | WR-90: 22.86 × 10.16 mm (0.900 × 0.400 in) | EIA WR-90; f_c = 6.557 GHz; banda recomendada 8.2–12.4 GHz | ✔ dimensiones; ℹ el explorador muestra "banda monomodo 6.56–13.11 GHz" (teórica f_c10–f_c20), no la banda de operación EIA 8.2–12.4 GHz (≈1.25–1.9 f_c). Conviene distinguirlas en el texto |
| 76 | WR-284: 72.14 × 34.04 mm (2.840 × 1.340 in) | EIA; f_c = 2.078 GHz; banda 2.60–3.95 GHz | ✔ |
| 77 | WR-42: 10.668 × 4.318 mm (0.420 × 0.170 in) | EIA; f_c = 14.05 GHz; banda 18.0–26.5 GHz | ✔ |
| 80 | Control f: 1–40 GHz | — | ✔ cubre las tres guías; con WR-42 el corte (14.05 GHz) queda dentro del rango |
| 97 | Texto v_p > c, v_g < c, v_p v_g = c², puerta del horno (2.45 GHz) | Pozar 3.3 | ✔ |

No se muestra Z_TE = η/√(1 − (f_c/f)²) ni Z_TM; no aparece en el explorador (laguna, no error).

### 3.2 Casos de prueba

| a × b (mm) | f (GHz) | f_c10 JS / Py (GHz) | Orden de modos JS (= Py) | λ_g JS / Py (mm) | v_p/c | v_g/c | Estado JS |
|---|---|---|---|---|---|---|---|
| 22.86 × 10.16 | 10 (defecto) | 6.5571 / 6.5571 | TE10 6.557, TE20 13.114, TE01 14.754, TE11 16.145, TE30 19.671, TE21 19.740 | 39.707 / 39.707 | 1.32449 | 0.75501 | monomodo ✔ |
| idem | 6.5 (< f_c) | idem | idem | "evanescente" / — | — | — | evanescente ✔ |
| idem | 6.6 | idem | idem | 399.22 / 399.22 | 8.789 | 0.1138 | monomodo ✔ |
| idem | 12.4 | idem | idem | 28.485 / 28.485 | 1.1782 | 0.8487 | monomodo ✔ |
| idem | 40 (máx) | idem | idem | 7.5976 / 7.5976 | 1.01371 | 0.98647 | **"6 modos se propagan"** — real: muchos más (ver 3.3) |
| 72.14 × 34.04 | 3 | 2.0779 / 2.0779 | TE10 2.078, TE20 4.156, TE01 4.404, TE11 4.869, TE21 6.055, TE30 6.234 | 138.54 / 138.54 | 1.3864 | 0.7213 | monomodo ✔ |
| 72.14 × 34.04 | 10 | idem | idem | — | — | — | **"6 modos"**; sólo TE con m,n ≤ 10 ya son 12 (Py), más los TM |
| 10.668 × 4.318 | 20 | 14.051 / 14.051 | TE10 14.051, TE20 28.102, TE01 34.714, TE11 37.45, TE30 42.15, TE21 44.66 | 21.064 / 21.064 | 1.4052 | 0.7116 | monomodo ✔ |
| 20 × 20 (cuadrada) | 10 | 7.4948 / 7.4948 | TE01 7.495, TE10 7.495, TE11 10.599, … | 45.284 / 45.284 | 1.5105 | 0.6620 | "2 modos" ✔ (degeneración TE10/TE01; banda monomodo "7.49–7.49 GHz" de ancho nulo: físicamente correcto, pero sin explicación) |

Δrel ≤ 1e-15 en todos los valores numéricos. Los cortes de las guías coinciden con los valores EIA tabulados (WR-90 6.557, WR-284 2.078, WR-42 14.051 GHz); además verifiqué WR-62 (15.799 × 7.899 mm → 9.488 GHz) por si se añade.

### 3.3 Errores y puntos de verificación
- ✘ **Conteo de modos truncado** (l.124, 129, 146). `modos()` sólo considera m,n ≤ 3 y conserva 6 entradas; `nprop` cuenta sobre esa lista. Consecuencias confirmadas: (a) a f alta el "Estado" dice "6 modos se propagan" aunque haya ≥ 12 TE + TM (WR-90 a 40 GHz; WR-284 a ≥ 6.3 GHz); (b) con a/b > 3 tecleado a mano (p. ej. a = 22.86, b = 2 mm) TE40 (26.2 GHz) y TE50 quedan fuera de la lista aunque corten antes que TE01 (73.8 GHz), así que el mapa de modos omite cortes reales. Corrección propuesta:
  ```js
  function modos(fmax){ var lista=[];
    for(var m=0;m<=12;m++)for(var n=0;n<=12;n++){ if(m===0&&n===0)continue;
      var F=fc(m,n); lista.push({m:m,n:n,fc:F,tipo:(m>0&&n>0)?'TE/TM':'TE'}); }
    lista.sort(function(p,q){return p.fc-q.fc;}); return lista; }
  // dibujar sólo los que caben en el eje (fc < fmax); contar nprop sobre la lista completa,
  // sumando 2 por cada (m,n) con m,n>0 (TE y TM degenerados) si se quiere el número real de modos.
  ```
- ⚠ **Etiquetas "TE11", "TE21"…** (l.176): para m,n ≥ 1 el corte es común a TE_mn y TM_mn (Pozar 3.3–3.4: TM11 es el TM más bajo). El explorador nunca menciona TM. Proponer etiqueta `TE/TM11` y una frase en el formulario.
- ℹ "Banda monomodo" = f_c10 – f_c(2º modo) es la banda teórica; la banda EIA (8.2–12.4 GHz para WR-90, ≈1.25–1.9 f_c) es más estrecha por dispersión y atenuación cerca del corte. Conviene mostrar ambas (añadir la banda EIA al botón de cada guía).
- ℹ Guía cuadrada: banda monomodo de ancho nulo; mostrar "— (TE10 y TE01 degenerados)" sería más claro que "7.49 GHz – 7.49 GHz".

### 3.4 Cobertura pedagógica (4.10–4.12)
Cubierto: f_c(mn), orden de modos para a = 2b, banda monomodo, λ_g, v_p, v_g, v_p v_g = c², patrón E_y del TE₁₀, guías estándar, efecto del dieléctrico (sólo texto), evanescencia.
No cubierto: modos TM (y que TM11 es el TM dominante), impedancia de onda Z_TE/Z_TM, diagrama de dispersión ω–β (que ilustraría v_p y v_g como pendientes), atenuación por pérdidas en paredes (α_c), potencia transportada, campos H y corrientes en las paredes del TE₁₀, inexistencia del TEM en guía hueca, guía circular (si 4.12 la incluye). El efecto de εᵣ se menciona pero no hay control.

---

## 4. `AnatomiaGrafica_explorador.html` (transversal, cómputo científico, P6)

### 4.1 Tabla de fórmulas, datos y código generado

| Línea | Implementado | Referencia | Veredicto |
|---|---|---|---|
| 231, 248 | μ₀ = 4π×10⁻⁷; δ = 1/√(π f μ₀ μᵣ σ) | Jackson 3e (5.165)/(8.8); Ulaby 7-6 | ✔ (μ₀ = 4π×10⁻⁷ difiere del valor SI 2019 en 5.5e-10 relativo: irrelevante) |
| 88 | "Válida para buen conductor (σ ≫ 2πfε)" | — | ✔ aproximación declarada |
| 103 | "cobre a 1 MHz ≈ 66 µm" | δ = 66.09 µm | ✔ |
| 122 | "de 10² a 10¹⁰ Hz, el 90 % de los puntos de un barrido lineal cae por encima de 10⁹ Hz" | fracción exacta = 0.900 (200 puntos) | ✔ confirmado |
| 140 | Agua de mar: fórmula deja de valer hacia 10⁸–10⁹ Hz | σ = ωε₀εᵣ en f = 4/(2π·80·ε₀) = 0.90 GHz | ✔ |
| 213, 358 | f(δ = t) = 1/(π μ₀ μᵣ σ t²); cobre, 35 µm → 3.57 MHz | inversión de δ | ✔ (JS 3.565e6 = Py) |
| 217 | R_s = 1/(σδ) | Pozar (1.? superficie), Ulaby 7-6 | ✔ |
| 212 | pendiente log–log = −1/2 | δ ∝ f^{−1/2} | ✔ |
| 233 | Cobre σ = 5.8×10⁷ S/m | 5.8×10⁷ (textos); 5.96×10⁷ (IACS 100 %) | ✔ |
| 233 | Aluminio 3.5×10⁷ | 3.5–3.8×10⁷ | ✔ |
| 233 | Plata 6.3×10⁷ | 6.1–6.3×10⁷ | ✔ |
| 234 | Oro 4.1×10⁷ | 4.1–4.5×10⁷ | ✔ |
| 234 | Hierro 1.0×10⁷, μᵣ = 1000 | σ ≈ 1.0×10⁷ ✔; μᵣ: 200–5000 según pureza, frecuencia y campo | ⚠ orden de magnitud correcto; el texto l.140 ya advierte que μᵣ constante es aproximación |
| 234 | Acero inoxidable 304: 1.4×10⁶ | 1.39×10⁶ | ✔ |
| 235 | Grafito 1×10⁵ | 2×10⁴–3×10⁵ (anisótropo) | ⚠ "orientativo", aceptable con la advertencia de l.140 |
| 235 | Agua de mar 4 | 4–5 | ✔ |
| 390–393 | `delta()` en NumPy | — | ✔ ejecutado, idéntico al JS |
| 396–397 | `np.logspace(e1, e2, N)` / `np.linspace(1e<e1>, 1e<e2>, N)` | — | ✘ **`1e` + exponente no entero → `1e2.5` → SyntaxError** (ver 4.3) |
| 401–404 | `ax.plot(f, d, color=, ls=, marker=, markevery=, lw=, label=)` | API matplotlib 3.x | ✔ (`marker=""` válido = sin marcador; `ls` y `lw` son alias aceptados) |
| 405–408 | `set_xscale("log")`, `set_yscale("log")`, `set_xlabel/ylabel/title`, `axhline(y, color, ls, label)` | API | ✔ |
| 410–411 | `legend(loc=…, title=…)`, `grid(True, which="both", alpha=0.4)` | API | ✔ |
| 412 | `tight_layout()`, `savefig(fname, dpi=…)`, `plt.show()` | API | ✔ (dpi con .pdf es inocuo) |
| 468–471 | Quiz: `1.0 / np.pi * f * …` evalúa (1/π)·f·μ₀μᵣσ; `math.sqrt` falla con arreglos | precedencia Python; TypeError confirmado ("only 0-dimensional arrays can be converted") | ✔ |
| 353–354 | Nota de escala: ley de potencia → recta de pendiente −1/2 en log–log; con eje lineal se aplastan décadas | — | ✔ |
| 336 | En el canvas `loc="best"` se dibuja como "upper right" | matplotlib elige la posición con menos solapamiento | ℹ puede diferir de la figura Python; no es error |
| 223 | Referencias: Jackson 3e §5.18 y §8.1; Hunter 2007 DOI 10.1109/MCSE.2007.55; Harris 2020 DOI 10.1038/s41586-020-2649-2; Rougier 2014 DOI 10.1371/journal.pcbi.1003833 | — | ✔ (secciones y DOI correctos hasta donde conozco) |

### 4.2 Casos de prueba

Valores de δ (JS = NumPy, Δrel = 0):

| f (Hz) | σ (S/m) | μᵣ | δ |
|---|---|---|---|
| 10⁶ | 5.8×10⁷ | 1 | 66.085 µm |
| 10⁹ | 5.8×10⁷ | 1 | 2.0898 µm |
| 10² | 5.8×10⁷ | 1 | 6.6085 mm |
| 60 | 5.8×10⁷ | 1 | 8.5316 mm |
| 10⁶ | 10⁷ (Fe) | 1000 | 5.0329 µm |
| 10⁶ | 4 (mar) | 1 | 25.16 cm |
| 10¹⁰ | 1.4×10⁶ | 1 | 4.2536 µm |

Barrido: `freqs()` log → [100, 109.70, …, 10¹⁰] = `np.logspace(2,10,200)` ✔; lineal → paso 5.025×10⁷ Hz ✔.

Scripts generados y ejecutados con `python3 -I` (backend Agg):
1. Script por defecto (logspace 2–10, Cu + Al, mm, log–log, leyenda, rejilla): **ejecuta sin error**, produce `delta_equipoN.png`.
2. Variante (3 materiales incl. Fe μᵣ=1000, linspace, ejes lineales, unidad µm, línea de referencia 35 µm con etiqueta en leyenda, título de leyenda, rejilla menor, salida .pdf): **ejecuta sin error**, produce `delta_test.pdf`.
3. Variante con f mínima = 10^2.5 y `np.linspace`: genera `f = np.linspace(1e2.5, 1e10, 200)` → **SyntaxError: invalid syntax** (confirmado).

### 4.3 Errores confirmados
- ✘ l.397: `"f = np.linspace(1e"+pyNum(r[0])+", 1e"+pyNum(r[1])+…`. Los campos "f mínima: 10^" / "f máxima: 10^" aceptan decimales (y el rango permitido llega a −3), así que cualquier exponente no entero (2.5, −0.5…) produce código Python inválido. El canvas, en cambio, sí dibuja bien (usa `Math.pow`). Corrección:
  ```js
  :"f = np.linspace(10**"+pyNum(r[0])+", 10**"+pyNum(r[1])+", "+n+")   # Hz, paso uniforme"
  ```
  (o `np.linspace(10.0**a, 10.0**b, n)`). El caso `np.logspace` no tiene el problema.

### 4.4 Coherencia y cobertura
- El canvas reproduce los mismos datos que el script (misma `delta`, mismos barridos, mismas unidades): la figura en pantalla y la de Python coinciden salvo la posición automática de la leyenda ("best").
- La lista de verificación (l.370–380) es coherente con las buenas prácticas citadas (Rougier et al.).
- Laguna menor: el explorador no explica *por qué* `np.logspace` recibe exponentes y `np.linspace` valores (fuente típica de confusión); una línea de comentario en el código generado ayudaría.
- El botón "Guardar la figura" guarda el canvas como PNG aunque el nombre acabe en .pdf/.svg (se renombra a .png, l.494): correcto pero podría sorprender; el script Python sí respeta el formato.

---

## 5. Lista consolidada

### Errores confirmados
| # | Archivo | Línea | Descripción | Corrección propuesta |
|---|---|---|---|---|
| E1 | GuiaOnda_explorador.html | 124, 129, 146–149 | `modos()` limita a m,n ≤ 3 y a 6 modos; `nprop` y el texto "N modos se propagan" se saturan en 6 (WR-90 a 40 GHz, WR-284 a > 6.3 GHz) y el mapa omite TE40/TE50 cuando a/b > 3 | Enumerar m,n hasta ~12, no truncar la lista para contar, dibujar sólo los cortes < f_max del eje; contar TE y TM por separado (ver código en §3.3) |
| E2 | AnatomiaGrafica_explorador.html | 397 | Script generado `np.linspace(1e<a>, 1e<b>, N)` produce `1e2.5` → SyntaxError con exponentes no enteros | `np.linspace(10**a, 10**b, N)` |

### Puntos a verificar / mejoras de presentación (juicio, no error numérico)
| # | Archivo | Línea | Descripción | Propuesta |
|---|---|---|---|---|
| V1 | GuiaOnda | 176 | Etiquetas "TE11", "TE21" ocultan la degeneración con TM11, TM21; el explorador nunca menciona modos TM | Etiquetar "TE/TM11"; añadir frase en el formulario: "para m,n ≥ 1 coexisten TE_mn y TM_mn con la misma f_c; TM11 es el TM dominante" |
| V2 | GuiaOnda | 140, 75–77 | "Banda monomodo" (teórica f_c10–f_c20) vs banda de operación EIA (8.2–12.4 GHz en WR-90) no se distinguen | Mostrar la banda EIA junto a cada botón y explicar que se opera en ≈1.25–1.9 f_c |
| V3 | GuiaOnda | — | Falta Z_TE = η/√(1−(f_c/f)²) (y Z_TM) aunque el tema las incluye | Añadir tile y ecuación |
| V4 | GuiaOnda | 140 | Guía cuadrada: banda monomodo "7.49–7.49 GHz" | Mostrar "— (TE10/TE01 degenerados)" |
| V5 | LineaTransmision | 153–159, 169 | Γ se muestra con 1 decimal (0.3333 → "0.3"; 52+j1 Ω → "0.0" con VSWR 1.04); `replace('±j∞',…)` es código muerto | Formato específico para Γ: módulo con 3 decimales y fase en grados (como en Smith) |
| V6 | LineaTransmision | 174 | \|V\|máx/\|V\|mín es una copia de VSWR, no una medida de la envolvente | Calcular máx/mín numéricos de `envAt` sobre media λ y mostrar que coincide |
| V7 | LineaTransmision | 112 | Formulario sin el caso abierto Z_in = −jZ₀ cot βd ni la posición de máximos (d_mín ± λ/4) | Añadir ambos; dibujar máximos |
| V8 | Smith | 219 | Arrastre limitado a \|Γ\| ≤ 0.985 sin aviso | Mencionarlo o permitir \|Γ\| = 1 en el borde |
| V9 | Smith | 155–161 | Sin etiquetas de x en los arcos ni escala exterior en λ; sin admitancia ni stubs (temas 4.7–4.8) | Etiquetar arcos ±j0.5, ±j1, ±j2; añadir botón "y = 1/z (punto diametral)" y escala en λ |
| V10 | AnatomiaGrafica | 234–235 | μᵣ(Fe) = 1000 y σ(grafito) = 10⁵ son valores orientativos con dispersión de un orden de magnitud en la literatura | Mantener, pero indicar rango en la biblioteca (ya hay advertencia general en l.140) |
| V11 | AnatomiaGrafica | 336 | `loc="best"` se dibuja en el canvas como "upper right"; matplotlib puede colocarla en otro sitio | Nota en pantalla |

### Lo que queda confirmado numéricamente
Todas las fórmulas de Γ, VSWR, envolvente, Z_in(d), d_mín, rotación en la carta de Smith, geometría de los círculos r y x, f_c(mn), λ_g, v_p, v_g, δ y las frecuencias f(δ = t) coinciden con la reimplementación independiente en NumPy con error relativo ≤ 1e-15 en 30+ casos, incluidos los límites de los controles (d/λ = 0 y 1.5; f = 1 y 40 GHz; corto, abierto, adaptado; guía cuadrada). Las dimensiones y f_c de WR-90, WR-284 y WR-42 coinciden con el estándar EIA. Los scripts matplotlib por defecto y con todas las opciones activadas se ejecutan sin error en matplotlib 3.11.2.

Archivos de trabajo: `/tmp/claude-0/-home-claude/59869150-07f9-5bfd-a971-dafcad5e4df4/scratchpad/u4/` (`extract.py`, `lt.js`, `sm.js`, `go.js`, `an.js`, `run_js.js`, `js_out.json`, `verif.py`, `gen_script.js`, `script_default.py`, `script_var.py`, `script_edge.py`, `run/`).
