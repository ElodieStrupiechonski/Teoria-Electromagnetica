# Informe de auditoría física — Unidad 2 (ondas planas)

Archivos auditados (en `/tmp/tem`, sin modificar): `MicroondasC_explorador.html`, `EfectoPiel_explorador.html`, `Polarizacion_explorador.html`, `Doppler_explorador.html`, `Espectro_explorador.html`.

Método: lectura íntegra del HTML/JS; extracción literal de las funciones de cálculo a `js_extract.js` y ejecución con `node` (`run_js.js` → `js_out.json`) para obtener las salidas exactas del JS; reimplementación independiente en Python/numpy (`verifica.py`, ejecutado con `python3 -I`) con constantes CODATA 2018 y las fórmulas generales (no las aproximadas) para comparar. Todo está en `/tmp/claude-0/-home-claude/59869150-07f9-5bfd-a971-dafcad5e4df4/scratchpad/u2/`.

Leyenda de veredictos: ✔ correcto · ✘ error confirmado · ⚠ requiere verificación/juicio · ℹ aproximación no declarada.

Resumen ejecutivo: la aritmética de los cinco exploradores es correcta en su dominio nominal (diferencias con la reimplementación ≤ 0.3 %, atribuibles a redondeo de constantes). Los problemas reales son de **modelo y de coherencia**: (1) Efecto piel dibuja H *adelantada* 45° cuando el texto dice "retrasada"; (2) Efecto piel aplica δ = 1/√(πfμσ) fuera del régimen de buen conductor (hasta −98 % en agua de mar a THz) aunque el propio panel declare "cuasi-dieléctrico"; (3) Doppler usa la fórmula acústica de fuente móvil para "ondas electromagnéticas" con un control que llega a v/c = 0.7 (error del 40 %) sin declararlo; (4) Espectro: la frontera IR/visible está en 703 nm mientras el zoom y el color dicen 750 nm (incoherencia interna); (5) Microondas: para f < 188 MHz (accesible por la casilla numérica) el ajuste automático produce c = 0.9×10⁸ m/s; (6) Polarización clasifica como "Circular" elipses con relación axial hasta 1.33 y afirma "−3 dB sin importar la orientación", cosa que sus propios números no cumplen.

---

## 1. `MicroondasC_explorador.html` — tema 2.3, práctica P5

### 1.1 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 154 | `c0 = 299792458` m/s | CODATA (exacto) | ✔ |
| 156 | λ[cm] = 100·c₀/f | λ = c/f | ✔ |
| 159 | antinodos en x = λ/4 + m·λ/2 (pared en x = 0) | Onda estacionaria ante conductor: E ∝ sin(kz); nodo en la pared, primer antinodo a λ/4 (Ulaby 6e §8-1, incidencia normal sobre conductor perfecto; Griffiths 4e §9.2.1 para la superposición) | ✔ |
| 122, 132 | E(x,t) = 2E₀ sin(kx) cos(ωt) (texto) | E(z,t) = 2E₀ sin(kz) sin(ωt) en Ulaby 8-1 (misma envolvente espacial; la fase temporal depende de la convención) | ✔ |
| 211–212 | d = D/n; c = 2·(d/100)·f | c = fλ = 2df | ✔ |
| 221 | err = (c_med − c₀)/c₀·100 | error relativo porcentual | ✔ (no hay propagación de incertidumbre) |
| 252 | calculadora "con tus datos": idem | idem | ✔ |
| 225–226 | `snap()`: si hay < 2 antinodos en la ventana → h₁ = λ/4, h₂ = min(W, h₁+λ/2), n = 1 | Caso degenerado mal resuelto: cuando λ/2 no cabe, h₂ se recorta a W y el cociente deja de ser λ/2 | ✘ (ver caso 5) |
| 157 | ventana W = clamp(5.5·λ/2, 20, 120) cm | — | ⚠ origen del bug anterior |
| 182 | mancha de calor = gaussiana σ = λ/10 en cada antinodo | El calentamiento real ∝ E² ∝ sin²(kx) (lo dice el texto en l. 121) | ℹ estética, no cuantitativa |
| 127 | "f = 2.45 GHz → λ ≈ 12.2 cm, d ≈ 6.1 cm" | λ = 12.24 cm, d = 6.12 cm | ✔ |
| 73–78 | 2.45 GHz doméstico, 915 MHz industrial | bandas ISM 2.4–2.5 GHz y 902–928 MHz | ✔ |

### 1.2 Casos de prueba (JS vía node vs. reimplementación)

| # | Entrada | Salida JS | Valor independiente | Δ rel. |
|---|---|---|---|---|
| 1 | f = 2450 MHz, `snap` (defecto): W = 35 cm, n = 5, D = 30.59 cm | d = 6.12 cm, c = 2.998×10⁸, err −0.0 % | 2.9979×10⁸ | 0 |
| 2 | f = 915 MHz, `snap`: W = 95, n = 5, D = 81.91 | d = 16.38 cm, c = 2.998×10⁸ | 2.9979×10⁸ | 0 |
| 3 | f = 300 MHz (mín. deslizador): W = 120, n = 1, D = 49.97 | c = 2.998×10⁸ | 2.9979×10⁸ | 0 |
| 4 | f = 6000 MHz (máx. casilla): W = 20, n = 7 | c = 2.998×10⁸ | idem | 0 |
| 5 | **f = 100 MHz (mín. casilla)**: W = 120, antinodos = [74.9], fallback h₂ = 120 → D = 45.05, n = 1 | **c = 9.010×10⁷ m/s, err −69.9 %** | 2.998×10⁸ (λ/2 real = 149.9 cm) | **−70 %** |
| 6 | "con tus datos" precargado: 2450 MHz, D = 23 cm, n = 3 | d = 7.67, λ = 15.33 cm, c = 3.757×10⁸, +25.3 % | 3.7567×10⁸ | 0 |
| 7 | 2450 MHz, D = 24.5, n = 4 | c = 3.001×10⁸, +0.1 % | 3.0012×10⁸ | 0 |
| 8 | 915 MHz, D = 49.2, n = 3 | c = 3.001×10⁸ | 3.0012×10⁸ | 0 |

Caso 5: el fallo aparece para toda f < 187.7 MHz (condición λ/4 + λ/2 > 119.8 cm). Solo es alcanzable por la casilla `fnum` (min = 100), no por el deslizador (min = 300). Confirmado numéricamente.

### 1.3 Coherencia interna
- Curva E(x), marcas de nodos (cada λ/2 desde x = 0) y manchas (en λ/4 + mλ/2) son mutuamente coherentes ✔.
- Las cifras del panel (D, d, c, error) corresponden a la misma magnitud que dibuja el calibrador ✔.
- "Error relativo" muestra "−0.0 %" para el caso exacto (cosmético, `toFixed(1)` sobre un valor −1e-14).
- El dato precargado "real" (D = 23 cm, n = 3) da +25 %; la nota (l. 115) lo justifica por multimodo 3D. Es un juicio razonable, pero el explorador no lo cuantifica.

### 1.4 Cobertura del tema 2.3 (onda plana en espacio libre, velocidad de propagación)
- Cubre: c = fλ, onda estacionaria, medición de c. No cubre: relación c = 1/√(μ₀ε₀) (la constante aparece sólo como valor aceptado), ni la relación k = 2π/λ, ω = 2πf. Sugerencia: añadir la línea c = 1/√(μ₀ε₀) = 2.998×10⁸ m/s en "Formulario".
- **Incertidumbre (P5)**: no hay propagación de errores. Con D = 23 ± 0.5 cm y n = 3, δc/c = δD/D = 2.2 %, muy inferior al 25 % observado: eso es justamente el argumento pedagógico de que el error es sistemático (multimodo), y vale la pena mostrarlo. Propuesta: casilla "incertidumbre en D (cm)" y tile "δc/c = δD/D" (la frecuencia de placa puede tomarse exacta; la deriva del magnetrón es ~±10 MHz, 0.4 %).

---

## 2. `EfectoPiel_explorador.html` — tema 2.6, práctica P6

### 2.1 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 134 | μ₀ = 4π×10⁻⁷, ε₀ = 8.854×10⁻¹² | CODATA (μ₀ = 1.25663706×10⁻⁶ exacto a 1e-10) | ✔ |
| 136 | σ: Cu 5.8×10⁷, Al 3.5×10⁷, Au 4.1×10⁷, agua de mar 4 S/m, εᵣ = 81 | Ulaby 6e Apéndice B: Cu 5.8×10⁷, Al 3.5×10⁷, Au 4.1×10⁷, agua de mar 4 (εᵣ ≈ 80, 72–81 según texto) | ✔ |
| 140 | δ = 1/√(πfμ₀σ) para **cualquier** régimen | Válida sólo si σ/ωε ≫ 1 (Ulaby §7-4.2, ec. de buen conductor; Griffiths §9.4.1 ec. 9.128 con el mismo límite). Fórmula general: α = ω√(με/2)·[√(1+(σ/ωε)²) − 1]^{1/2}, δ = 1/α (Ulaby 7-4, ecs. 7.66a) | ✘ cuando el panel dice "intermedio" o "cuasi-dieléctrico" (ver casos 8–9) |
| 141 | tan δ_p = σ/(ωε) con ε = εᵣε₀ | tangente de pérdidas, Ulaby §7-4 (ε″/ε′ = σ/ωε) | ✔ (pero el valor no se muestra al estudiante) |
| 142 | θ_η = ½ arctan(σ/ωε) | η_c = √(μ/ε)·(1 − jσ/ωε)^{−1/2} ⇒ ∠η_c = ½ arctan(σ/ωε); → 45° en buen conductor (Ulaby 7-4, Griffiths 9.4.1) | ✔ (coincide con mi cálculo complejo en los 10 casos: 45.0°, 20.8°, 0.0°) |
| 117 | α = β = 1/δ | sólo buen conductor (Ulaby 7-4.2) | ℹ no declarado como aproximación |
| 151 | R_s = 1/(σδ) | R_s = 1/(σδ_s) = √(πfμ/σ), Ulaby §7-5 (ec. 7.92) | ✔ (en buen conductor) |
| 153 | régimen: tanδ > 10 "buen conductor", < 0.1 "cuasi-dieléctrico" | Ulaby usa ≥ 100 y ≤ 0.01 como criterios de aproximación | ⚠ umbrales más laxos que el libro (la etiqueta "buen conductor" entre 10 y 100 implica errores de hasta ~1 % en δ) |
| 171 | H dibujado como e^{−u}·cos(u − t − lag), E como e^{−u}·cos(u − t) | Con fase ωt − βz, H = (E₀/|η_c|)e^{−αz} cos(ωt − βz − θ_η): H **se retrasa** θ_η. En el código la fase de H es (t − u + lag): **H adelanta** | ✘ confirmado numéricamente (pico de E en t = 0, pico de H en t = −lag mod 2π = 5.498 rad, es decir, antes) |
| 72, 119 | "cae al 37 % en δ, ~5 % en 3δ" | e⁻¹ = 0.368, e⁻³ = 0.050 | ✔ |
| 120 | "por arriba del infrarrojo el modelo es orientativo (efectos de plasma)" | Para Cu, τ_Drude ≈ 2.5×10⁻¹⁴ s ⇒ ωτ ~ 1 ya a ~6 THz: σ(ω) deja de ser real/constante desde el THz, no "por arriba del IR" | ⚠ afirmación demasiado optimista |
| 136 | agua de mar εᵣ = 81 fijo hasta 1 PHz | εᵣ del agua cae de ~80 a ~5 por relajación de Debye (~20 GHz) y el modelo σ constante no aplica en THz/óptico | ⚠ tabla válida sólo ≲ 1 GHz |
| 121 | "μ ≈ μ₀ para los materiales de aquí" | correcto para Cu, Al, Au, agua; no hay entrada μᵣ | ℹ limita P6 (no se puede modelar acero/hierro) |

### 2.2 Casos de prueba

| # | Material, f | δ JS | δ buen conductor (indep.) | δ = 1/α general | Δ JS vs general | ∠η JS / indep. | Régimen JS |
|---|---|---|---|---|---|---|---|
| 1 | Cu, 1 MHz (defecto) | 66.09 µm | 66.085 µm | 66.085 µm | 0 | 45.0 / 45.0 | buen conductor |
| 2 | Cu, 1 kHz (mín.) | 2.090 mm | 2.0898 mm | 2.0898 mm | 0 | 45.0 | buen conductor |
| 3 | Cu, 60 Hz | 8.532 mm | 8.5316 mm | 8.5316 mm | 0 | 45.0 | buen conductor (valor tabulado ≈ 8.5 mm ✔) |
| 4 | Cu, 1 PHz (máx.) | 2.1 nm | 2.0898 nm | 2.0908 nm | −0.05 % | 45.0 | "buen conductor" (tanδ = 1.0×10³; físicamente sin sentido: Cu es plasma ya a 1 PHz) |
| 5 | Al, 1 GHz | 2.69 µm | 2.6902 µm | 2.6902 µm | 0 | 45.0 | buen conductor |
| 6 | Au, 2.45 GHz | 1.59 µm | 1.5880 µm | 1.5880 µm | 0 | 45.0 | buen conductor |
| 7 | mar, 1 MHz | 251.6 mm | 251.65 mm | 251.79 mm | −0.1 % | 45.0 | buen conductor (tanδ = 888) |
| 8 | **mar, 1 GHz** | 7.958 mm | 7.958 mm | **12.91 mm** | **−38 %** | 20.8 / 20.8 | "intermedio" (tanδ = 0.89) |
| 9 | **mar, 1 THz** | 251.6 µm | 251.6 µm | **11.95 mm** | **−98 %** | 0.0 / 0.0 | "cuasi-dieléctrico" (tanδ = 8.9×10⁻⁴) |
| 10 | Cu 1 MHz: R_s JS = 2.61×10⁻⁴ Ω | — | R_s = √(πfμ₀/σ) = 2.609×10⁻⁴ Ω; \|η_c\| = √2·R_s = 3.69×10⁻⁴ Ω (coincide con \|η_c\| complejo) | — | 0 | | |

Casos 8–9: el panel detecta correctamente el régimen (el ángulo 20.8° y 0.0° son los del cálculo complejo exacto) pero sigue mostrando δ, α y R_s de buen conductor. En el caso 9, además, el tile "Atenuación α = 1/δ" da 3.97×10³ Np/m cuando la α real (con εᵣ = 81 constante) es 83.7 Np/m, y la curva δ(f) log–log sigue una recta de pendiente −½ hasta 1 PHz para agua de mar, cuando debería aplanarse en ~1.2 cm a partir de ~1 GHz (régimen de bajas pérdidas: α → (σ/2)√(μ/ε), independiente de f).

### 2.3 Coherencia interna
- Curva principal: envolvente, E y marcas 1δ–3δ coherentes con δ del panel ✔. Fase H–E: **incoherente** con el texto (l. 108, 119: "H se retrasa 45°") — ✘.
- Gráfica δ(f): escala fija 1 kHz–1 PHz, 1 nm–10 m; banda "visible" sombreada en 4.27–7.94×10¹⁴ Hz (702–377 nm) ✔ aproximado.
- Tile "Desfase de H respecto de E" = θ_η ✔ (correcto en todos los regímenes).
- Rótulo "Profundidad δ = 1/√(πfμσ)" aparece aun cuando el régimen no es buen conductor — el estudiante ve una fórmula y una etiqueta de régimen que se contradicen.

### 2.4 Cobertura del tema 2.6 (tangente de pérdidas, buen conductor)
- Cubre: δ, decaimiento, R_s, ángulo de η, régimen. **No muestra**: el valor numérico de tan δ_p = σ/ωε (sólo se usa internamente, l. 141) — es el concepto central del tema; η_c = (1+j)/(σδ) (sólo el ángulo; falta |η_c| = √2/(σδ) y el valor); λ dentro del conductor = 2πδ y u_p = ωδ (Ulaby 7-4.2), que ilustran muy bien por qué "la onda apenas entra"; la fórmula general de α y β (Ulaby 7.66) que delimita la aproximación.
- Materiales: faltan plata (6.1×10⁷ S/m) y hierro/acero (σ ≈ 1×10⁷, μᵣ ≈ 50–5000 → δ mucho menor): sin entrada μᵣ el explorador no puede mostrar por qué el hierro apantalla mejor a baja frecuencia, relevante para la jaula de Faraday de P6.
- P6 (apantallamiento): sería natural un tile "atenuación de un espesor t: 20·t/(δ·ln10) dB" (p. ej. papel aluminio 16 µm a 1 GHz: 6 δ → 52 dB sólo por absorción).

---

## 3. `Polarizacion_explorador.html` — tema 2.8, práctica P7

### 3.1 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 112, 148 | E_x = A cos ωt, E_y = B cos(ωt + δ) en un punto fijo | Ulaby 6e §7-2 (ec. 7.29 con z = 0): E_x = a_x cos(ωt − kz), E_y = a_y cos(ωt − kz + δ) | ✔ misma convención que Ulaby |
| 164 | sentido: sin δ > 0 → "horario (en pantalla)", z hacia el observador | dψ/dt ∝ E_x Ė_y − E_y Ė_x = −ωAB sin δ ⇒ sin δ > 0 ⇒ horario visto con la onda acercándose | ✔ confirmado numéricamente |
| 164 | **no se nombra RHCP/LHCP ni se declara convención** | Con esta convención (Ulaby ec. 7.36–7.37): δ = +90° es **LHC (IEEE)**: visto a lo largo de +z (desde atrás) gira antihorario, mano izquierda con pulgar en +z. En convención óptica (Hecht, Born–Wolf: observador mirando hacia la fuente) ese mismo giro horario se llama **derecha**. | ⚠ omisión que el tema 2.8 exige (ver §3.4) |
| 164 | circular si \|A−B\| < 0.04 **y** \|sin δ − 1\| < 0.04 | A = B y δ = ±90° exactos; con tolerancia, el criterio natural es AR < 1 + ε | ✘ el umbral admite δ ∈ (73.7°, 106.3°) ⇒ AR hasta 1.33 clasificado "Circular" (caso 11) |
| 165 | relación axial por barrido numérico (180 puntos, paso 2°) | AR = √(λ_max/λ_min) de la matriz [[A², AB cos δ],[AB cos δ, B²]]; equivalente a Balanis AEE §4.4 / Ulaby 7-2.3 | ✔ (error −0.3 % por el paso de 2°: 2.41 vs 2.414, 3.72 vs 3.732) |
| 166 | PLF = (A²cos²θ + B²sin²θ + 2AB cosθ sinθ cos δ)/(A²+B²) | PLF = \|ρ̂_w·ρ̂_a\|² con ρ̂_w = (A, Be^{jδ})/√(A²+B²), ρ̂_a = (cos θ, sin θ) (Balanis, *Antenna Theory* §2.12; para onda y antena lineales = cos²θ, ley de Malus) | ✔ coincide con mi cálculo con vectores complejos en 15 casos |
| 246 | PLF en dB = 10 log₁₀(PLF) | potencia → 10 log | ✔ |
| 143, 250 | "circular: −3 dB sin importar la orientación" | PLF = ½ exacto si AR = 1 | ✔ sólo si es realmente circular (ver caso 11) |
| 149 | lineal si δ = 0°/180° o AB = 0; circular A = B, δ = ±90° | Ulaby 7-2.1/7-2.2 | ✔ |

### 3.2 Casos de prueba (θ = orientación de la antena)

| # | A, B, δ, θ | JS: tipo / giro / AR / PLF (dB) | Indep.: AR / PLF / giro / (ψ, χ) | Δ |
|---|---|---|---|---|
| 1 | 1, 1, 90°, 0° (defecto) | Circular / horario / 1.00 / 0.500 (−3.0) | 1.000 / 0.500 / horario = LHC-IEEE / (45°, 45°) | 0 |
| 2 | 1, 1, 90°, 45° | Circular / 0.500 (−3.0) | 0.500 | 0 |
| 3 | 1, 1, 270°, 0° | Circular / antihorario / 0.500 | antihorario = RHC-IEEE / (−45°, −45°) | 0 |
| 4 | 1, 0, 0°, 0° | Lineal / ∞ / 1.000 (0 dB) | 1.000 | 0 |
| 5 | 1, 0, 0°, 90° | Lineal / 0 (−∞) | 3.7×10⁻³³ ≈ 0 | 0 |
| 6 | 1, 0, 0°, 60° | Lineal / 0.250 (−6.0) | cos²60° = 0.25 | 0 |
| 7 | 1, 0.5, 90°, 0° | Elíptica / 2.00 / 0.800 (−1.0) | 2.000 / 0.800 / (0°, 26.6°) | 0 |
| 8 | 1, 0.5, 90°, 90° | Elíptica / 0.200 (−7.0) | 0.200 | 0 |
| 9 | 1, 1, 45°, 45° | Elíptica / 2.41 / 0.854 (−0.7) | 2.414 / 0.8536 / (45°, 22.5°) | AR −0.2 % |
| 10 | 0.6, 0.8, 180°, 53.13° | Lineal / 0.078 (−11.1) | 0.0784 (E a −53.13°, antena a +53.13° ⇒ cos²106.26°) | 0 |
| 11 | **1, 1, 74°, 45° / 135°** | **"Circular"**, AR tile = 1.33, verdict "−3 dB sin importar la orientación" | AR = 1.327; PLF(45°) = 0.638 (−2.0 dB), PLF(135°) = 0.362 (−4.4 dB) | contradicción interna |
| 12 | 1, 1, 30°, 0° | Elíptica / 3.72 / 0.500 | 3.732 / 0.500 / (45°, 15°) | −0.3 % |

### 3.3 Coherencia interna
- Figura izquierda (trayectoria y vector), gráfica E_x(t), E_y(t) y marcador de instante usan la misma fase (t, t + δ) ✔. Ejes 0, T, 2T con PM = 4π ✔.
- Perilla: θ medido desde +x en sentido antihorario en pantalla; coincide con ρ̂_a = (cos θ, sin θ) del PLF ✔.
- Caso 11: el tile "Relación axial" (1.33) y el tile "Tipo" ("Circular") se contradicen, y el veredicto textual afirma algo que el medidor de señal desmiente al girar la perilla.

### 3.4 Cobertura del tema 2.8
- Cubre: lineal/circular/elíptica, elipse trazada, sentido de giro en pantalla, AR, PLF/ley de Malus, enlace satélite.
- **Falta**: (a) nomenclatura RHCP/LHCP y declaración de convención (IEEE "pulgar en la dirección de propagación" vs. óptica); es el punto más confuso del tema y el explorador lo evita con "horario (en pantalla)". Propuesta: tile "Mano (IEEE)": sin δ > 0 → "izquierda (LHCP)", sin δ < 0 → "derecha (RHCP)", con nota de que en óptica los nombres se invierten; (b) parámetros de la elipse ψ (inclinación) y χ (elipticidad): tan 2ψ = tan 2ψ₀·cos δ, sin 2χ = sin 2ψ₀·sin δ, tan ψ₀ = B/A (Ulaby 7-2.3, ecs. 7.48–7.49), con AR = cot|χ|; (c) escritura fasorial Ẽ = (x̂A + ŷBe^{jδ})e^{−jkz} que conecta con el resto de la unidad; (d) el enlace satélite nombra GPS pero no dice que GPS es RHCP; (e) el caso "antena circular + onda circular de mano contraria → PLF = 0" (aislamiento de polarización, Balanis §2.12), que es la razón real por la que los satélites reutilizan frecuencia con dos manos.

---

## 4. `Doppler_explorador.html` — tema 2.9

### 4.1 Fórmulas implementadas

| Línea | Fórmula implementada | Referencia correcta | Veredicto |
|---|---|---|---|
| 122, 186, 210–211 | f′ = f/(1 ∓ v/c) (fuente móvil, observador en reposo) | Fórmula **acústica** (medio en reposo). Para ondas EM no hay medio: f′ = f·√((1 ± β)/(1 ∓ β)) (Doppler relativista longitudinal; Griffiths 4e cap. 12, relatividad especial). La diferencia es γ = 1/√(1−β²): f_acústica/f_relativista = 1/√(1−β²) | ✘ para "ondas electromagnéticas" con β hasta 0.7 (error 0.5 % en β = 0.1, 15 % en 0.5, 40 % en 0.7); la nota (l. 124) explica la elección pero **no** dice que es no relativista |
| 123 | Δf/f ≈ v/c | límite v ≪ c de ambas fórmulas | ✔ |
| 215–224 | animación de frentes: círculos de radio creciente centrados en posiciones sucesivas de la fuente | Correcta para EM en el marco del observador (cada frente se expande a c desde el punto de emisión); sólo falta la dilatación del intervalo de emisión por γ | ✔ cualitativo |
| 230 | señales: f factores 1/(1∓β) | idem l. 210 | coherente con sección 1 |
| 254–255 | curva f′/f = 1/(1∓β) hasta β = 0.7 | relativista √((1+β)/(1−β)) | ✘ (mismo error) |
| 163, 270 | z = Δλ/λ; se toma **z ≡ v/c** (las casillas "v/c" y "z" son el mismo número, l. 320–328) | z = v/c sólo si v ≪ c; relación exacta 1+z = √((1+β)/(1−β)) ⇒ β = ((1+z)²−1)/((1+z)²+1); además el corrimiento cosmológico no es un Doppler cinemático | ℹ declarado "válida para v ≪ c" en l. 166, pero el control llega a z = 0.3 (17 % de error en v) |
| 164, 285, 301 | λ_obs = λ(1+z) | definición | ✔ |
| 302 | v = z·c | ver arriba | ℹ |
| 261 | Hγ 434.0, Hβ 486.1, Na 589.0, Hα 656.3 nm | 434.05, 486.13, 588.99/589.59 (doblete D), 656.28 nm | ✔ |
| 190 | H₀ ≈ 70 km·s⁻¹·Mpc⁻¹ | Planck 2018: 67.4 ± 0.5; SH0ES: 73.0 ± 1.0 → "≈ 70, en discusión" es correcto | ✔ |
| 165 | v = H₀d (sólo texto) | ley de Hubble | ✔ pero no se calcula d |
| 180, 308 | Δf = k·f·(v/c), k = 2 radar, k = 1 un trayecto | Pozar, *Microwave Engineering* 4e §14.3 (radar Doppler): f_d = 2v f₀/c | ✔ |
| 309–311 | f′ mostrada con `toFixed(4)` GHz | resolución 100 kHz: un Δf de 2 kHz no se ve ("f′ = 10.0000 GHz") | ⚠ presentación |
| 286 | λ_obs > 780 nm se recorta a 780 en la figura, pero la etiqueta numérica sigue | para z > 0.188 Hα sale de la franja; la línea queda pegada al borde con un número que ya no corresponde a la posición | ⚠ presentación |

### 4.2 Casos de prueba

| # | Entrada | Salida JS | Acústica (indep.) | Relativista (correcta para EM) | Δ JS vs relativista |
|---|---|---|---|---|---|
| 1 | β = 0.30 (defecto) | f_adelante = 1.43 f, f_atrás = 0.77 f | 1.429 / 0.769 | 1.363 / 0.734 | +4.8 % |
| 2 | β = 0.10 | 1.11 / 0.91 | 1.111 / 0.909 | 1.106 / 0.905 | +0.5 % |
| 3 | β = 0.50 | 2.00 / 0.67 | 2.000 / 0.667 | 1.732 / 0.577 | +15.5 % |
| 4 | β = 0.70 (máx.) | 3.33 / 0.59 | 3.333 / 0.588 | 2.380 / 0.420 | +40 % |
| 5 | z = 0.10 (defecto) | Hα → 722 nm, v = 29 979 km/s | λ = 721.9 nm; v_clásica = 29 979 | v_rel = 28 487 km/s | +5.2 % |
| 6 | z = 0.30 (máx.) | Hα → 853 nm, v = 89 938 km/s | 853.2 nm | v_rel = 76 898 km/s | +17 % |
| 7 | radar 10 GHz, 30 m/s, acerca, k = 2 | Δf = +2.00 kHz, "f′ = 10.0000 GHz" | 2001.38 Hz | 2001.38 Hz (exacto relativista 2×1000.69) | 0 |
| 8 | 24 GHz, 40 m/s, k = 2 | 6.40 kHz | 6404.43 Hz | idem | 0 |
| 9 | 1.575 GHz, 7000 m/s (satélite LEO), k = 1 | 36.78 kHz | 36 775.44 Hz | 36 775.87 Hz | −1×10⁻⁵ |
| 10 | 2.45 GHz, 0.1 m/s, k = 2 | 1.6 Hz | 1.634 Hz | idem | 0 |

La calculadora (sección 4) es correcta; el problema está en las secciones 1–3 por el rango de β permitido.

### 4.3 Coherencia interna
- Secciones 1, 2 y la curva usan la misma fórmula ⇒ coherentes entre sí ✔; pero el título de la cita ("Efecto Doppler electromagnético") y el encabezado "Teoría Electromagnética" no concuerdan con la física implementada para β > 0.1.
- Sección 3: las dos casillas de entrada ("v/c" y "z") escriben el mismo valor y el tile "Velocidad de recesión" = z·c; el estudiante puede creer que z = β es una identidad.
- Sección 4: f′ con 4 decimales de GHz oculta el corrimiento (caso 7).

### 4.4 Cobertura del tema 2.9
- Cubre: idea cualitativa, fuente móvil, corrimiento al rojo, Hubble, radar.
- Falta: fórmula relativista (la única correcta para EM) y su comparación con la acústica; caso observador móvil (en acústica difiere de fuente móvil; en EM no — eso es justamente la enseñanza del tema); distinción Doppler cinemático vs. corrimiento cosmológico; cálculo de d = v/H₀ (con z = 0.1 → 428 Mpc) ya que la ley de Hubble se enuncia; Doppler transversal (opcional).

---

## 5. `Espectro_explorador.html` — transversal

### 5.1 Fórmulas y datos implementados

| Línea | Implementado | Valor correcto / referencia | Veredicto |
|---|---|---|---|
| 135 | c = 2.998×10⁸, h = 6.626×10⁻³⁴, e = 1.602×10⁻¹⁹ | 2.99792458×10⁸; 6.62607015×10⁻³⁴; 1.602176634×10⁻¹⁹ (CODATA 2018, exactos) | ✔ (desviación 0.003 % en λ, 0.010 % en E) |
| 199 | λ = c/f; E = hf; E_eV = E/e; ν̄ = f/(100c) | ν̄[cm⁻¹] = 1/λ[cm] | ✔ (coincide a 0.01 % en 25 casos) |
| 115, 192 | número de onda espectroscópico ν̄ = 1/λ en cm⁻¹ (declarado) | distinto de k = 2π/λ rad/m usado en toda la unidad | ✔ declarado; ℹ falta aclarar k = 2πν̄·100 |
| 116, 124 | 1240/λ[nm]; 1 eV ↔ 8065.5 cm⁻¹ ↔ 2.418×10¹⁴ Hz; hc = 1240 eV·nm; h = 4.136×10⁻¹⁵ eV·s | hc = 1239.84 eV·nm; 8065.54 cm⁻¹; 2.4180×10¹⁴ Hz; 4.1357×10⁻¹⁵ eV·s | ✔ |
| 143 | Radio 10³–10^8.5 Hz; Microondas 10^8.5–10^11.48 (316 MHz–302 GHz) | convención 300 MHz–300 GHz (log 8.477–11.477) | ✔ (±5 %) |
| 144 | THz 10^11.48–10^13 (0.30–10 THz) | "THz gap" usual 0.1–10 THz; 0.3–10 es también común | ✔ convención (hay traslape con mm-wave, lo advierte l. 86) |
| 144 | IR 10^13–10^14.63 (30 µm–**702.8 nm**) | el propio explorador define el visible como 750–380 nm (l. 106, 245, 267) | ✘ incoherencia interna |
| 145 | Visible 10^14.63–10^14.90 (702.8–377.4 nm) | 750–380 nm ⇒ log 14.602–14.897 | ✘ límite rojo; el límite violeta (377 vs 380 nm) es despreciable |
| 145 | UV 10^14.90–10^16.5 (377–9.5 nm) | ~400–10 nm | ✔ |
| 146 | Rayos X 10^16.5–10^19.7 (9.5 nm–6 pm, 131 eV–207 keV); γ > 207 keV | frontera X/γ convencional ~100 keV (o por origen nuclear) | ⚠ convención aceptable |
| 148 | banderas: FM 10⁸ (100 MHz); 4G 10^9.26 (1.82 GHz); 5G sub-6 10^9.54 (3.47 GHz); 5G mmW 10^10.45 (28.2 GHz); 1 THz | FM 88–108 MHz ✔; LTE banda 3 1.8 GHz ✔; n78 3.3–3.8 GHz ✔; n257 26.5–29.5 GHz ✔ | ✔ |
| 212 | presets: FM 100 MHz, WiFi 2.4 GHz, 5G 3.5 GHz, 28 GHz, 1 THz, IR 10 µm, 550 nm, UV 300 nm, X 0.1 nm (12.4 keV), γ 1 pm (1.24 MeV) | todos correctos | ✔; faltan horno 2.45 GHz y GPS L1 1.575 GHz (mencionados en otros exploradores) |
| 245 | violeta 380–450, azul 450–485, cian 485–500, verde 500–565, amarillo 565–590, naranja 590–625, rojo 625–750 nm | tabla estándar | ✔ |
| 247–256 | RGB aproximado (Bruton) | estético | ✔ |
| 108 | "menos de una octava de las ~60 que abarca el espectro completo" | visible: log₂(750/380) = 0.98 ✔; el eje del explorador (1 kHz–1 YHz) abarca 69.8 octavas; el espectro físico no tiene límites | ⚠ "~60" es impreciso; decir "las ~70 del eje mostrado" |
| 158 | formato de λ | 1 pm se muestra como "1000.00 fm" (redondeo 9.99…×10⁻¹³ < 10⁻¹²) | ⚠ cosmético |
| 159 | formato de E | 1 eV exacto se muestra "1000.00 meV" | ⚠ cosmético |

### 5.2 Casos de prueba (JS vs CODATA)

| # | Entrada | JS: banda / f / λ / E / ν̄ / color | Independiente | Δ |
|---|---|---|---|---|
| 1 | log f = 14.74 (defecto) | Visible / 549.54 THz / 545.55 nm / 2.27 eV / 1.83×10⁴ cm⁻¹ / verde | 545.53 nm, 2.2727 eV, 18 331 cm⁻¹ | +0.003 % / +0.01 % |
| 2 | WiFi 2.4 GHz | Microondas / 12.49 cm / 9.93 µeV / 0.080 cm⁻¹ | 12.491 cm, 9.926 µeV | 0 |
| 3 | 2.45 GHz (tecleado) | Microondas / 12.24 cm / 10.13 µeV | 12.236 cm | 0 |
| 4 | 1 THz | Terahertz / 299.80 µm / 4.14 meV / 33.356 cm⁻¹ | 299.79 µm, 4.1357 meV, 33.356 cm⁻¹ | 0 |
| 5 | IR 10 µm | Infrarrojo / 29.98 THz / 124.00 meV / 1000.000 cm⁻¹ | 29.979 THz, 123.98 meV, 1000 cm⁻¹ | 0 |
| 6 | X 0.1 nm | Rayos X / 3.00 EHz / 12.40 keV / 10⁸ cm⁻¹ | 12.398 keV | 0 |
| 7 | γ 1 pm | Rayos gamma / "1000.00 fm" / 1.24 MeV | 1.2398 MeV | 0 (formato) |
| 8 | log f = 3 (mín.) | Radio / 1 kHz / 299.80 km / "0.00 neV" / 3.34×10⁻⁸ | 4.136×10⁻¹² eV | formato pierde el valor |
| 9 | log f = 24 (máx.) | γ / 1 YHz / 0.30 fm / 4.14 GeV | 4.1357 GeV | 0 |
| 10 | **λ = 750 nm** | **Banda "Infrarrojo"**, color "rojo", el zoom visible muestra el cursor dentro | 750 nm es el borde rojo del visible según la propia página | incoherencia |
| 11 | λ = 700 nm | Visible / rojo | ✔ | — |
| 12 | λ = 380 nm | Visible / violeta | ✔ | — |
| 13 | E = 1 eV | Infrarrojo / 1.24 µm / "1000.00 meV" / 8064.5 cm⁻¹ | 1239.8 nm, 8065.5 cm⁻¹ | formato |

### 5.3 Coherencia interna
- Cuatro ejes alineados (f, λ, E, ν̄) con un único cursor: comprobé que las marcas 1 GHz / 30 cm / 4.1 µeV / 0.033 cm⁻¹ coinciden en la misma x (todas se derivan de log f con las mismas constantes) ✔.
- Banda visible: el gradiente del eje principal (rojo izq.→violeta der.) y el zoom (750 izq.→380 der.) son coherentes con f creciente ✔.
- Tile "Banda" vs tile "Color" vs zoom: **incoherentes entre 703 y 750 nm** (caso 10).
- Texto "Fórmulas de conversión": ν̄ = f/(100·c) ✔ coincide con el código.

### 5.4 Cobertura (transversal)
- Cumple su propósito. Sugerencias: añadir preset "Horno de microondas 2.45 GHz" y "GPS L1 1.575 GHz" (los usan los exploradores de 2.3 y 2.9); añadir un quinto renglón o una nota con k = 2π/λ (rad/m) y ω = 2πf, que son las variables de la unidad; nombrar sub-bandas de radio/microondas (HF, VHF, UHF, L, S, C, X, Ku, Ka) ya que el curso trabaja en bandas de radar/guía de onda.

---

## 6. Lista consolidada

### 6.1 Errores confirmados (numéricamente o por lectura directa del código)

| # | Archivo · línea | Descripción | Corrección propuesta |
|---|---|---|---|
| E1 | `EfectoPiel_explorador.html` · 171 | H se dibuja **adelantada** θ_η respecto de E (`cos(u-t-lag)`), contradiciendo el texto (l. 108, 119) y la física (Griffiths 9.4.1: B se retrasa 45°). Verificado: pico de H en t = −lag. | `var yh=mid-ex(uh)*Math.cos(uh-t+lag)*amp;` |
| E2 | `EfectoPiel_explorador.html` · 140, 150, 151, 102–104 | δ, α = 1/δ y R_s se calculan con la fórmula de buen conductor en todo régimen; para agua de mar a 1 GHz ("intermedio") δ está 38 % por debajo del valor exacto y a 1 THz ("cuasi-dieléctrico") 98 %. La gráfica δ(f) también es errónea en esos tramos. | Usar la fórmula general (Ulaby 7.66): `var w=2*Math.PI*f, eps=er()*E0P, q=sigma()/(w*eps); var a=w*Math.sqrt(MU0*eps/2)*Math.sqrt(Math.sqrt(1+q*q)-1); var b=w*Math.sqrt(MU0*eps/2)*Math.sqrt(Math.sqrt(1+q*q)+1); delta=1/a;` y mostrar α y β por separado; o bien limitar f para que tanδ ≥ 10 y rotular "fuera del modelo". |
| E3 | `Doppler_explorador.html` · 122, 186, 210–211, 230, 254–255 | Fórmula acústica de fuente móvil f/(1∓β) aplicada a ondas EM con β hasta 0.7 (error 40 %). | Sustituir por la relativista: `fup=Math.sqrt((1+beta)/(1-beta))`, `fdn=Math.sqrt((1-beta)/(1+beta))`; en el `.eq`: f′ = f·√((1±v/c)/(1∓v/c)); conservar Δf/f ≈ v/c como límite. Opcional: dibujar ambas curvas en `drawCurve` para mostrar la diferencia. |
| E4 | `Espectro_explorador.html` · 144–145 | Frontera IR/visible en 10^14.63 Hz = 702.8 nm; la página define el visible como 750–380 nm (l. 106, 245, 267). A 750 nm el tile dice "Infrarrojo" y el color "rojo". | `{a:13,b:14.602,...,n:'Infrarrojo'},{a:14.602,b:14.897,c:'rainbow',n:'Visible'},{a:14.897,b:16.5,...}` (y en `EfectoPiel` l. 189 la banda sombreada 14.63–14.90 puede dejarse: es sólo orientativa). |
| E5 | `MicroondasC_explorador.html` · 225–226 | Para f < 188 MHz (sólo vía casilla `fnum`, min = 100) el ajuste automático toma h₂ = W y da c = 0.90×10⁸ m/s (−70 %). | Bajar `min` de `fnum` a 200, o en `win()` quitar el tope 120 cm cuando λ/2 > 100 cm, o en el fallback poner `n=1; h2=h1+lam()/2` y, si h₂ > W, mostrar "λ/2 no cabe en la ventana". |
| E6 | `Polarizacion_explorador.html` · 164, 250 | Umbral de "Circular" (\|sinδ−1\| < 0.04 ⇒ δ ∈ 73.7°–106.3°) admite AR = 1.33 mientras el tile AR muestra 1.33 y el veredicto afirma "−3 dB sin importar la orientación" (en realidad −2.0 a −4.4 dB). | Clasificar por AR: `var ar=axialRatioNum(); circ = ar<1.05;` (y lineal si ar>50), o apretar la tolerancia a \|sinδ−1\| < 0.002 y \|A−B\| < 0.01. |

### 6.2 Puntos que requieren verificación o decisión pedagógica

| # | Archivo · línea | Descripción | Propuesta |
|---|---|---|---|
| V1 | `Doppler` · 155–156, 302, 320–328 | z y v/c se tratan como idénticos hasta z = 0.3 (17 % de error en v); además el tile se llama "Velocidad de recesión" aunque el corrimiento cosmológico no es un Doppler cinemático. | Limitar el deslizador a z ≤ 0.1, o calcular β = ((1+z)²−1)/((1+z)²+1) y mostrar ambas; añadir nota "para galaxias lejanas z no es una velocidad". |
| V2 | `Doppler` · 309 | f′ mostrada con 4 decimales de GHz oculta corrimientos de kHz. | Mostrar f′ como "f + Δf" o con `toPrecision(12)`. |
| V3 | `Doppler` · 286 | Para z > 0.188, Hα sale de la franja (780 nm) y la etiqueta queda en el borde. | Extender LMAX a ~900 nm o indicar "fuera de la franja (IR)". |
| V4 | `EfectoPiel` · 153 | Umbrales de régimen 10 / 0.1 frente a 100 / 0.01 de Ulaby. | Adoptar los del libro o declarar los propios. |
| V5 | `EfectoPiel` · 120, 136 | "Modelo orientativo por arriba del IR" es optimista: Cu deja de ser σ constante desde ~1 THz (ωτ ~ 1); agua de mar εᵣ = 81 sólo vale ≲ 1–10 GHz (relajación de Debye). | Reformular la nota: "válido hasta ~100 GHz para metales y ~1 GHz para agua". |
| V6 | `EfectoPiel` · tiles | No se muestra tan δ_p ni η_c = (1+j)/(σδ) ni λ = 2πδ, u_p = ωδ; no hay μᵣ (hierro/acero) ni plata. | Añadir tiles y entrada μᵣ; añadir Ag (6.1×10⁷) y Fe (1.0×10⁷, μᵣ ≈ 200 como valor orientativo, con advertencia de dispersión). |
| V7 | `Polarizacion` · 109, 164 | No se declara convención de mano ni se nombra RHCP/LHCP; no se muestran ψ y χ. | Tile "Mano (IEEE)": sinδ > 0 → LHCP, sinδ < 0 → RHCP, con nota de la convención óptica inversa; tiles ψ y χ con las ecs. 7.48–7.49 de Ulaby. |
| V8 | `Polarizacion` · 165 | AR por barrido con paso 2° (−0.3 %). | Fórmula cerrada: `var p=A*A+B*B, q=Math.sqrt((A*A-B*B)*(A*A-B*B)+4*A*A*B*B*Math.cos(dd)*Math.cos(dd)); AR=Math.sqrt((p+q)/(p-q));` |
| V9 | `MicroondasC` · 97, 113 | Sin propagación de incertidumbre (P5). | Tile δc/c = δD/D con casilla δD; nota de que el 25 % observado es sistemático (multimodo) y no estadístico. |
| V10 | `MicroondasC` · 134 | No aparece c = 1/√(μ₀ε₀) (tema 2.3). | Añadir al formulario. |
| V11 | `Espectro` · 108 | "~60 octavas" (el eje muestra 69.8). | "~70 octavas del eje mostrado". |
| V12 | `Espectro` · 158–159 | Formatos "1000.00 fm", "1000.00 meV", "0.00 neV" por redondeo en los umbrales. | Comparar con `>=0.9995e-12` etc., o usar `toPrecision`. |
| V13 | `Espectro` · 146 | Frontera X/γ en 207 keV (convención habitual ~100 keV o por origen). | Decisión de convención; declararla. |
| V14 | `Espectro` · 212 | Faltan presets horno 2.45 GHz y GPS 1.575 GHz; falta nota k = 2π/λ. | Añadir. |

### 6.3 Qué está confirmado y qué es juicio
- **Confirmado numéricamente** (node + numpy): E1 (signo de la fase), E2 (−38 %/−98 %), E3 (+0.5…+40 %), E4 (tile "Infrarrojo" a 750 nm), E5 (c = 9.01×10⁷), E6 (AR = 1.327 clasificado circular; PLF 0.36–0.64); exactitud de todas las demás fórmulas (≤ 0.3 %); valores de σ, líneas espectrales, constantes, banderas tecnológicas y presets.
- **Juicio pedagógico / convención**: V1, V4, V5 (límites de validez de σ(ω) y εᵣ(ω)), V7 (qué convención adoptar), V13, cobertura de temas.
- Referencias citadas sólo por libro y sección que conozco con certeza: Ulaby–Michielssen–Ravaioli 6e §7-2 (polarización), §7-4 (medios con pérdidas, buen conductor), §7-5 (R_s), §8-1 (incidencia normal, onda estacionaria), Apéndice B (σ, εᵣ); Griffiths 4e §9.4.1 (ondas en conductores, retraso de 45°), cap. 12 (relatividad, Doppler); Balanis *Antenna Theory* §2.12 (PLF); Pozar 4e §14.3 (radar Doppler).
